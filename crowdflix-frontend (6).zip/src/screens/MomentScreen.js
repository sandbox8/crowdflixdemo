import React, {
  useEffect,
  useState,
  useMemo,
  useCallback,
  useRef,
} from "react";
import { useParams, useNavigate } from "react-router-dom";
import MomentMediaDisplay from "../components/MomentMediaDisplay";
import MomentTitleSection from "../components/MomentTitleSection";
import MomentPriceSection from "../components/MomentPriceSection";
import CharacterBlock from "../components/CharacterBlock";
import MovieBlock from "../components/MovieBlock";
import MomentDescriptionStats from "../components/MomentDescriptionStats";
import SalesHistoryTable from "../components/SalesHistoryTable";
import BidsHistoryTable from "../components/BidsHistoryTable";

// Sample moment data
const sampleMomentData = {
  "iron-man-reveal": {
    id: "iron-man-reveal",
    title: "I Am Iron Man",

    // Title section data for MomentTitleSection
    titleData: {
      rarity: "Legendary",
      serialNumber: "#3,498",
      sold: "9,854",
      total: "12,000",
      momentName: "Iron Man",
      subtitle: "MCU Legendary Moment",
      iconUrl:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/f874c6ddb00d519f7941eda79457c5fd2a177be6",
    },

    // Price section data for MomentPriceSection
    priceData: {
      lowestAsk: "$13.00",
      currency: "USD",
      avgSale: "$14.00 USD",
      forSale: "50",
    },

    // Media data for MomentMediaDisplay
    media: {
      videoUrl:
        "https://cdn.builder.io/o/assets%2FYJIGb4i01jvw0SRdL5Bt%2Fd27731a526464deba0016216f5f9e570%2Fcompressed?apiKey=YJIGb4i01jvw0SRdL5Bt&token=d27731a526464deba0016216f5f9e570&alt=media&optimized=true",
      angle1:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F35be60d44b714f869e2fd177463466d3",
      angle2:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F8f0b5b6d419f455392efe8a069e5b192",
      angle3:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fbd2c990d57b842dbb08d53f12b339652",
    },

    // Character data for CharacterBlock
    character: {
      name: "Iron Man",
      description:
        "Iron Man, also known as Tony Stark, is a beloved character from the Marvel Universe, known for his genius intellect, cutting-edge technology, and charismatic personality.",
      alias: "Tony Stark",
      nationality: "U.S",
      height: "6&apos;1",
      actor: "Robert Downey Jr.",
      born: "1973",
      avatarImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/225835f61b9b0d4cbace96462d65f716ee2a4575",
    },

    // Movie data for MovieBlock
    movie: {
      title: "Avengers: Endgame",
      year: "2019",
      tags: ["Marvel", "Superhero", "Time Travel", "Action", "Sci-Fi"],
      posterImage: "https://cdn.builder.io/api/v1/image/assets/TEMP/poster1",
      carouselImages: [
        "https://cdn.builder.io/api/v1/image/assets/TEMP/poster1",
        "https://cdn.builder.io/api/v1/image/assets/TEMP/poster2",
        "https://cdn.builder.io/api/v1/image/assets/TEMP/poster3",
      ],
      credits: {
        director: "Anthony Russo, Joe Russo",
        writers: "Christopher Markus, Stephen McFeely",
        producers: "Kevin Feige",
        cinematography: "Trent Opaloch",
        composers: "Alan Silvestri",
        releaseDate: "April 26, 2019",
        boxOffice: "$2.798 billion",
      },
    },

    // Description and stats for MomentDescriptionStats
    description:
      "Tony Stark&apos;s iconic reveal in Iron Man (2008) changed superhero cinema forever. This pivotal moment showcases Stark&apos;s defiance of traditional secret identity conventions.",
    stats: [
      {
        label: "Unlisted",
        sublabel: "Owned",
        value: "306",
        color: "purple",
        bgColor: "rgba(118, 22, 156, 0.10)",
      },
      {
        label: "For Sale",
        sublabel: "Owned",
        value: "198",
        color: "blue",
        bgColor: "rgba(57, 65, 211, 0.10)",
      },
      {
        label: "Locked",
        sublabel: "Owned",
        value: "459",
        color: "cyan",
        bgColor: "rgba(55, 154, 184, 0.10)",
      },
      {
        label: "Hidden In Packs",
        sublabel: "",
        value: "1.389",
        color: "green",
        bgColor: "rgba(55, 154, 184, 0.10)",
      },
      {
        label: "In The Locker",
        sublabel: "",
        value: "94",
        color: "yellow",
        bgColor: "rgba(139, 127, 56, 0.10)",
      },
      {
        label: "Burned",
        sublabel: "",
        value: "35",
        color: "red",
        bgColor: "rgba(189, 67, 46, 0.10)",
      },
    ],

    // Sales data for SalesHistoryTable
    sales: {
      availableCount: 6,
      sortBy: "Lowest Ask: low to high",
      listings: [
        {
          id: 1,
          price: "$350.00",
          serial: "#37",
          seller: "@EWW",
          avatar: "user-1",
          isSelected: false,
          isHighlighted: false,
        },
        {
          id: 2,
          price: "$400.00",
          serial: "#9",
          seller: "@num1SEAfanNSD",
          avatar: "user-2",
          isSelected: true,
          isHighlighted: true,
        },
        {
          id: 3,
          price: "$550.00",
          serial: "#2",
          seller: "@wemby",
          avatar: "user-3",
          isSelected: false,
          isHighlighted: false,
        },
        {
          id: 4,
          price: "$600.00",
          serial: "#63",
          seller: "@MaktW2n",
          avatar: "user-4",
          isSelected: false,
          isHighlighted: false,
        },
        {
          id: 5,
          price: "$600.00",
          serial: "#24",
          seller: "@SEAfanNSD",
          avatar: "user-5",
          isSelected: false,
          isHighlighted: false,
        },
        {
          id: 6,
          price: "$1,000.00",
          serial: "#71",
          seller: "@Twtbttttt",
          avatar: "user-6",
          isSelected: false,
          isHighlighted: false,
        },
      ],
    },

    // Bids data for BidsHistoryTable
    bids: {
      timeFilter: "Today",
      bidHistory: [
        {
          id: 1,
          user: "@wemby",
          avatar: "user-3",
          price: "$8.00",
          time: "05:00 pm",
        },
        {
          id: 2,
          user: "@MaktW2n",
          avatar: "user-4",
          price: "$10.00",
          time: "05:25 pm",
        },
        {
          id: 3,
          user: "@SEAfanNSD",
          avatar: "user-5",
          price: "$11.00",
          time: "07:00 pm",
        },
      ],
      highestBid: {
        user: "@Twtbttttt",
        avatar: "user-6",
        price: "$13.00",
        time: "09:00 pm",
      },
    },
  },
};

function MomentScreen() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [moment, setMoment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isSticky, setIsSticky] = useState(false);
  const [shareSuccess, setShareSuccess] = useState(false);
  const [purchaseLoading, setPurchaseLoading] = useState(false);
  const [activeSection, setActiveSection] = useState("title");
  const [isMobile, setIsMobile] = useState(false);

  // Refs for scroll management
  const contentRef = useRef(null);
  const titleRef = useRef(null);
  const characterRef = useRef(null);
  const movieRef = useRef(null);
  const statsRef = useRef(null);
  const salesRef = useRef(null);
  const bidsRef = useRef(null);

  // Get moment data based on ID
  const momentData = useMemo(() => {
    return sampleMomentData[id] || sampleMomentData["iron-man-reveal"];
  }, [id]);

  // Optimized share handler with feedback
  const handleShare = useCallback(async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: `${moment.titleData.momentName} - CrowdFlix`,
          text: `Check out this ${moment.titleData.rarity} moment: ${moment.titleData.momentName}`,
          url: window.location.href,
        });
      } else {
        await navigator.clipboard.writeText(window.location.href);
        setShareSuccess(true);
        setTimeout(() => setShareSuccess(false), 3000);
      }
    } catch (err) {
      console.error("Share failed:", err);
    }
  }, [moment]);

  // Optimized purchase handler with loading state
  const handlePurchase = useCallback(async () => {
    setPurchaseLoading(true);
    try {
      // Simulate brief loading for UX
      await new Promise((resolve) => setTimeout(resolve, 500));

      // Navigate directly to payment success screen for bottom CTA
      navigate("/purchase-success");
    } catch (err) {
      console.error("Navigation failed:", err);
    } finally {
      setPurchaseLoading(false);
    }
  }, [navigate]);

  // Mobile detection effect
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 1024);
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);

    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  // Scroll to section handler
  const scrollToSection = useCallback((section) => {
    const refs = {
      title: titleRef,
      character: characterRef,
      movie: movieRef,
      stats: statsRef,
      sales: salesRef,
      bids: bidsRef,
    };

    refs[section]?.current?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
    setActiveSection(section);
  }, []);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case "s":
            e.preventDefault();
            handleShare();
            break;
          case "b":
            e.preventDefault();
            handlePurchase();
            break;
          case "Escape":
            navigate("/marketplace");
            break;
          default:
            break;
        }
      }
    };

    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, [handleShare, handlePurchase, navigate]);

  // Scroll monitoring for sticky elements and active sections
  useEffect(() => {
    const handleScroll = () => {
      if (contentRef.current) {
        const scrollTop = contentRef.current.scrollTop;
        setIsSticky(scrollTop > 100);

        // Update active section based on scroll position
        const sections = [
          { name: "title", ref: titleRef },
          { name: "character", ref: characterRef },
          { name: "movie", ref: movieRef },
          { name: "stats", ref: statsRef },
          { name: "sales", ref: salesRef },
          { name: "bids", ref: bidsRef },
        ];

        for (let i = sections.length - 1; i >= 0; i--) {
          const section = sections[i];
          if (section.ref.current) {
            const rect = section.ref.current.getBoundingClientRect();
            if (rect.top <= 200) {
              setActiveSection(section.name);
              break;
            }
          }
        }
      }
    };

    const contentElement = contentRef.current;
    if (contentElement) {
      contentElement.addEventListener("scroll", handleScroll);
      return () => contentElement.removeEventListener("scroll", handleScroll);
    }
  }, []);

  // Enhanced loading with error handling
  useEffect(() => {
    const loadMoment = async () => {
      try {
        setLoading(true);
        setError(null);

        // Simulate API call with potential failure
        await new Promise((resolve, reject) => {
          setTimeout(() => {
            if (Math.random() > 0.95) {
              // 5% chance of error for testing
              reject(new Error("Failed to load moment"));
            } else {
              resolve();
            }
          }, 800);
        });

        setMoment(momentData);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    loadMoment();
  }, [momentData]);

  if (loading) {
    return (
      <div className="moment-loading">
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <div className="loading-text">Loading moment...</div>
          <div className="loading-subtitle">
            Preparing your exclusive experience
          </div>
          <div className="loading-progress">
            <div className="progress-bar"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !moment) {
    return (
      <div className="moment-error">
        <div className="error-container">
          <div className="error-icon">⚠️</div>
          <h2>{error ? "Failed to Load Moment" : "Moment Not Found"}</h2>
          <p>
            {error
              ? "There was an issue loading this moment. Please try again."
              : "The moment you're looking for doesn't exist or has been removed."}
          </p>
          <div className="error-actions">
            {error && (
              <button
                className="retry-button"
                onClick={() => window.location.reload()}
              >
                Try Again
              </button>
            )}
            <button
              className="back-button"
              onClick={() => navigate("/marketplace")}
            >
              Back to Marketplace
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="moment-detail-page">
      {/* Background styling */}
      <div className="moment-background">
        <div className="background-gradient"></div>
        <div className="background-pattern"></div>
      </div>

      {/* Navigation breadcrumb */}
      <div className="moment-breadcrumb">
        <button
          onClick={() => navigate("/marketplace")}
          className="breadcrumb-link"
        >
          ← Marketplace
        </button>
        <span className="breadcrumb-divider">/</span>
        <span className="breadcrumb-current">
          {moment.titleData.momentName}
        </span>
      </div>

      {/* Quick navigation sidebar */}
      <div className={`quick-nav ${isSticky ? "sticky" : ""}`}>
        <div className="nav-title">Quick Navigation</div>
        <button
          className={`nav-item ${activeSection === "title" ? "active" : ""}`}
          onClick={() => scrollToSection("title")}
        >
          Overview
        </button>
        <button
          className={`nav-item ${activeSection === "character" ? "active" : ""}`}
          onClick={() => scrollToSection("character")}
        >
          Character
        </button>
        <button
          className={`nav-item ${activeSection === "movie" ? "active" : ""}`}
          onClick={() => scrollToSection("movie")}
        >
          Movie
        </button>
        <button
          className={`nav-item ${activeSection === "stats" ? "active" : ""}`}
          onClick={() => scrollToSection("stats")}
        >
          Statistics
        </button>
        <button
          className={`nav-item ${activeSection === "sales" ? "active" : ""}`}
          onClick={() => scrollToSection("sales")}
        >
          Sales
        </button>
        <button
          className={`nav-item ${activeSection === "bids" ? "active" : ""}`}
          onClick={() => scrollToSection("bids")}
        >
          Bids
        </button>
      </div>

      {/* Success feedback */}
      {shareSuccess && (
        <div className="share-success">✓ Link copied to clipboard!</div>
      )}

      {/* Keyboard shortcuts help */}
      <div className="keyboard-hints">
        <div className="hint">Ctrl+S to share</div>
        <div className="hint">Ctrl+B to buy</div>
        <div className="hint">ESC to go back</div>
      </div>

      {/* Main layout container */}
      <div className="moment-detail-layout">
        {/* Left Column - Scroll-locked media */}
        <div className="moment-media-column">
          <div className="media-sticky-container">
            <MomentMediaDisplay
              videoUrl={moment.media.videoUrl}
              angle1={moment.media.angle1}
              angle2={moment.media.angle2}
              angle3={moment.media.angle3}
            />
          </div>
        </div>

        {/* Right Column - Scrollable content */}
        <div className="moment-content-column" ref={contentRef}>
          {/* Moment title section */}
          <div ref={titleRef} className="section-anchor">
            <MomentTitleSection
              rarity={moment.titleData.rarity}
              serialNumber={moment.titleData.serialNumber}
              sold={moment.titleData.sold}
              total={moment.titleData.total}
              momentName={moment.titleData.momentName}
              subtitle={moment.titleData.subtitle}
              iconUrl={moment.titleData.iconUrl}
            />
          </div>

          {/* Moment price section with enhanced interactions */}
          <div className="price-section-container">
            <MomentPriceSection
              lowestAsk={moment.priceData.lowestAsk}
              currency={moment.priceData.currency}
              avgSale={moment.priceData.avgSale}
              forSale={moment.priceData.forSale}
              onShare={handleShare}
              onPurchase={handlePurchase}
              isLoading={purchaseLoading}
            />
          </div>

          {/* Character information */}
          <div ref={characterRef} className="section-anchor">
            <div className="section-header">
              <h3 className="section-title">Character Details</h3>
              <div className="section-divider"></div>
            </div>
            <CharacterBlock
              name={moment.character.name}
              description={moment.character.description}
              alias={moment.character.alias}
              nationality={moment.character.nationality}
              height={moment.character.height}
              actor={moment.character.actor}
              born={moment.character.born}
              avatarImage={moment.character.avatarImage}
            />
          </div>

          {/* Movie information */}
          <div ref={movieRef} className="section-anchor">
            <div className="section-header">
              <h3 className="section-title">Movie Details</h3>
              <div className="section-divider"></div>
            </div>
            <MovieBlock
              title={moment.movie.title}
              year={moment.movie.year}
              tags={moment.movie.tags}
              posterImage={moment.movie.posterImage}
              carouselImages={moment.movie.carouselImages}
              credits={moment.movie.credits}
            />
          </div>

          {/* Description and statistics */}
          <div ref={statsRef} className="section-anchor">
            <div className="section-header">
              <h3 className="section-title">Statistics & Analytics</h3>
              <div className="section-divider"></div>
            </div>
            <MomentDescriptionStats
              description={moment.description}
              stats={moment.stats}
            />
          </div>

          {/* Sales history */}
          <div ref={salesRef} className="section-anchor">
            <div className="section-header">
              <h3 className="section-title">Sales History</h3>
              <div className="section-divider"></div>
            </div>
            <SalesHistoryTable
              availableCount={moment.sales.availableCount}
              sortBy={moment.sales.sortBy}
              listings={moment.sales.listings}
            />
          </div>

          {/* Bids history */}
          <div ref={bidsRef} className="section-anchor">
            <div className="section-header">
              <h3 className="section-title">Bid History</h3>
              <div className="section-divider"></div>
            </div>
            <BidsHistoryTable
              timeFilter={moment.bids.timeFilter}
              bidHistory={moment.bids.bidHistory}
              highestBid={moment.bids.highestBid}
            />
          </div>

          {/* Scroll to top button */}
          <button
            className={`scroll-top-button ${isSticky ? "visible" : ""}`}
            onClick={() =>
              contentRef.current?.scrollTo({ top: 0, behavior: "smooth" })
            }
          >
            ↑ Back to Top
          </button>
        </div>
      </div>

      {/* Bottom CTA Section for Mobile */}
      {isMobile && (
        <div className="moment-bottom-cta visible">
          <div className="bottom-cta-content">
            <div className="bottom-cta-info">
              <div className="moment-name">{moment.titleData.momentName}</div>
              <div className="moment-price">{moment.priceData.lowestAsk}</div>
            </div>
            <button
              className={`bottom-select-pay-button ${purchaseLoading ? "loading" : ""}`}
              onClick={handlePurchase}
              disabled={purchaseLoading}
            >
              {purchaseLoading ? (
                <>
                  <div className="button-spinner"></div>
                  Processing...
                </>
              ) : (
                "Select and Pay"
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default MomentScreen;
