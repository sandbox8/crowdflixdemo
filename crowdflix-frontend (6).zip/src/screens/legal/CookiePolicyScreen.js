import React from 'react';

function CookiePolicyScreen() {
    return (
        <div className='container my-3 legal align-self-start'>
            <h3>Cookie Policy</h3>
            <div>
                <p className='fs-5'><strong>Cookie Policy Overview (Effective from November 26, 2023):</strong></p>
                <p><strong>Purpose of Cookies and Tracking Technologies:</strong><br />
                    CrowdFlix employs cookies and pixel tags to enhance user experience and ensure the platform&apos;s security. These technologies are used to authenticate users, remember preferences, analyze site usage, and personalize advertising content.</p>

                <strong>User Control and Consent:</strong><br />
                <ul>
                    <li>Users have tools to control cookie settings, with the ability to opt out of non-essential cookies. Essential cookies are mandatory for site function and security.</li>
                    <li>Preferences for marketing communications and app notifications can be adjusted in user settings.</li>
                </ul>

                <strong>Security Practices:</strong><br />
                <ul>
                    <li>CrowdFlix prioritizes data security, using encryption and advocating for solid user account protection measures, including the recommendation of two-factor authentication.</li>
                    <li>A dedicated team is in place to respond to and manage security incidents.</li>
                </ul>
            </div>
        </div>
    );
}

export default CookiePolicyScreen;