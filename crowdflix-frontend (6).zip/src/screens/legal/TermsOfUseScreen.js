import React from 'react';

function TermsOfUseScreen() {
    return (
        <div className='container my-3 legal'>
            <h3>Terms of Use</h3>
            <div>
                <p>
                    <strong>Acceptance of Terms:</strong> By accessing CrowdFlix, a digital collectibles platform operated by CrowdFlix Inc. (&quot;us,&quot; &quot;we&quot;), you accept these Terms, including our Privacy and Cookie Policies, and agree to comply with other site-specific rules.<br />
                    <strong>Modifications to Terms:</strong> We may periodically revise these Terms. Notice of significant changes will be provided on our platform or by email. Continued use after changes means you agree to the new Terms.<br />
                    <strong>Usage of CrowdFlix:</strong> CrowdFlix is intended for personal, non-commercial use, with expanded use detailed in further sections.<br />
                    <strong>Account Registration:</strong> You must be 18+ or of legal age to form a binding contract to create a CrowdFlix account. Ensure your information is accurate. Keep your password secret, and report unauthorized use to <a href='mailto:support@crowdflix.io' className='my-link text-decoration-underline'>support@crowdflix.io</a>.
                </p>

                <strong>Prohibited Actions:</strong><br />
                <ul>
                    <li>Do not violate laws, others&apos; rights, or contracts.</li>
                    <li>Avoid posting inaccurate, misleading, or fraudulent information.</li>
                    <li>Do not distribute spam or malicious software.</li>
                    <li>Refrain from engaging in fraudulent transactions or unauthorized marketplace activities.</li>
                </ul>

                <p className='fw-bold fs-5'>How Movie Moments Work:</p>
                <p>Movie Moments on CrowdFlix are officially licensed digital collectibles from studios, distributors, and independent IP holders. Collectors can acquire, trade, and showcase these moments on the Flow blockchain.</p>

                <strong>Ownership and Licensing:</strong><br />
                <ul>
                    <li>Purchasing a Movie Moment NFT grants you ownership of the digital collectible but not the underlying intellectual property.</li>
                    <li>Movie Moments are licensed by studios, distributors, and IP holders for use on CrowdFlix.</li>
                    <li>You cannot alter, commercialize, or resell Movie Moments outside of approved platforms.</li>
                </ul>

                <strong>Trading and Showcasing:</strong><br />
                <ul>
                    <li>Movie Moments can be traded within the CrowdFlix marketplace.</li>
                    <li>Collectors can showcase their collections using the CrowdFlix platform.</li>
                </ul>

                <strong>Payments, Gas Fees & Taxes:</strong><br />
                <ul>
                    <li>All transactions occur on the Flow blockchain.</li>
                    <li>Gas fees apply for blockchain transactions.</li>
                    <li>You are responsible for any applicable taxes related to your purchases.</li>
                </ul>

                <strong>Account Security:</strong><br />
                <ul>
                    <li>Users are responsible for securing their CrowdFlix accounts and electronic wallets.</li>
                    <li>If unauthorized access is detected, notify us immediately.</li>
                </ul>

                <p className='fw-bold fs-5'>Termination & Enforcement:</p>
                <ul>
                    <li>If you violate these Terms, we reserve the right to suspend or terminate your account.</li>
                    <li>We may revoke Movie Moments acquired through fraudulent activities.</li>
                </ul>

                <p className='fw-bold fs-5'>Dispute Resolution & Arbitration:</p>
                <ul>
                    <li>All disputes shall be resolved through binding arbitration.</li>
                    <li>You waive the right to participate in class-action lawsuits against CrowdFlix.</li>
                </ul>

                <p className='fw-bold fs-5'>Changes to Terms:</p>
                <ul>
                    <li>We may update these Terms, and continued use of the App after updates constitutes acceptance.</li>
                </ul>

                <hr />

                <p><strong>External Websites:</strong><br />
                    When you click on a link that takes you off CrowdFlix, your experience on that third-party site is not our responsibility. You also agree to their terms when partnering with companies like Stripe for payment processing.</p>

                <p><strong>Your Intellectual Property:</strong><br />
                    Your content stays yours; you permit us to use it to run and promote the service. When you post content, you grant us the right to use and adapt your content, but you must have the rights to what you post.</p>

                <p><strong>CrowdFlix&apos;s Intellectual Property:</strong><br />
                    You can use the content on CrowdFlix for personal, non-commercial purposes. Commercial use requires permission. CrowdFlix owns and protects its content under copyrights, trademarks, patents, and other laws.</p>

                <p><strong>Copyright Issues:</strong><br />
                    We adhere to the DMCA and will respond to valid infringement notices. Repeat infringers&apos; accounts may be terminated.</p>

                <p><strong>Deleting Your Account:</strong><br />
                    You can delete your account, but this doesn&apos;t remove your posted content. Some data may be retained as required by law or for legitimate business purposes. Contact us for specific requests regarding content removal.</p>

                <p><strong>Our Rights:</strong><br />
                    CrowdFlix Inc. reserves the right to manage the platform to maintain its integrity and provide a secure environment. This includes making service alterations without notice, determining user eligibility, canceling accounts, and moderating projects at any time.</p>

                <p><strong>Warranty Disclaimer:</strong><br />
                    The CrowdFlix platform is provided &quot;as is&quot; without warranties. Users engage with the platform at their own risk, and CrowdFlix Inc. disclaims all warranties, whether express or implied, to the extent permitted by law.</p>

                <p><strong>Indemnification:</strong><br />
                    Users agree to indemnify and hold CrowdFlix Inc. harmless from any legal claims resulting from their use or misuse of CrowdFlix, including breaches of the Terms of Use.</p>

                <p><strong>Limitation of Liability:</strong><br />
                    CrowdFlix Inc.&apos;s liability for the platform is limited. The company is not liable for indirect or consequential damages arising from using the platform, capped at $100 for direct damages.</p>

                <p><strong>Dispute Resolution and Governing Law:</strong><br />
                    Any legal disputes concerning CrowdFlix will be governed by the laws of Delaware and must be resolved through arbitration or in the state’s courts.</p>
            </div>
        </div>
    );
}

export default TermsOfUseScreen;