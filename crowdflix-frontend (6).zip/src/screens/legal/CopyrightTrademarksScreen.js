import React from 'react';

function CopyrightTrademarksScreen() {
    return (
        <div className='container my-3 legal'>
            <h3>Copyright & Trademark</h3>
            <div>
                <p className='fs-5'><strong>Copyright and DMCA Compliance Overview (Effective from November 28, 2023):</strong></p>
                <p><strong>Purpose of Cookies and Tracking Technologies:</strong><br />
                    Sandbox8 employs cookies and pixel tags to enhance user experience and ensure the platform&apos;s security. These technologies are used to authenticate users, remember preferences, analyze site usage, and personalize advertising content.</p>

                <strong>DMCA Adherence:</strong><br />
                <ul>
                    <li>Sandbox8 observes DMCA regulations, removing content that infringes copyright upon receipt of a valid takedown notice.</li>
                    <li>Users have recourse to report infringements or respond to takedown notices if they believe content was wrongly removed.</li>
                </ul>

                <strong>Reporting and Counter-Notification:</strong><br />
                <ul>
                    <li>Users considering filing a claim should seek legal advice to understand fair use and other copyright exceptions.</li>
                    <li>Detailed instructions are provided for submitting a DMCA notice requiring specific information to process the claim.</li>
                    <strong>Counter-Notification Process for Sandbox8 Projects:</strong><br />
                    If your project has been affected by a Take Down Notice and you believe it&apos;s a mistake or have the right to use the material, you can challenge this by submitting a counter-notification to Sandbox8. Here&apos;s what you need to include, which you should verify with legal counsel or refer to 7 USC §52(g)(3):
                    <ul>
                        <li><strong>Your Signature:</strong> Include either your physical or electronic signature.</li>
                        <li><strong>Identification of Removed Material:</strong> Clearly describe the material that was removed or disabled, along with its previous location on the platform before removal or disablement.</li>
                        <li><strong>Statement of Good Faith Belief:</strong> Assert, &quot;Under penalty of perjury, I have a good faith belief that the material was removed or disabled as a result of mistake or misidentification of the material.&quot;</li>
                        <li><strong>Contact Information:</strong> Provide your name, address, and telephone number.</li>
                        <li><strong>Consent to Jurisdiction:</strong> Include a statement consenting to the jurisdiction of the federal district court for the district where your address is located, or if outside the US, in any district where Sandbox8 may be found. Agree to accept service of process from the person who submitted the Take Down Notice or their agent.</li>
                    </ul>
                </ul>

                <p>This information must be provided in English and sent to Sandbox8&apos;s designated copyright agent at the provided email address. This process is designed to ensure that creators have the opportunity to dispute a takedown when they have lawful grounds to do so. Counter-Notification and Copyright Dispute Process (Sandbox8):</p>

                <strong>Liability for Misrepresentation:</strong>
                <p>Misrepresenting material as mistakenly removed can lead to liability under the Copyright Act.</p>

                <strong>Counter-Notification Handling:</strong>
                <ul>
                    <li>Sandbox8 processes counter-notifications according to DMCA timelines.</li>
                    <li>Additional information may be requested to complete the counter-notification process.</li>
                    <li>Action on counter-notifications requires complete and accurate attestations.</li>
                </ul>

                <strong>Post-Counter-Notification Procedure:</strong>
                <ul>
                    <li>Counter-notifications are communicated to the original claimant.</li>
                    <li>Absence of legal action from the claimant within 10 business days may lead to the reinstatement of the project.</li>
                    <li>Project access remains restricted during the dispute period, with specific project management actions still available to the creator.</li>
                </ul>

                <strong>Transparency Commitment:</strong>
                <ul>
                    <li>Sandbox8 publishes Down Notices and counter-notifications on the platform and Lumen, excluding personal identifiers.</li>
                    <li>Parties involved in the dispute consent to the publication of their provided information.</li>
                </ul>

                <strong>Backer Communication:</strong>
                <ul>
                    <li>Backers will be notified via email about any project involved in a copyright dispute.</li>
                    <li>Management of pledges is still accessible even if the project content is disabled.</li>
                </ul>

                <strong>Restoration or Cancellation of Projects:</strong>
                <ul>
                    <li>Projects may be restored if disputes are resolved within 30 days; otherwise, projects may be canceled.</li>
                    <li>Pledge authorizations expire if projects are canceled.</li>
                </ul>

                <strong>Patent Infringement Claims:</strong>
                <ul>
                    <li>Sandbox8 reviews patent infringement claims with valid court orders.</li>
                    <li>Required information for such claims includes the URL of the infringing project and contact details.</li>
                    <li>A court order is necessary due to the complexity of patent infringement claims.</li>
                </ul>

                <strong>Review of Patent Claims:</strong>
                <ul>
                    <li>Sandbox8 will act on patent infringement claims substantiated by a court order, removing the infringing project from public view.</li>
                </ul>

                <hr />

                <p className='fs-5'><strong>Trademark Policy Overview (Effective from November 28, 2023):</strong></p>
                <strong>Policy Summary:</strong>
                <p>Sandbox8&apos;s Policy outlines how it handles potential trademark infringements. The platform does not mediate disputes but may investigate and act on clear infringement cases.</p>

                <strong>Trademark Infringement Resolution:</strong>
                <ul>
                    <li>Trademark owners are encouraged to resolve issues directly with the creator first.</li>
                    <li>If direct resolution is impossible, trademark owners can file a complaint via Sandbox8&apos;s specified process.</li>
                </ul>

                <strong>Filing a Trademark Complaint:</strong>
                <ul>
                    <li>Complaints require detailed information about the alleged infringement and must be submitted in English.</li>
                    <li>The complaint must include the URL of the infringing project, specific details of the violation, trademark registration details, and the claimant&apos;s contact information.</li>
                    <li>A statement acknowledging that the complaint may be shared with involved parties and affirming good faith belief in the violation must be included.</li>
                </ul>

                <strong>Sandbox8&apos;s Response to Trademark Complaints:</strong>
                <ul>
                    <li>Each report is reviewed seriously, and appropriate action is taken at Sandbox8&apos;s discretion, which could involve content removal or account termination.</li>
                    <li>Repeat infringers or even single-instance infringers may face account termination.</li>
                </ul>
            </div>
        </div>
    );
}

export default CopyrightTrademarksScreen;