import React from 'react';

function PrivacyPolicyScreen() {
    return (
        <div className='container my-3 legal'>
            <h3>Privacy Policy</h3>
            <div>
                <p>
                    CrowdFlix LLC (together with its subsidiaries, affiliates, agents, representatives, consultants, employees, officers, and directors—collectively, &quot;CrowdFlix,&quot; &quot;we,&quot; or &quot;us&quot;) provides services through <a href='https://crowdflix.io' className='my-link text-decoration-underline'>crowdflix.io</a>, &quot;crowdflix&quot; that help people bring creative projects to life (our &quot;Services&quot;).
                </p>

                <p className='fs-5'><strong>Privacy Policy Overview</strong></p>
                <p><strong>Purpose and Consent:</strong><br />This Policy outlines the handling of user information by CrowdFlix. You consent to the terms and data practices described herein by utilizing the services.</p>

                <strong>Data Collection:</strong>
                <ul>
                    <li><strong>Account Creation:</strong> Collects essential details to establish and manage your user account.</li>
                    <li><strong>Verification:</strong> Additional personal details may be required for identity verification, particularly for creators.</li>
                    <li><strong>Transactions:</strong> Partners handle payment processing; CrowdFlix retains minimal payment details for compliance and security purposes.</li>
                    <li><strong>Site Interaction and Analytics:</strong> Collects data on user interactions for service optimization, subject to opt-out provisions.</li>
                    <li><strong>User Communications:</strong> Includes all correspondence with CrowdFlix for support and feedback.</li>
                    <li><strong>Community Engagement:</strong> Data from user participation on the platform.</li>
                    <li><strong>Third-Party Integrations:</strong> Information from third-party platforms is used only with user permission and is subject to the third party&apos;s privacy policies.</li>
                </ul>

                <p><strong>Optional Data Provision:</strong><br />
                    Demographic Information: Users may choose to provide additional demographic details voluntarily.</p>

                <p><strong>Data Provision Implications:</strong><br />
                    Withholding information may restrict service use. Full-service use requires a complete user account.</p>

                <strong>Information Utilization:</strong>
                <ul>
                    <li><strong>Security and Verification:</strong> To safeguard the platform and validate user identities.</li>
                    <li><strong>Service Delivery and Customization:</strong> To provide personalized service experiences.</li>
                    <li><strong>Performance Monitoring:</strong> To evaluate and enhance the functionality of the services.</li>
                </ul>

                <p className='fs-5'><strong>Information Sharing Overview (CrowdFlix):</strong></p>

                <strong>Publicly Shared Information:</strong>
                <ul>
                    <li><strong>Profile Information:</strong> Usernames and account creation dates are basic on profiles. Profiles are private by default and can be made public at the user&apos;s discretion.</li>
                    <li><strong>Public Profile Content:</strong> If made public, profiles may show user-selected usernames, creation dates, profile additions (like photos and bio), backed or launched projects (excluding financial details), comments, and project update &apos;Likes&apos;.</li>
                    <li><strong>Anonymous Options:</strong> Users can choose non-identifiable usernames or images to maintain privacy on public profiles.</li>
                    <li><strong>Verified Names:</strong> Creators&apos; verified names are public on their profiles and projects post-verification.</li>
                </ul>

                <strong>Privately Held Information:</strong>
                <ul>
                    <li><strong>Sensitive Data:</strong> Payment information, passwords, IP addresses, phone numbers, birth dates, identity verification documents, and private profile settings are confidential.</li>
                    <li><strong>User Communications:</strong> Private messages and support-related communications are not publicly disclosed.</li>
                </ul>

                <strong>Third-Party Service Sharing:</strong>
                <ul>
                    <li><strong>Service Providers:</strong> Information may be shared with trusted partners to facilitate service provision, improvement, promotion, or security, with strict usage and protection guidelines.</li>
                    <li><strong>Aggregated Data:</strong> Non-identifying, aggregated information may be shared for analytical or promotional purposes.</li>
                </ul>

                <p><strong className='fs-5'>Shared to Protect CrowdFlix and Comply with the Law:</strong><br /></p>
                <p>We may disclose information to comply with legal obligations, enforce our rights, or protect our community.</p>

                <p><strong>External Links:</strong><br />
                    External websites linked to CrowdFlix have their privacy practices, which this Policy does not cover.</p>

                <p><strong>Retention:</strong><br />
                    Information is retained as long as necessary to provide services, comply with legal obligations, and protect CrowdFlix&apos;s legal rights.</p>

                <p><strong>Data Transfers:</strong><br />
                    Information is processed in the United States, and users must agree to our Terms of Use, which govern the contractual relationship.</p>

                <strong>Security Measures:</strong>
                <ul>
                    <li>Industry-standard practices, such as TLS encryption, are used to protect user data.</li>
                    <li>Users are encouraged to use strong passwords and enable two-factor authentication for additional security.</li>
                    <li>CrowdFlix has a Security Incident Response Team for data breaches and encourages responsible vulnerability disclosures.</li>
                </ul>

                <strong>Children&apos;s Privacy (CrowdFlix):</strong>
                <ul>
                    <li><strong>Usage Restrictions:</strong> Individuals under eight or the legal age in their jurisdiction are not allowed to use CrowdFlix independently.</li>
                    <li><strong>Data Collection Policy:</strong> CrowdFlix does not knowingly collect personal data from children under 16. Those under 16 cannot register for an account or use the services.</li>
                    <li><strong>Response to Data from Children:</strong> If CrowdFlix is contacted regarding personal information submitted by a child under 16, the information will be deleted.</li>
                </ul>
            </div>
        </div>
    );
}

export default PrivacyPolicyScreen;