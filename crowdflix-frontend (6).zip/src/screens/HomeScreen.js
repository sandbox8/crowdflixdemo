import React from "react";
import HeroSection from "../components/HeroSection";
import CharacterSection from "../components/CharacterSection";
import ComingSoonFeatures from "../components/ComingSoonFeatures";
import TieredPackCards from "../components/TieredPackCards";
import EnhancedFooter from "../components/EnhancedFooter";

const HomeScreen = () => {
  return (
    <div
      style={{
        width: "100%",
        minHeight: "100vh",
        background: "#000",
        fontFamily: "Outfit, sans-serif",
        overflow: "hidden",
      }}
    >
      {/* Hero Section with Search */}
      <HeroSection />

      {/* Discover Characters Section */}
      <CharacterSection />

      {/* Coming Soon Features Section */}
      <ComingSoonFeatures />

      {/* Tiered Pack Cards Section */}
      <TieredPackCards />

      {/* Enhanced Footer */}
      <EnhancedFooter />
    </div>
  );
};

export default HomeScreen;
