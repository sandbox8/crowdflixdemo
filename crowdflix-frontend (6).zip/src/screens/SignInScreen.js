import React, { useState, useEffect } from 'react';
import { Eye, EyeSlash } from 'react-bootstrap-icons';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { toast, ToastContainer, cssTransition } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

// Define a custom fade transition (make sure to add matching CSS)
const FadeTransition = cssTransition({
    enter: 'toast-fade-enter',
    exit: 'toast-fade-exit',
    duration: [300, 300]
});

import { signInWithEmailAndPassword } from 'firebase/auth';
import { useDispatch } from 'react-redux';
import { login } from '../features/user/userSlice';
import { auth } from '../firebase';

import crowdflix_logo from '../assets/images/crowdflix_logo.png';

function SignInScreen() {
    const navigate = useNavigate();
    const location = useLocation();
    const dispatch = useDispatch();

    const TOAST_CLOSE_TIMER = 4000;

    const [data, setData] = useState({
        email: '',
        password: ''
    });

    const [showPassword, setShowPassword] = useState(false);
    const handleTogglePassword = () => {
        setShowPassword((prevState) => !prevState);
    };

    const [error, setError] = useState('');

    useEffect(() => {
        if (location.state?.toastMessage) {
            toast.error(location.state.toastMessage, { autoClose: TOAST_CLOSE_TIMER });
        }
    }, [location]);

    const changeHandler = (e) => {
        if (error) setError('');
        setData({ ...data, [e.target.name]: e.target.value });
    };

    const checkUser = (e) => {
        e.preventDefault();

        signInWithEmailAndPassword(auth, data.email, data.password)
            .then((userCredential) => {
                const user = userCredential.user;
                dispatch(login({
                    id: user.uid,
                    email: user.email,
                    displayName: user.displayName,
                    profilePicture: user.photoURL,
                }));

                navigate(`/profile/${user.uid}`);
            })
            .catch((error) => {
                const errorCode = error.code;
                const errorMessage = error.message;
                console.log(errorCode, errorMessage);

                if (errorCode === 'auth/invalid-login-credentials') {
                    setError('Invalid email/password');
                }
            });
    };

    return (
        <div className="container">
            <ToastContainer
                autoClose={TOAST_CLOSE_TIMER}
                position="top-right"
                // hideProgressBar
                newestOnTop={false}
                closeOnClick
                draggable
                transition={FadeTransition}
                theme="dark"
            />
            <div className="row my-5">
                <div className="col-lg-6 d-none d-lg-flex align-items-center justify-content-center">
                    <img src={crowdflix_logo} style={{ maxHeight: '450px' }} alt="description" />
                </div>

                <div className="col-12 col-lg-6 d-flex justify-content-center align-items-center">
                    <div className="form-container d-flex justify-content-center align-items-center flex-column dark-bg rounded py-4">
                        <h3 className="text-white"><strong>Hi!</strong> Welcome Back!</h3>
                        <form
                            action=""
                            className="text-center p-4"
                            id="sign-in-form"
                            onSubmit={checkUser}
                        >
                            <input
                                name="email"
                                type="email"
                                placeholder="Email"
                                className="form-control bg-dark border-dark text-white mb-3"
                                required
                                value={data.email}
                                onChange={changeHandler}
                            />

                            <div className="input-group mb-2">
                                <input
                                    type={showPassword ? 'text' : 'password'}
                                    placeholder="Password"
                                    className="form-control bg-dark border-dark text-white"
                                    required
                                    data-testid="password-input"
                                    name="password"
                                    value={data.password}
                                    onChange={changeHandler}
                                />
                                <span
                                    className="btn btn-outline-secondary bg-dark border-0"
                                    type="button"
                                    onClick={handleTogglePassword}
                                    data-testid="toggle-password"
                                >
                                    {showPassword ? <EyeSlash color="#0069D9" /> : <Eye color="#0069D9" />}
                                </span>
                            </div>

                            <div className="text-end">
                                <Link className="my-link" to="/forgot-password">Forgot password?</Link>
                            </div>

                            {error && <div className="alert alert-danger w-100 mt-3">{error}</div>}

                            <button className="btn btn-primary px-4 mt-4" type="submit" id="signup-btn">
                                Login
                            </button>
                        </form>

                        <div>
                            <Link to="/sign-up" className="my-link">Don&apos;t have an account?</Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default SignInScreen;