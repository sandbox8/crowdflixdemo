import React from "react";
import Navbar from "../components/Navbar";
import MobileOptimizedFooter from "../components/MobileOptimizedFooter";

const MobileFooterDemoScreen = () => {
  return (
    <div className="mobile-footer-demo-screen">
      <Navbar />

      <div className="demo-content">
        <div className="demo-hero">
          <h1 className="demo-title">📱 Mobile-Optimized Footer Demo</h1>
          <p className="demo-description">
            A responsive footer component based on the Figma design, optimized
            for mobile devices but working beautifully across all screen sizes.
          </p>
        </div>

        <div className="demo-features">
          <div className="feature-card">
            <h3>✨ Features</h3>
            <ul>
              <li>
                <strong>Mobile-First Design:</strong> Perfect for mobile devices
              </li>
              <li>
                <strong>Responsive Layout:</strong> Adapts to all screen sizes
              </li>
              <li>
                <strong>Email Signup:</strong> Functional email subscription
                form
              </li>
              <li>
                <strong>Social Links:</strong> Instagram, Facebook, Twitter
                icons
              </li>
              <li>
                <strong>Navigation:</strong> Quick access to key pages
              </li>
              <li>
                <strong>Builder.io Ready:</strong> Available for drag-and-drop
              </li>
            </ul>
          </div>

          <div className="feature-card">
            <h3>🎨 Design Elements</h3>
            <ul>
              <li>CrowdFlix logo with proper branding</li>
              <li>Explore and Trade navigation buttons</li>
              <li>Email input with blue accent border</li>
              <li>Clean link hierarchy</li>
              <li>SVG social media icons</li>
              <li>Copyright notice</li>
            </ul>
          </div>

          <div className="feature-card">
            <h3>📱 Responsive Behavior</h3>
            <ul>
              <li>
                <strong>Mobile:</strong> Vertical stack layout
              </li>
              <li>
                <strong>Tablet:</strong> Email form becomes horizontal
              </li>
              <li>
                <strong>Desktop:</strong> Links arrange in grid
              </li>
              <li>
                <strong>Spacing:</strong> Adaptive gaps and padding
              </li>
              <li>
                <strong>Touch-Friendly:</strong> Larger tap targets
              </li>
            </ul>
          </div>
        </div>

        <div className="demo-spacer">
          <p>Scroll down to see the mobile-optimized footer in action! 👇</p>
        </div>
      </div>

      {/* Mobile Optimized Footer */}
      <MobileOptimizedFooter />
    </div>
  );
};

export default MobileFooterDemoScreen;
