import React, { useEffect, useState } from 'react';

import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

import Multiselect from 'multiselect-react-dropdown';
import { Form } from 'react-bootstrap';
// import { CardImage, CheckLg } from 'react-bootstrap-icons';
import { useNavigate } from "react-router-dom";

import { addDoc, arrayUnion, collection, serverTimestamp, doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';

import { useDispatch, useSelector } from 'react-redux';
import { selectCategories } from '../features/categories/categorySlice';
import { selectUser, updateUserDetails } from '../features/user/userSlice';

import crowdflix_logo from '../assets/images/crowdflix_logo.png';

import StepIndicator from '../components/StepIndicator';
import { addProject } from '../features/projects/projectSlice';

function StartProjectScreen() {
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const now = new Date();
    const oneMonthFromNow = new Date(now.getTime());
    oneMonthFromNow.setMonth(now.getMonth() + 1);

    const oneYearFromNow = new Date(now.getTime());
    oneYearFromNow.setFullYear(now.getFullYear() + 1);


    const user = useSelector(selectUser);
    useEffect(() => {
        if (!user) {
            navigate("/sign-in");
        }
    }, []);

    const [step, setStep] = useState(1);
    const stepsCount = 3;

    const [error, setError] = useState('');
    const [submitting, setSubmitting] = useState(false);

    const categories = useSelector(selectCategories);

    const [projectData, setProjectData] = useState({
        projectName: '',
        projectDescription: '',
        fundingGoal: '',
        selectedCategories: [],
        selectedFiles: [],
        projectImage: '',
        endDate: oneMonthFromNow,
    });

    const resetError = () => {
        if (error) setError('');
    };

    const nextStep = () => {
        setStep(step < stepsCount ? step + 1 : step);
    };

    const prevStep = () => {
        setStep(step > 1 ? step - 1 : step);
    };

    const handleChange = input => e => {
        resetError();
        setProjectData({ ...projectData, [input]: e.target.value });
    };

    const handleDateChange = (date) => {
        resetError();
        setProjectData({ ...projectData, endDate: date.getTime() }); // Store as milliseconds
    };


    const onSelect = (selectedList, selectedItem) => {
        resetError();
        setProjectData({ ...projectData, selectedCategories: selectedList });
    };

    const onRemove = (selectedList, removedItem) => {
        resetError();
        setProjectData({ ...projectData, selectedCategories: selectedList });
    };

    const formatFundingGoal = (value) => {
        const numericValue = parseFloat(value);

        if (!isNaN(numericValue)) {
            return `$${numericValue.toLocaleString()}`;
        } else {
            return value;
        }
    };

    const handleUploadClick = () => {
        const fileInput = document.getElementById('fileInput');
        if (fileInput) {
            fileInput.click();
        }
    };

    const handleFileSelect = (e) => {
        if (e.target.files && e.target.files.length > 0) {
            const file = e.target.files[0];
            setProjectData({ ...projectData, selectedFiles: file });
        } else {
            setProjectData({ ...projectData, selectedFiles: [] });
        }
    };

    const handleSubmit = async (e) => {
        const formData = {};

        formData.funded = 0;
        formData.projectCreator = user.displayName;
        formData.projectCreatorId = user.id;
        formData.backers = [];

        if (projectData.projectName.trim().length === 0) {
            e.preventDefault();
            setError('Project name is required');
            return;
        }
        formData.projectName = projectData.projectName;

        if (projectData.fundingGoal.trim().length === 0) {
            e.preventDefault();
            setError('Funding goal is required');
            return;
        }
        // Remove the first character ('$') from the fundingGoal string
        formData.fundingGoal = parseInt(projectData.fundingGoal.substring(1));

        if (projectData.selectedCategories.length === 0) {
            e.preventDefault();
            setError('A category is required');
            return;
        }
        formData.categories = projectData.selectedCategories;

        if (projectData.projectDescription.trim().length === 0) {
            e.preventDefault();
            setError('Project description is required');
            return;
        }
        formData.projectDescription = projectData.projectDescription;

        formData.endDate = projectData.endDate;

        // if (projectData.selectedFiles.length === 0 || projectData.selectedFiles === null) {
        //     formData.projectImage = '';
        // } else {
        //     formData.projectImage = 'img-url';
        // }
        if (projectData.projectImage.trim().length === 0) {
            e.preventDefault();
            setError('Project image is required');
            return;
        }
        formData.projectImage = projectData.projectImage;
        
        try {
            setSubmitting(true);

            // Add the new project to 'projects' collection
            const projDocRef = await addDoc(collection(db, "projects"), {
                ...formData,
                timestamp: serverTimestamp()
            });

            // Update the user's `createdProjects` array
            const userDocRef = doc(db, 'users', user.id);
            await updateDoc(userDocRef, {
                createdProjects: arrayUnion(projDocRef.id)
            });

            dispatch(updateUserDetails({
                userDetails: {
                    ...user,
                    createdProjects: [...user.createdProjects, projDocRef.id]
                }
            }));

            dispatch(addProject({
                newProject: {
                    ...formData,
                    id: projDocRef.id,
                }
            }));

            navigate(`/project/${projDocRef.id}`);
        } catch (error) {
            console.error("Error adding document: ", error);
            setError(error.message);
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <div className="container" id='start-project-screen'>
            <div className="row my-5">
                <div className="col-lg-6 d-none d-lg-flex align-items-center justify-content-center">
                    <img src={crowdflix_logo} style={{ maxHeight: '450px' }} alt="Start your project" />
                </div>
                <div className="col-12 col-lg-6 d-flex justify-content-center align-items-center">
                    <div className="form-container d-flex justify-content-center align-items-center flex-column dark-bg rounded py-4">
                        <h1 className='fs-1 text-white'>Let&apos;s get <strong>STARTED!</strong></h1>

                        <Form
                            className="p-4 d-flex flex-column justify-content-between"
                            id='start-project-form'
                        >
                            {step === 1 && (
                                <div className="">
                                    <input
                                        name="projectNameStep1"
                                        type="text"
                                        placeholder="Project Name"
                                        className="form-control bg-dark border-dark text-white mb-3"
                                        value={projectData.projectName}
                                        onChange={handleChange('projectName')}
                                    />

                                    <textarea
                                        name="descriptionStep2"
                                        rows={4}
                                        maxLength={750}
                                        placeholder="Project Description (750 characters)"
                                        className="form-control bg-dark border-dark text-white mb-3"
                                        value={projectData.projectDescription}
                                        onChange={handleChange('projectDescription')}
                                    />

                                    <input
                                        name="projectImageStep2"
                                        type="text"
                                        placeholder="Link to Project Image"
                                        className="form-control bg-dark border-dark text-white mb-3"
                                        value={projectData.projectImage}
                                        onChange={handleChange('projectImage')}
                                    />

                                    <Multiselect
                                        className='mb-3 text-white'
                                        options={categories}
                                        selectedValues={projectData.selectedCategories}
                                        onSelect={onSelect}
                                        placeholder={projectData.selectedCategories.length === 0 ? 'Category' : ''}
                                        onRemove={onRemove}
                                        displayValue="category"
                                        showCheckbox
                                        style={{
                                            chips: {
                                                background: '#0069D9',
                                            },
                                            searchBox: {
                                                background: '#24262a',
                                                border: 'none',
                                                paddingLeft: '10px',
                                                paddingRight: '10px',
                                                caretColor: 'white',
                                            },
                                            optionContainer: {
                                                background: '#24262a',
                                                border: 'none',
                                                borderRadius: 0
                                            },
                                            option: {
                                                color: '#fff',
                                                background: '#24262a'
                                            }
                                        }}
                                    />
                                </div>
                            )}
                            {step === 2 && (
                                <div>

                                    <input
                                        name="fundingGoalStep1"
                                        type="text"
                                        placeholder="Funding Goal (USD)"
                                        className="form-control bg-dark border-dark text-white mb-3"
                                        value={formatFundingGoal(projectData.fundingGoal)}
                                        onChange={handleChange('fundingGoal')}
                                    />

                                    <div className="div d-flex align-items-center justify-content-between text-white">
                                        <div className="mx-2">Project End date:</div>
                                        <DatePicker
                                            selected={new Date(projectData.endDate)}
                                            onChange={handleDateChange}
                                            minDate={new Date(oneMonthFromNow)}
                                            maxDate={new Date(oneYearFromNow)}
                                            className="form-control bg-dark border-dark text-white w-100"
                                            placeholderText="Select an end date"
                                        />
                                    </div>

                                    {/* <div className="form-control bg-dark border-dark justify-content-center p-4 d-flex flex-column align-items-center placeholder-text mb-3"
                                        id='image-video-upload'
                                        onClick={handleUploadClick}
                                    >
                                        <input
                                            id="fileInput"
                                            type="file"
                                            name="projectFiles"
                                            accept="image/*,video/*"
                                            onChange={handleFileSelect}
                                            // multiple
                                            className="form-control bg-dark border-dark text-white mb-3"
                                            style={{ display: 'none' }}
                                        />

                                        {projectData.selectedFiles.length === 0 || projectData.selectedFiles === null
                                            ? <div className=" text-center">
                                                <CardImage size={48} />
                                                <div>Upload an image or video</div>
                                            </div>
                                            : <div className="text-center">
                                                <CheckLg className='text-success' size={48} />
                                                <div>Uploaded!</div>
                                            </div>}
                                    </div> */}
                                </div>

                            )}
                            {step === 3 && (
                                <div className="">
                                    <div className="alert alert-info h-75 text-black ">
                                        <p className='text-black text-justify'>Keep in mind that transaction fees including credit and debit charges are deducted from each investment. Make sure to have a bank account and mailing address with proper documents Also by continuing you agree to following conditions:</p>

                                        <ul className='text-black'>
                                            <li><strong>I am at least 18 years old</strong></li>
                                            <li><strong>I can verify a government issued ID</strong></li>
                                            <li><strong>I can verify the legitimacy of the project</strong></li>
                                        </ul>
                                    </div>

                                    {error && <div className="alert alert-danger col-mb-6 w-100">{error}</div>}
                                </div>

                            )}

                            <div className={`d-flex ${step === 1 ? 'justify-content-end' : 'justify-content-between'}`}>
                                {step > 1 && (
                                    <button className="btn btn-secondary" type="button" onClick={prevStep}>
                                        Previous
                                    </button>
                                )}
                                {step < stepsCount ? (
                                    <button className="btn btn-primary" type="button" onClick={nextStep}>
                                        Next
                                    </button>
                                ) : (
                                    <button
                                        className="btn btn-primary"
                                        type="button"
                                        onClick={handleSubmit}
                                        disabled={submitting}
                                    >
                                        Submit
                                    </button>
                                )}
                            </div>
                        </Form>

                        <StepIndicator steps={stepsCount} currentStep={step} />
                    </div>
                </div>
            </div>
        </div>
    );
}

export default StartProjectScreen;
