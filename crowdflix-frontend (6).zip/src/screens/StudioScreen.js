import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import StudioHeader from "../components/StudioHeader";
import StudioContent from "../components/StudioContent";
import StudioSidebar from "../components/StudioSidebar";

const StudioScreen = () => {
  const { studioSlug } = useParams();
  const [activeTab, setActiveTab] = useState("moments");
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(true);

  // Sample studio data - would come from API
  const studioData = {
    a24: {
      id: "a24",
      name: "A24",
      slug: "a24",
      tagline: "Uncompromising. Authentic. Boundary-pushing.",
      description:
        "Independent studio creating films that matter. From Moonlight to Everything Everywhere All at Once.",
      logo: "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F6607286236984051a11f108bbc22662e",
      banner:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F35be60d44b714f869e2fd177463466d3",
      verified: true,
      followers: 127843,
      totalMoments: 89,
      activePacksCount: 12,
      founded: "2012",
      headquarters: "New York, NY",
      website: "https://a24films.com",
      socialLinks: {
        twitter: "@A24",
        instagram: "@a24",
      },
      stats: {
        totalRevenue: "$2.4M",
        topMoment: "Everything Everywhere All at Once",
        avgPrice: "$24.50",
        mostPopular: "Hereditary Door Slam",
      },
      recentMoments: [
        {
          id: "eeaao-bagel",
          title: "The Everything Bagel",
          film: "Everything Everywhere All at Once",
          price: "$156.00",
          rarity: "immortal",
          thumbnail:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F35be60d44b714f869e2fd177463466d3",
          emotion: "🤯 Mind-bending",
        },
        {
          id: "hereditary-door",
          title: "The Door Slam",
          film: "Hereditary",
          price: "$89.00",
          rarity: "legendary",
          thumbnail:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F5a1c0dbf6e324f6a88e34e2230cae9b7",
          emotion: "😱 Terror",
        },
        {
          id: "moonlight-beach",
          title: "Beach Conversation",
          film: "Moonlight",
          price: "$67.00",
          rarity: "epic",
          thumbnail:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F6ebffc23d7d44c2190d242565dd9fdb9",
          emotion: "💙 Identity",
        },
      ],
      activePacks: [
        {
          id: "a24-horror-pack",
          name: "A24 Horror Collection",
          description: "The most terrifying moments from our horror catalog",
          price: "$49.99",
          totalMoments: 15,
          ownedMoments: 3,
          rarity: "legendary",
          thumbnail:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F12d9e666c7e049b6a4d62f67ffdc2e27",
        },
        {
          id: "a24-drama-pack",
          name: "Emotional Masterpieces",
          description: "Heart-wrenching performances that defined a generation",
          price: "$39.99",
          totalMoments: 12,
          ownedMoments: 0,
          rarity: "epic",
          thumbnail:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fa3cb973601e7471a9b4d0c02a2bafd37",
        },
      ],
      updates: [
        {
          id: "update-1",
          title: "New Horror Pack Dropping Tomorrow",
          content:
            "Our most terrifying moments collection goes live at midnight EST. First 1000 collectors get exclusive variant covers.",
          timestamp: "2 hours ago",
          type: "announcement",
          engagement: 247,
        },
        {
          id: "update-2",
          title: "Behind the Scenes: Everything Everywhere",
          content:
            "Go inside the making of our most successful moment drop with exclusive director commentary and unseen footage.",
          timestamp: "1 day ago",
          type: "content",
          engagement: 892,
        },
        {
          id: "update-3",
          title: "Community Spotlight: Fan Art Contest",
          content:
            "Incredible fan creations inspired by A24 moments. Winners get exclusive early access to our next collection.",
          timestamp: "3 days ago",
          type: "community",
          engagement: 156,
        },
      ],
    },
    marvel: {
      id: "marvel",
      name: "Marvel Studios",
      slug: "marvel",
      tagline: "The most ambitious cinematic universe ever.",
      description:
        "Creating interconnected superhero stories that captivate audiences worldwide.",
      logo: "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F8f0b5b6d419f455392efe8a069e5b192",
      banner:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F1af024ccf9ef4c6db837dc7c19bdbc56",
      verified: true,
      followers: 2847291,
      totalMoments: 456,
      activePacksCount: 34,
      founded: "2008",
      headquarters: "Burbank, CA",
      website: "https://marvelstudios.com",
      socialLinks: {
        twitter: "@MarvelStudios",
        instagram: "@marvelstudios",
      },
      stats: {
        totalRevenue: "$15.2M",
        topMoment: "Avengers Assemble",
        avgPrice: "$42.30",
        mostPopular: "Iron Man Snap",
      },
      recentMoments: [
        {
          id: "iron-man-snap",
          title: "I Am Iron Man",
          film: "Avengers: Endgame",
          price: "$299.00",
          rarity: "immortal",
          thumbnail:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F35be60d44b714f869e2fd177463466d3",
          emotion: "⚡ Epic",
        },
        {
          id: "thor-entrance",
          title: "Thor's Entrance",
          film: "Avengers: Infinity War",
          price: "$189.00",
          rarity: "legendary",
          thumbnail:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F5a1c0dbf6e324f6a88e34e2230cae9b7",
          emotion: "⚡ Thunder",
        },
      ],
      activePacks: [
        {
          id: "marvel-infinity-pack",
          name: "Infinity Saga Collection",
          description: "Epic moments from the culmination of the MCU",
          price: "$89.99",
          totalMoments: 25,
          ownedMoments: 5,
          rarity: "legendary",
          thumbnail:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F12d9e666c7e049b6a4d62f67ffdc2e27",
        },
      ],
      updates: [
        {
          id: "marvel-update-1",
          title: "Phase 5 Moments Coming Soon",
          content:
            "Get ready for the next chapter of the MCU with exclusive moments from our upcoming releases.",
          timestamp: "1 day ago",
          type: "announcement",
          engagement: 1247,
        },
      ],
    },
  };

  const currentStudio = studioData[studioSlug] || studioData.a24;

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setLoading(false);
    }, 800);

    return () => clearTimeout(timer);
  }, [studioSlug]);

  const handleFollow = () => {
    setIsFollowing(!isFollowing);
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  if (loading) {
    return (
      <div className="studio-screen loading">
        <div className="studio-loading">
          <div className="loading-spinner"></div>
          <p>Loading {currentStudio.name}...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="studio-screen">
      {/* Studio Header */}
      <StudioHeader
        studio={currentStudio}
        isFollowing={isFollowing}
        onFollow={handleFollow}
      />

      {/* Main Content */}
      <div className="studio-main">
        <div className="studio-main__content">
          <StudioContent
            studio={currentStudio}
            activeTab={activeTab}
            onTabChange={handleTabChange}
          />
        </div>

        <div className="studio-main__sidebar">
          <StudioSidebar studio={currentStudio} />
        </div>
      </div>
    </div>
  );
};

export default StudioScreen;
