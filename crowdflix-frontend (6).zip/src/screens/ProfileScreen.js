import React, { useState } from "react";
import { Link } from "react-router-dom";
import PropTypes from "prop-types";

// Enhanced moment data with metadata for fan title and tag computation
const sampleMoments = [
  {
    id: 1,
    title: '"I am Iron Man" - Tony Stark',
    creator: "RingBearer42",
    image:
      "https://cdn.builder.io/api/v1/image/assets/TEMP/392c23981a1ba4a806624e3c38b765e54eea65bd",
    lowestAsk: "$25,950.00",
    avgSale: "$28,400.00",
    sold: "9,854",
    total: "12,000",
    tier: "Legendary",
    movie: { universe: "Marvel", franchise: "Iron Man" },
    genre: ["Action", "Sci-Fi"],
    characters: ["Tony Stark", "Iron Man"],
    hasCreatorPic: false,
  },
  {
    id: 2,
    title: "The Snap - Avengers: Endgame",
    creator: "RingBearer42",
    image:
      "https://cdn.builder.io/api/v1/image/assets/TEMP/ea88a267200b7dc1e4b87644bb23269578ea6c41",
    lowestAsk: "$31,200.00",
    avgSale: "$35,800.00",
    sold: "7,234",
    total: "8,500",
    tier: "Legendary",
    movie: { universe: "Marvel", franchise: "Avengers" },
    genre: ["Action", "Drama"],
    characters: ["Thanos", "Tony Stark"],
    hasCreatorPic: true,
  },
  {
    id: 3,
    title: "Godzilla vs Kong - Final Battle",
    creator: "RingBearer42",
    image:
      "https://cdn.builder.io/api/v1/image/assets/TEMP/392c23981a1ba4a806624e3c38b765e54eea65bd",
    lowestAsk: "$450.00",
    avgSale: "$520.00",
    sold: "15,432",
    total: "25,000",
    tier: "Ultimate",
    movie: { universe: "Kaiju", franchise: "MonsterVerse" },
    genre: ["Action", "Monster"],
    characters: ["Godzilla", "Kong"],
    hasCreatorPic: false,
  },
  {
    id: 4,
    title: "Luffy Gear 5 - One Piece",
    creator: "RingBearer42",
    image:
      "https://cdn.builder.io/api/v1/image/assets/TEMP/ea88a267200b7dc1e4b87644bb23269578ea6c41",
    lowestAsk: "$890.00",
    avgSale: "$1,200.00",
    sold: "12,543",
    total: "18,000",
    tier: "Ultimate",
    movie: { universe: "Anime", franchise: "One Piece" },
    genre: ["Animation", "Adventure"],
    characters: ["Monkey D. Luffy"],
    hasCreatorPic: true,
  },
  {
    id: 5,
    title: "The Batman - Riddler Chase",
    creator: "RingBearer42",
    image:
      "https://cdn.builder.io/api/v1/image/assets/TEMP/392c23981a1ba4a806624e3c38b765e54eea65bd",
    lowestAsk: "$180.00",
    avgSale: "$220.00",
    sold: "8,765",
    total: "15,000",
    tier: "Fan",
    movie: { universe: "DC", franchise: "Batman" },
    genre: ["Action", "Crime"],
    characters: ["Batman", "The Riddler"],
    hasCreatorPic: false,
  },
  {
    id: 6,
    title: "Dune - Paul vs Feyd-Rautha",
    creator: "RingBearer42",
    image:
      "https://cdn.builder.io/api/v1/image/assets/TEMP/ea88a267200b7dc1e4b87644bb23269578ea6c41",
    lowestAsk: "$2,100.00",
    avgSale: "$2,450.00",
    sold: "3,421",
    total: "5,000",
    tier: "Legendary",
    movie: { universe: "A24", franchise: "Dune" },
    genre: ["Sci-Fi", "Drama"],
    characters: ["Paul Atreides", "Feyd-Rautha"],
    hasCreatorPic: true,
  },
  {
    id: 7,
    title: "Spirited Away - No Face",
    creator: "RingBearer42",
    image:
      "https://cdn.builder.io/api/v1/image/assets/TEMP/392c23981a1ba4a806624e3c38b765e54eea65bd",
    lowestAsk: "$650.00",
    avgSale: "$780.00",
    sold: "18,234",
    total: "20,000",
    tier: "Ultimate",
    movie: { universe: "Anime", franchise: "Studio Ghibli" },
    genre: ["Animation", "Fantasy"],
    characters: ["Chihiro", "No Face"],
    hasCreatorPic: false,
  },
  {
    id: 8,
    title: "John Wick - Continental Hotel",
    creator: "RingBearer42",
    image:
      "https://cdn.builder.io/api/v1/image/assets/TEMP/ea88a267200b7dc1e4b87644bb23269578ea6c41",
    lowestAsk: "$340.00",
    avgSale: "$410.00",
    sold: "11,876",
    total: "16,500",
    tier: "Fan",
    movie: { universe: "Action", franchise: "John Wick" },
    genre: ["Action", "Thriller"],
    characters: ["John Wick", "Winston"],
    hasCreatorPic: true,
  },
];

// User profile data - would come from Firestore/API in real app
const userProfile = {
  profileImage:
    "https://cdn.builder.io/api/v1/image/assets/TEMP/5f169eedaef56da042fcfbf6a0bb57dfb38ee65b",
  username: "James Blackwood",
  joinedDate: new Date("2024-11-01"),
  location: "United States",
  ownedMoments: sampleMoments, // In real app, this would be filtered from Firestore
};

// Fan Title Logic Component
function getFanTitle(ownedMoments) {
  const tierCounts = countByTier(ownedMoments);
  const franchises = extractUniqueFranchises(ownedMoments);

  // Legendary collector if 3+ legendary moments
  if (tierCounts.Legendary >= 3) return "Legendary Sci-Fi Collector";

  // Indie archivist if owns A24 moments
  if (includesFranchise(ownedMoments, "A24")) return "Indie Archivist";

  // Anime collector if 2+ anime moments
  if (
    franchises.filter((f) => ["One Piece", "Studio Ghibli"].includes(f))
      .length >= 2
  )
    return "Anime Enthusiast";

  // Marvel collector if 2+ Marvel moments
  if (tierCounts.Marvel >= 2) return "Marvel Superfan";

  // Default title
  return "Cinematic Explorer";
}

function extractTags(ownedMoments) {
  const tags = new Set();
  ownedMoments.forEach((m) => {
    if (m.movie.universe) tags.add(m.movie.universe);
    if (m.tier) tags.add(m.tier);
    if (m.genre) m.genre.forEach((g) => tags.add(g));
  });
  return Array.from(tags).slice(0, 6); // Limit to 6 tags for clean UI
}

function countByTier(ownedMoments) {
  return ownedMoments.reduce((acc, moment) => {
    acc[moment.tier] = (acc[moment.tier] || 0) + 1;
    if (moment.movie.universe === "Marvel") {
      acc.Marvel = (acc.Marvel || 0) + 1;
    }
    return acc;
  }, {});
}

function extractUniqueFranchises(ownedMoments) {
  return [...new Set(ownedMoments.map((m) => m.movie.franchise))];
}

function includesFranchise(ownedMoments, franchise) {
  return ownedMoments.some((m) => m.movie.franchise === franchise);
}

function getTopTierMoments(ownedMoments, count = 3) {
  const tierOrder = { Legendary: 4, Ultimate: 3, Fan: 2, Moments: 1 };
  return ownedMoments
    .sort((a, b) => (tierOrder[b.tier] || 0) - (tierOrder[a.tier] || 0))
    .slice(0, count);
}

// Moment Card Component
const MomentCard = ({ moment }) => {
  return (
    <Link to={`/moment/iron-man-reveal`} className="profile-moment-card-link">
      <div className="profile-moment-card">
        <div className="profile-moment-card-background">
          <div className="profile-moment-card-inner">
            {moment.hasCreatorPic ? (
              <div className="profile-moment-image-container">
                <div className="profile-moment-image-mask">
                  <img
                    src={moment.image}
                    alt={moment.title}
                    className="profile-moment-image-centered"
                  />
                </div>
              </div>
            ) : (
              <img
                src={moment.image}
                alt={moment.title}
                className="profile-moment-image"
              />
            )}

            <div className="profile-moment-tier-badge">
              <span>{moment.tier}</span>
            </div>

            {moment.hasCreatorPic && (
              <div className="profile-moment-creator-pic">
                <div className="profile-moment-creator-circle">
                  <div className="profile-moment-creator-inner"></div>
                </div>
              </div>
            )}

            <div className="profile-moment-content">
              <div className="profile-moment-title-section">
                <h3 className="profile-moment-title">{moment.title}</h3>
                <p className="profile-moment-creator">{moment.creator}</p>
              </div>

              {/* Figma Price Component */}
              <div className="figma-price-component">
                <div className="price-left-info">
                  <div className="lowest-ask-section">
                    <div className="price-category-label">LOWEST ASK</div>
                    <div className="price-display-main">
                      <span className="price-amount">
                        ${moment.lowestAsk.split(".")[0]}
                      </span>
                      <span className="price-cents">
                        .{moment.lowestAsk.split(".")[1]}
                      </span>
                      <span className="currency-label">USD</span>
                    </div>
                  </div>
                  <div className="sub-info-row">
                    <div className="avg-sale-info">
                      <span className="sub-label">AVG SALE</span>
                      <span className="sub-value">{moment.avgSale} USD</span>
                    </div>
                    <div className="for-sale-info">
                      <span className="sub-label">FOR SALE</span>
                      <span className="sub-value">{moment.sold}</span>
                    </div>
                  </div>
                </div>
                <div className="price-right-actions">
                  <div className="share-button">
                    <span className="share-text">SHARE</span>
                    <svg
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <g opacity="0.6">
                        <path
                          d="M7 7V6C7 4.34315 8.34315 3 10 3H18C19.6569 3 21 4.34315 21 6V14C21 15.6569 19.6569 17 18 17H17"
                          stroke="white"
                          strokeWidth="1.15"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          fillRule="evenodd"
                          clipRule="evenodd"
                          d="M3 10.1111V17.8889C3 19.6071 4.39289 21 6.11111 21H13.8889C15.6071 21 17 19.6071 17 17.8889V10.1111C17 8.39289 15.6071 7 13.8889 7H6.11111C4.39289 7 3 8.39289 3 10.1111Z"
                          stroke="white"
                          strokeWidth="1.15"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M8 16L12 12"
                          stroke="white"
                          strokeWidth="1.15"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M8 12H12V16"
                          stroke="white"
                          strokeWidth="1.15"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </g>
                    </svg>
                  </div>
                  <div className="select-buy-button">
                    <span>Select and Buy</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

function ProfileScreen() {
  const [activeTab, setActiveTab] = useState("Overview");
  const [searchTerm, setSearchTerm] = useState("");

  const tabs = [
    "Overview",
    "Moments",
    "Packs",
    "Leaderboards",
    "Showcase",
    "Wishlist",
  ];

  // Computed values for fandom identity
  const fanTitle = getFanTitle(userProfile.ownedMoments);
  const fandomTags = extractTags(userProfile.ownedMoments);
  const tierCounts = countByTier(userProfile.ownedMoments);
  const uniqueFranchises = extractUniqueFranchises(userProfile.ownedMoments);
  const uniqueCharacters = [
    ...new Set(userProfile.ownedMoments.flatMap((m) => m.characters)),
  ];
  const topTierMoments = getTopTierMoments(userProfile.ownedMoments);

  // Collection stats
  const totalMoments = userProfile.ownedMoments.length;
  const legendaryCount = tierCounts.Legendary || 0;
  const franchiseCount = uniqueFranchises.length;
  const characterCount = uniqueCharacters.length;
  const collectionRate = Math.round((totalMoments / 50) * 100); // Assuming 50 is max collection

  const formatJoinedDate = (date) => {
    return date.toLocaleDateString("en-US", { month: "long", year: "numeric" });
  };

  const copyProfileUrl = () => {
    const url = `${window.location.origin}/profile/${userProfile.username.toLowerCase().replace(" ", "-")}`;
    navigator.clipboard.writeText(url);
    // You could add a toast notification here
  };

  return (
    <div className="profile-screen">
      {/* Hero Background */}
      <div className="profile-hero-background">
        <div className="profile-hero-overlay"></div>
        <div className="profile-hero-blur-effects">
          <img
            className="profile-hero-blur-1"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/e36b69b47bfef1788c2ca05f3750a1463f119594"
            alt=""
          />
          <img
            className="profile-hero-blur-2"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/3af1d5ea9d8009e9f0177d1ca07c89df964acc76"
            alt=""
          />
          <img
            className="profile-hero-blur-3"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/013e359d623e4664561d6e93c99224a187da922a"
            alt=""
          />
          <img
            className="profile-hero-blur-4"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/bd04ee1fd84b5a5923f77b8807116f03e5d23e54"
            alt=""
          />
        </div>
      </div>

      {/* Profile Avatar */}
      <div className="profile-avatar-container">
        <div className="profile-avatar-wrapper">
          <div className="profile-avatar-inner">
            <img
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/5f169eedaef56da042fcfbf6a0bb57dfb38ee65b"
              alt="James Blackwood"
              className="profile-avatar-image"
            />
          </div>
        </div>
      </div>

      {/* Profile Info */}
      <div className="profile-info-container">
        <h1 className="profile-name">{userProfile.username}</h1>

        <div className="profile-location-info">
          <div className="profile-location-badge">
            <svg
              className="profile-us-flag"
              width="17"
              height="17"
              viewBox="0 0 17 17"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <g clipPath="url(#clip0_12_13141)">
                <mask
                  id="mask0_12_13141"
                  style={{ maskType: "luminance" }}
                  maskUnits="userSpaceOnUse"
                  x="0"
                  y="0"
                  width="17"
                  height="17"
                >
                  <path
                    d="M8.5 16.5C12.9183 16.5 16.5 12.9183 16.5 8.5C16.5 4.08172 12.9183 0.5 8.5 0.5C4.08172 0.5 0.5 4.08172 0.5 8.5C0.5 12.9183 4.08172 16.5 8.5 16.5Z"
                    fill="white"
                  />
                </mask>
                <g mask="url(#mask0_12_13141)">
                  <path
                    d="M8.5 0.5H16.5V2.5L15.5 3.5L16.5 4.5V6.5L15.5 7.5L16.5 8.5V10.5L15.5 11.5L16.5 12.5V14.5L8.5 15.5L0.5 14.5V12.5L1.5 11.5L0.5 10.5V8.5L8.5 0.5Z"
                    fill="#EEEEEE"
                  />
                  <path
                    d="M7.5 2.5H16.5V4.5H7.5V2.5ZM7.5 6.5H16.5V8.5H8.5L7.5 6.5ZM0.5 10.5H16.5V12.5H0.5V10.5ZM0.5 14.5H16.5V16.5H0.5V14.5Z"
                    fill="#D80027"
                  />
                  <path d="M0.5 0.5H8.5V8.5H0.5V0.5Z" fill="#0052B4" />
                  <path
                    d="M6.34375 8.09375L8.125 6.8125H5.9375L7.71875 8.09375L7.03125 6L6.34375 8.09375ZM3.8125 8.09375L5.59375 6.8125H3.40625L5.1875 8.09375L4.5 6L3.8125 8.09375ZM1.28125 8.09375L3.0625 6.8125H0.875L2.65625 8.09375L1.96875 6L1.28125 8.09375ZM6.34375 5.5625L8.125 4.28125H5.9375L7.71875 5.5625L7.03125 3.46875L6.34375 5.5625ZM3.8125 5.5625L5.59375 4.28125H3.40625L5.1875 5.5625L4.5 3.46875L3.8125 5.5625ZM1.28125 5.5625L3.0625 4.28125H0.875L2.65625 5.5625L1.96875 3.46875L1.28125 5.5625ZM6.34375 3L8.125 1.71875H5.9375L7.71875 3L7.03125 0.90625L6.34375 3ZM3.8125 3L5.59375 1.71875H3.40625L5.1875 3L4.5 0.90625L3.8125 3ZM1.28125 3L3.0625 1.71875H0.875L2.65625 3L1.96875 0.90625L1.28125 3Z"
                    fill="#EEEEEE"
                  />
                </g>
              </g>
              <defs>
                <clipPath id="clip0_12_13141">
                  <rect
                    width="16"
                    height="16"
                    fill="white"
                    transform="translate(0.5 0.5)"
                  />
                </clipPath>
              </defs>
            </svg>
            <span className="profile-location-text">
              <span className="profile-location-country">
                {userProfile.location} |
              </span>
              <span className="profile-location-joined">
                Joined {formatJoinedDate(userProfile.joinedDate)}
              </span>
            </span>
          </div>
        </div>

        <div className="profile-action-buttons">
          <button className="profile-edit-button">
            <svg
              width="18"
              height="18"
              viewBox="0 0 18 18"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M18.0267 20.2916C17.8858 20.4326 17.774 20.5999 17.6978 20.7841C17.6216 20.9683 17.5824 21.1657 17.5825 21.365V23.5H19.7309C20.1334 23.5 20.52 23.34 20.805 23.055L27.1384 16.7183C27.2796 16.5774 27.3916 16.4101 27.4681 16.2258C27.5445 16.0416 27.5839 15.844 27.5839 15.6446C27.5839 15.4451 27.5445 15.2475 27.4681 15.0633C27.3916 14.879 27.2796 14.7117 27.1384 14.5708L26.5125 13.945C26.3716 13.8036 26.2042 13.6915 26.0199 13.6149C25.8356 13.5384 25.6379 13.499 25.4384 13.499C25.2388 13.499 25.0412 13.5384 24.8568 13.6149C24.6725 13.6915 24.5051 13.8036 24.3642 13.945L18.0267 20.2916Z"
                stroke="#FFC03F"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M27.5825 21C27.5825 24.5358 27.5825 26.3033 26.4842 27.4017C25.3859 28.5 23.6175 28.5 20.0825 28.5C16.5475 28.5 14.7792 28.5 13.6809 27.4017C12.5825 26.3033 12.5825 24.535 12.5825 21C12.5825 17.465 12.5825 15.6967 13.6809 14.5983C14.7792 13.5 16.5475 13.5 20.0825 13.5"
                stroke="#FFC03F"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>

          <button className="profile-share-button" onClick={copyProfileUrl}>
            <svg
              width="18"
              height="18"
              viewBox="0 0 19 18"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <g clipPath="url(#clip0_12_13160)">
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M17.3749 3.37501C17.3758 4.07451 17.1591 4.75699 16.7548 5.3278C16.3504 5.89862 15.7785 6.32949 15.1183 6.56068C14.4581 6.79188 13.7424 6.81193 13.0703 6.61807C12.3982 6.42421 11.803 6.02604 11.3674 5.47876L7.0586 7.87501C7.18348 8.22713 7.25098 8.60513 7.25098 9.00001C7.25098 9.39488 7.18348 9.77288 7.0586 10.125L11.3674 12.5213C11.803 11.974 12.3982 11.5758 13.0703 11.3819C13.7424 11.1881 14.4581 11.2081 15.1183 11.4393C15.7785 11.6705 16.3504 12.1014 16.7548 12.6722C17.1591 13.243 17.3758 13.9255 17.3749 14.625C17.3749 16.4925 15.8674 18 13.9999 18C13.4595 18.0011 12.9268 17.8723 12.4467 17.6245C11.9665 17.3766 11.553 17.0169 11.241 16.5757C10.929 16.1346 10.7276 15.6249 10.6539 15.0896C10.5801 14.5543 10.6362 14.0091 10.8172 13.5L6.50848 11.1038C6.07282 11.651 5.47768 12.0492 4.80558 12.2431C4.13347 12.4369 3.4177 12.4169 2.7575 12.1857C2.0973 11.9545 1.52539 11.5236 1.12107 10.9528C0.716739 10.382 0.500028 9.69951 0.50098 9.00001C0.500028 8.3005 0.716739 7.61803 1.12107 7.04721C1.52539 6.4764 2.0973 6.04552 2.7575 5.81433C3.4177 5.58314 4.13347 5.56308 4.80558 5.75694C5.47768 5.95081 6.07282 6.34898 6.50848 6.89626L10.8172 4.50001C10.6362 3.99091 10.5801 3.44573 10.6539 2.91044C10.7276 2.37515 10.929 1.86544 11.241 1.42428C11.553 0.983117 11.9665 0.623437 12.4467 0.375562C12.9268 0.127687 13.4595 -0.0011177 13.9999 7.30663e-06C15.8674 7.30663e-06 17.3749 1.50751 17.3749 3.37501Z"
                  fill="#2AA2FD"
                />
              </g>
              <defs>
                <clipPath id="clip0_12_13160">
                  <rect
                    width="18"
                    height="18"
                    fill="white"
                    transform="translate(0.5)"
                  />
                </clipPath>
              </defs>
            </svg>
          </button>
        </div>
      </div>

      {/* Fandom Identity Header */}
      <div className="fandom-identity-header">
        <div className="fandom-identity-content">
          <div className="fan-title-section">
            <h2 className="fan-title">{fanTitle}</h2>
            <div className="fandom-tags">
              {fandomTags.map((tag, index) => (
                <span
                  key={index}
                  className={`fandom-tag ${tag.toLowerCase().replace(" ", "-")}`}
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>

          <div className="collection-stats-mini">
            <div className="stat-item">
              <span className="stat-emoji">🔥</span>
              <span className="stat-value">{legendaryCount}</span>
              <span className="stat-label">Legendary</span>
            </div>
            <div className="stat-item">
              <span className="stat-emoji">🎬</span>
              <span className="stat-value">{franchiseCount}</span>
              <span className="stat-label">Franchises</span>
            </div>
            <div className="stat-item">
              <span className="stat-emoji">🎭</span>
              <span className="stat-value">{characterCount}</span>
              <span className="stat-label">Characters</span>
            </div>
            <div className="stat-item">
              <span className="stat-emoji">🏆</span>
              <span className="stat-value">{collectionRate}%</span>
              <span className="stat-label">Complete</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="profile-tabs-container">
        {tabs.map((tab) => (
          <button
            key={tab}
            className={`profile-tab ${activeTab === tab ? "profile-tab-active" : ""}`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Search and Filter */}
      <div className="profile-search-container">
        <div className="profile-search-input">
          <svg
            width="18"
            height="18"
            viewBox="0 0 18 18"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M15.747 7.187C18.663 10.103 18.663 14.831 15.747 17.747C12.831 20.663 8.103 20.663 5.187 17.747C2.271 14.831 2.271 10.103 5.187 7.187C8.103 4.271 12.831 4.271 15.747 7.187"
              stroke="#FFC03F"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M19 19L15.75 15.75"
              stroke="#FFC03F"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <input
            type="text"
            placeholder="Search"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <button className="profile-filter-button">
          <svg
            width="18"
            height="18"
            viewBox="0 0 18 18"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M11.5 10.5L16.707 5.293C16.895 5.105 17 4.851 17 4.586V2C17 1.448 16.552 1 16 1H2C1.448 1 1 1.448 1 2V4.586C1 4.851 1.105 5.106 1.293 5.293L6.5 10.5"
              stroke="#2AA2FD"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M6.5 10.5V16.749C6.5 17.562 7.264 18.159 8.053 17.962L10.553 17.337C11.109 17.198 11.5 16.698 11.5 16.124V10.5"
              stroke="#2AA2FD"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
      </div>

      {/* Moments Grid */}
      {activeTab === "Moments" && (
        <div className="profile-moments-grid">
          {sampleMoments.map((moment) => (
            <MomentCard key={moment.id} moment={moment} />
          ))}
        </div>
      )}

      {/* Overview Tab - Collection Statistics */}
      {activeTab === "Overview" && (
        <div className="overview-tab-content">
          <div className="overview-stats-grid">
            <div className="stat-card">
              <div className="stat-card-header">
                <h3>Collection Overview</h3>
              </div>
              <div className="stat-card-body">
                <div className="overview-stat-item">
                  <span className="overview-stat-label">Total Moments</span>
                  <span className="overview-stat-value">{totalMoments}</span>
                </div>
                <div className="overview-stat-item">
                  <span className="overview-stat-label">Total Value</span>
                  <span className="overview-stat-value">$124,680</span>
                </div>
                <div className="overview-stat-item">
                  <span className="overview-stat-label">Avg. Moment Value</span>
                  <span className="overview-stat-value">$15,585</span>
                </div>
              </div>
            </div>

            <div className="stat-card">
              <div className="stat-card-header">
                <h3>Tier Distribution</h3>
              </div>
              <div className="stat-card-body">
                <div className="tier-breakdown">
                  <div className="tier-item legendary">
                    <span className="tier-label">Legendary</span>
                    <span className="tier-count">
                      {tierCounts.Legendary || 0}
                    </span>
                  </div>
                  <div className="tier-item ultimate">
                    <span className="tier-label">Ultimate</span>
                    <span className="tier-count">
                      {tierCounts.Ultimate || 0}
                    </span>
                  </div>
                  <div className="tier-item fan">
                    <span className="tier-label">Fan</span>
                    <span className="tier-count">{tierCounts.Fan || 0}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="stat-card">
              <div className="stat-card-header">
                <h3>Top Franchises</h3>
              </div>
              <div className="stat-card-body">
                <div className="franchise-list">
                  {uniqueFranchises.slice(0, 5).map((franchise, index) => (
                    <div key={index} className="franchise-item">
                      <span className="franchise-name">{franchise}</span>
                      <span className="franchise-count">
                        {
                          userProfile.ownedMoments.filter(
                            (m) => m.movie.franchise === franchise,
                          ).length
                        }
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="recent-activity-section">
            <h3>Recent Activity</h3>
            <div className="activity-timeline">
              <div className="activity-item">
                <div className="activity-icon">🎬</div>
                <div className="activity-content">
                  <span className="activity-action">Acquired</span>
                  <span className="activity-moment">
                    Dune - Paul vs Feyd-Rautha
                  </span>
                  <span className="activity-time">2 days ago</span>
                </div>
                <span className="activity-value">$2,100</span>
              </div>
              <div className="activity-item">
                <div className="activity-icon">⭐</div>
                <div className="activity-content">
                  <span className="activity-action">Added to Showcase</span>
                  <span className="activity-moment">
                    The Snap - Avengers: Endgame
                  </span>
                  <span className="activity-time">1 week ago</span>
                </div>
              </div>
              <div className="activity-item">
                <div className="activity-icon">🏆</div>
                <div className="activity-content">
                  <span className="activity-action">Achievement Unlocked</span>
                  <span className="activity-moment">Legendary Collector</span>
                  <span className="activity-time">2 weeks ago</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Showcase Tab - Top 3 Moments */}
      {activeTab === "Showcase" && (
        <div className="showcase-tab-content">
          <div className="showcase-header">
            <h2>Featured Collection</h2>
            <p>Your most prized cinematic moments</p>
          </div>
          <div className="showcase-grid">
            {topTierMoments.map((moment, index) => (
              <Link
                key={moment.id}
                to={`/moment/iron-man-reveal`}
                className="showcase-moment-link"
              >
                <div className="showcase-moment-card">
                  <div className="showcase-rank">#{index + 1}</div>
                  <div className="showcase-image-container">
                    <img
                      src={moment.image}
                      alt={moment.title}
                      className="showcase-image"
                    />
                    <div className="showcase-tier-overlay">
                      <span
                        className={`showcase-tier-badge ${moment.tier.toLowerCase()}`}
                      >
                        {moment.tier}
                      </span>
                    </div>
                  </div>
                  <div className="showcase-info">
                    <h3 className="showcase-title">{moment.title}</h3>
                    <p className="showcase-franchise">
                      {moment.movie.franchise}
                    </p>
                    <div className="showcase-value">
                      <span className="showcase-price">{moment.lowestAsk}</span>
                      <span className="showcase-change">+12.4%</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="showcase-actions">
            <button className="customize-showcase-btn">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path
                  d="M10 2L12.5 7.5L18 8L14 12.5L15 18L10 15L5 18L6 12.5L2 8L7.5 7.5L10 2Z"
                  fill="currentColor"
                />
              </svg>
              Customize Showcase
            </button>
          </div>
        </div>
      )}

      {/* Other tab content */}
      {activeTab === "Packs" && (
        <div className="profile-tab-content">
          <div className="coming-soon-content">
            <div className="coming-soon-icon">📦</div>
            <h3>Pack Collection</h3>
            <p>Unopened packs and pack history coming soon...</p>
          </div>
        </div>
      )}

      {activeTab === "Leaderboards" && (
        <div className="profile-tab-content">
          <div className="coming-soon-content">
            <div className="coming-soon-icon">🏆</div>
            <h3>Leaderboards</h3>
            <p>Global rankings and achievements coming soon...</p>
          </div>
        </div>
      )}

      {activeTab === "Wishlist" && (
        <div className="profile-tab-content">
          <div className="coming-soon-content">
            <div className="coming-soon-icon">❤️</div>
            <h3>Wishlist</h3>
            <p>Track moments you want to collect...</p>
          </div>
        </div>
      )}
    </div>
  );
}

// PropTypes validation for MomentCard component
MomentCard.propTypes = {
  moment: PropTypes.shape({
    id: PropTypes.number.isRequired,
    title: PropTypes.string.isRequired,
    creator: PropTypes.string.isRequired,
    image: PropTypes.string.isRequired,
    lowestAsk: PropTypes.string.isRequired,
    avgSale: PropTypes.string.isRequired,
    sold: PropTypes.string.isRequired,
    total: PropTypes.string.isRequired,
    tier: PropTypes.string.isRequired,
    hasCreatorPic: PropTypes.bool,
  }).isRequired,
};

export default ProfileScreen;
