import React, { useState, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import OfferSelectionList from "../components/OfferSelectionList";
import PurchaseSummaryCard from "../components/PurchaseSummaryCard";
import PaymentMethodTabs from "../components/PaymentMethodTabs";
import PaymentForm from "../components/PaymentForm";

const OfferOptionsScreen = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  // Mock data - in real app this would come from API/props
  const mockOffers = [
    { id: "1", price: 350.0, serial: 37, seller: "EWW" },
    { id: "2", price: 400.0, serial: 9, seller: "num1SEAfanNSD" },
    { id: "3", price: 550.0, serial: 2, seller: "wemby" },
    { id: "4", price: 600.0, serial: 63, seller: "MaktW2n" },
    { id: "5", price: 600.0, serial: 24, seller: "SEAfanNSD" },
    { id: "6", price: 1000.0, serial: 71, seller: "Twtbttttt" },
  ];

  const mockItem = {
    name: "IRON MAN",
    description: "LEGENDARY MCU MOMENT",
    imageUrl:
      "https://cdn.builder.io/api/v1/image/assets/TEMP/31e7486266d19ac2ba83b04c7910ab8497cfe6b9",
    quantity: 2,
  };

  const [selectedOffer, setSelectedOffer] = useState(mockOffers[1]); // Default to second offer
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState("card");
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);

  // Calculate pricing
  const subtotal = selectedOffer?.price || 0;
  const shipping = 7.24;
  const taxes = 2.24;
  const total = subtotal + shipping;

  const handleOfferSelect = useCallback((offer) => {
    setSelectedOffer(offer);
  }, []);

  const handleSelectAndPay = useCallback(() => {
    setShowPaymentForm(true);
  }, []);

  const handlePaymentMethodChange = useCallback((method) => {
    setPaymentMethod(method);
  }, []);

  const handlePaymentSubmit = useCallback(
    async (paymentData) => {
      setIsProcessingPayment(true);

      try {
        // Simulate payment processing
        await new Promise((resolve) => setTimeout(resolve, 2000));

        // Navigate to success screen
        navigate("/purchase-success", {
          state: {
            item: mockItem,
            offer: selectedOffer,
            total,
            paymentData,
          },
        });
      } catch (error) {
        console.error("Payment failed:", error);
        setIsProcessingPayment(false);
      }
    },
    [selectedOffer, total, mockItem, navigate],
  );

  const handleBack = useCallback(() => {
    if (showPaymentForm) {
      setShowPaymentForm(false);
    } else {
      navigate(`/moment/${id}`);
    }
  }, [showPaymentForm, navigate, id]);

  return (
    <div className="offer-options-screen">
      <div className="screen-header">
        <button
          className="back-button"
          onClick={handleBack}
          aria-label="Go back"
        >
          <svg
            width="42"
            height="42"
            viewBox="0 0 42 42"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <rect
              x="1"
              y="1"
              width="40"
              height="40"
              rx="20"
              fill="#FD4725"
              fillOpacity="0.05"
            />
            <rect
              x="1"
              y="1"
              width="40"
              height="40"
              rx="20"
              stroke="#2AA2FD"
              strokeOpacity="0.35"
              strokeLinejoin="bevel"
            />
            <path
              d="M12.9985 21.0001H28.9919"
              stroke="white"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M12.9985 27.4974H28.9919"
              stroke="white"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M12.9985 14.5027H28.9919"
              stroke="white"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>

        <div className="user-avatar">
          <img
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/0be9141cd3a2cd490a87bf9bab2add354433a845"
            alt="User"
          />
        </div>
      </div>

      <h1 className="screen-title">Offer Options</h1>

      <div className="content-container">
        <OfferSelectionList
          offers={mockOffers}
          selectedOffer={selectedOffer}
          onOfferSelect={handleOfferSelect}
          availableCount={6}
        />

        <PurchaseSummaryCard
          item={mockItem}
          selectedOffer={selectedOffer}
          subtotal={subtotal}
          shipping={shipping}
          taxes={taxes}
          total={total}
        />

        {showPaymentForm ? (
          <div className="payment-section">
            <h2 className="payment-title">Payment</h2>

            <PaymentMethodTabs
              activeMethod={paymentMethod}
              onMethodChange={handlePaymentMethodChange}
            />

            {paymentMethod === "card" && (
              <PaymentForm
                onSubmit={handlePaymentSubmit}
                total={total}
                isLoading={isProcessingPayment}
              />
            )}

            {paymentMethod === "apple_pay" && (
              <div className="alternative-payment">
                <p>Apple Pay integration would go here</p>
                <button
                  className="pay-button"
                  onClick={() => handlePaymentSubmit({})}
                >
                  Pay with Apple Pay
                </button>
              </div>
            )}

            {paymentMethod === "dapper_wallet" && (
              <div className="alternative-payment">
                <p>Dapper Wallet integration would go here</p>
                <button
                  className="pay-button"
                  onClick={() => handlePaymentSubmit({})}
                >
                  Pay with Dapper Wallet
                </button>
              </div>
            )}
          </div>
        ) : (
          <button className="select-pay-button" onClick={handleSelectAndPay}>
            Select and pay
          </button>
        )}
      </div>
    </div>
  );
};

export default OfferOptionsScreen;
