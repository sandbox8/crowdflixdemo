import React from 'react';

const NoPage = () => {
    return <div className="container my-4 text-center">
        <h2 className='text-white'>404: Page not found.</h2>
    </div>;
};

export default NoPage;