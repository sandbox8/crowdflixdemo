import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import PropTypes from "prop-types";
import { builder, BuilderComponent } from "@builder.io/react";

// Import universe components
import StickyMediaColumn from "../components/StickyMediaColumn";
import UniverseHero from "../components/UniverseHero";
import FeaturedCharacters from "../components/FeaturedCharacters";
import CollectiblesGrid from "../components/CollectiblesGrid";

// Initialize Builder.io API Key only if available
const BUILDER_API_KEY = process.env.REACT_APP_BUILDER_API_KEY;
const BUILDER_ENABLED =
  BUILDER_API_KEY && BUILDER_API_KEY !== "YOUR_BUILDER_API_KEY";

if (BUILDER_ENABLED) {
  builder.init(BUILDER_API_KEY);
}

// Fallback images for broken thumbnails
const FALLBACK_IMAGES = {
  thumbnail:
    "https://via.placeholder.com/400x300/1a1a1a/ffffff?text=Universe+Moment",
  logo: "https://via.placeholder.com/200x100/1a1a1a/ffffff?text=Universe+Logo",
  background:
    "https://via.placeholder.com/1200x600/1a1a1a/ffffff?text=Universe+Background",
  character: "https://via.placeholder.com/300x400/1a1a1a/ffffff?text=Character",
};

// Sample universe data with proper fallbacks
const sampleUniverseData = {
  marvel: {
    id: "marvel",
    name: "Marvel Universe",
    slug: "marvel",
    hero: {
      logo: FALLBACK_IMAGES.logo,
      bgImage: FALLBACK_IMAGES.background,
      tagline: "Heroes. Legends. Forever.",
      stats: {
        moments: "12.5K",
        collectors: "3.2K",
        volume: "$2.1M",
      },
    },
    featuredVideo: {
      url: "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4",
      title: "I Am Iron Man",
      thumbnails: [
        FALLBACK_IMAGES.thumbnail,
        FALLBACK_IMAGES.thumbnail,
        FALLBACK_IMAGES.thumbnail,
      ],
    },
    characters: [
      {
        id: "ironman",
        name: "Iron Man",
        image: FALLBACK_IMAGES.character,
        description: "Genius, billionaire, playboy, philanthropist",
      },
    ],
    collectibles: [
      {
        id: "ironman-reveal",
        title: "I Am Iron Man",
        image: FALLBACK_IMAGES.thumbnail,
        price: "$255.00",
        tier: "Ultimate",
        variants: [
          {
            id: "directors-cut",
            title: "Director's Cut",
            price: "$299.00",
            tier: "Ultimate",
          },
          {
            id: "deleted-scene",
            title: "Deleted Scene",
            price: "$89.00",
            tier: "Rare",
          },
        ],
      },
    ],
  },
  dc: {
    id: "dc",
    name: "DC Universe",
    slug: "dc",
    hero: {
      logo: FALLBACK_IMAGES.logo,
      bgImage: FALLBACK_IMAGES.background,
      tagline: "Justice. Honor. Legacy.",
      stats: {
        moments: "8.7K",
        collectors: "2.1K",
        volume: "$1.8M",
      },
    },
    featuredVideo: {
      url: "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4",
      title: "The Dark Knight Rises",
      thumbnails: [FALLBACK_IMAGES.thumbnail, FALLBACK_IMAGES.thumbnail],
    },
    characters: [
      {
        id: "batman",
        name: "Batman",
        image: FALLBACK_IMAGES.character,
        description: "The Dark Knight of Gotham City",
      },
    ],
    collectibles: [
      {
        id: "batman-begins",
        title: "I'm Batman",
        image: FALLBACK_IMAGES.thumbnail,
        price: "$189.00",
        tier: "Legendary",
        variants: [],
      },
    ],
  },
};

function UniversePage() {
  const { slug } = useParams();
  const [universeData, setUniverseData] = useState(null);
  const [builderContent, setBuilderContent] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadUniverseData = async () => {
      try {
        // Only try Builder.io if properly configured
        if (BUILDER_ENABLED) {
          try {
            const content = await builder
              .get("universe-page", {
                userAttributes: {
                  urlPath: `/universe/${slug}`,
                },
              })
              .toPromise();

            if (content) {
              setBuilderContent(content);
            }
          } catch (builderError) {
            console.warn(
              "Builder.io not available or unauthorized:",
              builderError.message,
            );
          }
        }

        // Load sample data (fallback or for development)
        const sampleData = sampleUniverseData[slug];
        if (sampleData) {
          setUniverseData(sampleData);
        }

        setLoading(false);
      } catch (error) {
        console.error("Error loading universe data:", error);
        // Fallback to sample data
        const sampleData = sampleUniverseData[slug];
        if (sampleData) {
          setUniverseData(sampleData);
        }
        setLoading(false);
      }
    };

    if (slug) {
      loadUniverseData();
    }
  }, [slug]);

  if (loading) {
    return (
      <div className="universe-loading">
        <div className="loading-spinner"></div>
        <div className="loading-text">Loading {slug} universe...</div>
      </div>
    );
  }

  if (!universeData && !builderContent) {
    return (
      <div className="universe-not-found">
        <h1>Universe Not Found</h1>
        <p>The universe &ldquo;{slug}&rdquo; doesn&apos;t exist yet.</p>
        <p>Available universes: Marvel, DC</p>
      </div>
    );
  }

  return (
    <div className="universe-page">
      {/* Builder.io Content - only render if properly configured */}
      {BUILDER_ENABLED && builderContent && (
        <BuilderComponent
          model="universe-page"
          content={builderContent}
          data={{ universe: universeData }}
        />
      )}

      {/* Fallback/Sample Content */}
      {(!BUILDER_ENABLED || !builderContent) && universeData && (
        <div className="universe-content">
          <UniverseLayoutContainer universe={universeData} />
        </div>
      )}
    </div>
  );
}

// Layout container component for sticky left-right layout
function UniverseLayoutContainer({ universe }) {
  return (
    <div className="universe-layout-container">
      {/* Left Column - Sticky Media */}
      <div className="universe-left-column">
        <StickyMediaColumn
          videoUrl={universe.featuredVideo.url}
          title={universe.featuredVideo.title}
          thumbnails={universe.featuredVideo.thumbnails}
        />
      </div>

      {/* Right Column - Scrollable Content */}
      <div className="universe-right-column">
        <UniverseHero
          logo={universe.hero.logo}
          bgImage={universe.hero.bgImage}
          tagline={universe.hero.tagline}
          name={universe.name}
          stats={universe.hero.stats}
        />

        <FeaturedCharacters characters={universe.characters} />

        <CollectiblesGrid collectibles={universe.collectibles} />
      </div>
    </div>
  );
}

UniverseLayoutContainer.propTypes = {
  universe: PropTypes.shape({
    name: PropTypes.string.isRequired,
    hero: PropTypes.object.isRequired,
    featuredVideo: PropTypes.object.isRequired,
    characters: PropTypes.array.isRequired,
    collectibles: PropTypes.array.isRequired,
  }).isRequired,
};

export default UniversePage;
