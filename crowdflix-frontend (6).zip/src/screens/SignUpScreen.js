import React, { useState } from 'react';

import { Eye, EyeSlash } from 'react-bootstrap-icons';
import { Form, Link, useNavigate } from 'react-router-dom';

import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { useDispatch } from 'react-redux';
import { login } from '../features/user/userSlice';
import { auth, db } from '../firebase';

import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { storage } from "../firebase";

import userTemplate from '../models/UserTemplate';

import crowdflix_logo from '../assets/images/crowdflix_logo.png';

function SignUpScreen() {
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const [email, setEmail] = useState('');
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [confirmPassword, setConfirmPassword] = useState('');

    const [profilePicFile, setProfilePicFile] = useState(null);
    const [profilePicURL, setProfilePicURL] = useState('');

    const [error, setError] = useState('');

    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleEmailChange = (e) => {
        setEmail(e.target.value);
    };
    const handleFirstNameChange = (e) => {
        setFirstName(e.target.value);
    };
    const handleLastNameChange = (e) => {
        setLastName(e.target.value);
    };
    const handlePasswordChange = (e) => {
        setPassword(e.target.value);
    };
    const handleConfirmPasswordChange = (e) => {
        setConfirmPassword(e.target.value);
    };
    const handleTogglePassword = () => {
        setShowPassword((prevState) => !prevState);
    };

    const addUserToFirestore = async (user) => {
        if (!user) return;

        const userRef = doc(db, 'users', user.uid);
        const newUser = {
            ...userTemplate,
            id: user.uid,
            displayName: user.displayName || userTemplate.name,
            email: user.email || userTemplate.email,
            profilePicture: user.photoURL || userTemplate.profilePicture,
            biography: userTemplate.biography,
        };

        const snapshot = await getDoc(userRef);
        if (!snapshot.exists()) {
            await setDoc(userRef, newUser);
        }

        dispatch(login({
            ...newUser
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Check if the password is at least six characters long
        if (password.length < 6) {
            setError('Password must be at least six characters long.');
            return;
        }

        // Check if the password contains both letters and numbers
        const passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d).{6,}$/;
        if (!passwordRegex.test(password)) {
            setError('Password must contain at least one letter and one number.');
            return;
        }

        // Check if the password and confirm password fields match
        if (password !== confirmPassword) {
            setError('Passwords do not match. Please try again.');
            return;
        }

        setError('');
        setIsSubmitting(true);

        let uploadedProfilePicURL = ''; // Default to empty

        try {
            // Create user in Firebase Auth
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            const user = userCredential.user;

            // Upload profile picture if selected
            if (profilePicFile) {
                const storageRef = ref(storage, `profile_pictures/${user.uid}`);

                await uploadBytes(storageRef, profilePicFile); // Upload file
                uploadedProfilePicURL = await getDownloadURL(storageRef); // Get file URL
            }

            // Update Firebase Auth profile
            await updateProfile(user, {
                displayName: `${firstName} ${lastName}`,
                photoURL: uploadedProfilePicURL
            });

            // Save user details in Firestore
            await addUserToFirestore({ ...user, photoURL: uploadedProfilePicURL });

            setIsSubmitting(false);
            navigate(`/profile/${user.uid}`);

        } catch (error) {
            console.error("Error creating profile: ", error);
            setError(error.message);
            setIsSubmitting(false);
        }
    };

    return (
        <div className="container">
            <div className="row my-5">
                <div className="col-lg-6 d-none d-lg-flex align-items-center justify-content-center">
                    <img src={crowdflix_logo} style={{ maxHeight: '450px' }} alt="description" />
                </div>

                <div className=" col-12 col-lg-6 d-flex justify-content-center align-items-center">
                    <div className="form-container d-flex justify-content-center align-items-center flex-column dark-bg rounded py-4 text-center">
                        <h3 className='text-white px-2'><strong>Hey!</strong> Welcome to Crowdflix!</h3>
                        <Form className="text-center p-4" id='sign-up-form' onSubmit={handleSubmit}>
                            {/* Name Inputs */}
                            <input
                                name="firstName"
                                type="text"
                                placeholder="First Name"
                                className="form-control bg-dark border-dark text-white mb-3"
                                required
                                value={firstName} onChange={handleFirstNameChange}
                            />
                            <input
                                name="lastName"
                                type="text"
                                placeholder="Last Name"
                                className="form-control bg-dark border-dark text-white mb-3"
                                required
                                value={lastName} onChange={handleLastNameChange}
                            />

                            {/* Email Input */}
                            <input
                                name="email"
                                type="email"
                                placeholder="Email"
                                className="form-control bg-dark border-dark text-white mb-3"
                                required
                                value={email} onChange={handleEmailChange}
                            />

                            {/* Password Inputs */}
                            <div className="input-group mb-3">
                                <input
                                    name="password"
                                    type={showPassword ? 'text' : 'password'}
                                    placeholder="Password"
                                    className="form-control bg-dark border-dark text-white"
                                    required
                                    value={password}
                                    onChange={handlePasswordChange}
                                    data-testid="password-input"
                                />
                                <span
                                    className="btn btn-outline-secondary bg-dark border-0"
                                    type="button"
                                    onClick={handleTogglePassword}
                                    data-testid="toggle-password"
                                >
                                    {showPassword ? <EyeSlash color="#0069D9" /> : <Eye color="#0069D9" />}
                                </span>
                            </div>

                            <input
                                type="password"
                                placeholder="Confirm Password"
                                className="form-control bg-dark border-dark text-white mb-3"
                                required
                                value={confirmPassword}
                                onChange={handleConfirmPasswordChange}
                            />

                            {/* Profile Picture Input */}
                            <div className="mb-3" style={
                                { textAlign: 'end' }
                            }>
                                <input
                                    type="file"
                                    accept="image/*"
                                    className="form-control bg-dark border-dark text-white"
                                    onChange={(e) => setProfilePicFile(e.target.files[0])}
                                />

                                <small className="text-white">
                                    {profilePicFile ? profilePicFile.name : "*optional"}
                                </small>
                            </div>

                            {/* Error Message */}
                            {error && <div className="alert alert-danger w-100">{error}</div>}

                            {/* Submit Button */}
                            <button
                                className="btn btn-primary px-4 mt-3"
                                type="submit"
                                id='signup-btn'
                                disabled={isSubmitting}
                            >
                                Sign Up
                            </button>
                        </Form>

                        <div className="">
                            <Link to='/sign-in' className='my-link'>Already have an account?</Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default SignUpScreen;