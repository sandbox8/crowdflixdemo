import React from 'react';

import TeamCard from '../components/TeamCard';

function AboutUsScreen() {
    return (
        <div className='container' id='about-screen'>
            <header className="my-4 my-md-5 d-flex flex-column align-items-center text-center">
                <h1 className='fs-1'>About Us</h1>
            </header>

            {/* Info Section */}
            <div className="row mb-5">
                <div className="col-12 d-flex flex-column justify-content-center align-items-center text-center">
                    <h2 className='fs-2 mb-2'>Crowdflix: The Next-Gen Social Film Economy</h2>
                    <p className='text-justify'>
                        Gamified, social, and collectible. Powered by the magic of movies, AI, and blockchain.
                    </p>
                </div>
            </div>

            <hr className='border-light' />

            {/* Team Section */}
            <h2 className='fs-2 my-4 text-center text-md-start'>Our Team</h2>
            <div className="row">
                <TeamCard
                    name='Cameron Macpherson'
                    role='Co-Founder, CEO'
                    profilePic='https://media.licdn.com/dms/image/D5603AQHm4yl0OBKqxg/profile-displayphoto-shrink_800_800/0/1701143898215?e=1706745600&v=beta&t=7R8w3IszgAHAo0QuBb6BhtLc3p4jp_9y_ek5hT7v3oE'
                    profileLink='https://www.linkedin.com/in/cameron-macpherson/'
                />
                <TeamCard
                    name='Kari Barber'
                    role='Co-Founder, President'
                    profilePic='https://media.licdn.com/dms/image/C4E03AQGK4I9Yk8l39A/profile-displayphoto-shrink_800_800/0/1517751441750?e=1706745600&v=beta&t=lZynTXViuCfj1AY1nj58yxHRwpAGj5sWmm4dtTtlYow'
                    profileLink='https://www.linkedin.com/in/kari-barber-12263a5/'
                />
                <TeamCard
                    name='Adit Kapoor'
                    role='Director, Technical Advisor'
                    profilePic='https://media.licdn.com/dms/image/C4E03AQGE-zqUOi6dng/profile-displayphoto-shrink_800_800/0/1650584213070?e=1706745600&v=beta&t=Mtf4l57nPuLZ4VQmuTw9-1HQM20SIyaVXKUtoRdfXm8'
                    profileLink='https://www.linkedin.com/in/adit-kapoor/'
                />
            </div>
        </div>
    );
}

export default AboutUsScreen;