import React from "react";
import Navbar from "../components/Navbar";
import MarketplaceMomentCard from "../components/MarketplaceMomentCard";
import MarketplaceFilterSidebar from "../components/MarketplaceFilterSidebar";
import SortAndSearchBar from "../components/SortAndSearchBar";

const MarketplaceDemoScreen = () => {
  // Sample moment data
  const sampleMoments = [
    {
      id: "moment-1",
      momentName: "Iron Man Reveal",
      studio: "Marvel Studios",
      lowestAsk: "25",
      avgSale: "32",
      sold: "1,254",
      total: "5,000",
      rarity: "Legendary",
      videoPreviewUrl:
        "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/e318dad147db92f5d6487c15728ee9a42eb4a65b",
    },
    {
      id: "moment-2",
      momentName: "Spider-Man Swing",
      studio: "Sony Pictures",
      lowestAsk: "18",
      avgSale: "24",
      sold: "2,847",
      total: "8,000",
      rarity: "Rare",
      videoPreviewUrl: "",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/e318dad147db92f5d6487c15728ee9a42eb4a65b",
    },
    {
      id: "moment-3",
      momentName: "Thor Lightning",
      studio: "Marvel Studios",
      lowestAsk: "45",
      avgSale: "58",
      sold: "876",
      total: "3,000",
      rarity: "Ultimate",
      videoPreviewUrl:
        "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/e318dad147db92f5d6487c15728ee9a42eb4a65b",
    },
  ];

  return (
    <div className="marketplace-demo-screen">
      <Navbar />

      <div className="demo-container">
        <h1 className="demo-title">🎯 Marketplace Components Demo</h1>

        <div className="demo-description">
          <p>
            All marketplace components extracted from Figma design and ready for
            Builder.io integration
          </p>
        </div>

        {/* Sort and Search Bar Demo */}
        <section className="demo-section">
          <h2 className="section-title">📊 Sort & Search Bar</h2>
          <div className="component-demo">
            <SortAndSearchBar
              activeTab="Moments"
              onTabChange={(tab) => console.log("Tab changed:", tab)}
              onSearchChange={(query) => console.log("Search:", query)}
              onSortChange={(sort) => console.log("Sort:", sort)}
              onFilterToggle={() => console.log("Filter toggled")}
            />
          </div>
        </section>

        {/* Filter Sidebar Demo */}
        <section className="demo-section">
          <h2 className="section-title">🔍 Filter Sidebar</h2>
          <div className="component-demo">
            <MarketplaceFilterSidebar
              onFilterChange={(filters) => console.log("Filters:", filters)}
              onClearAll={() => console.log("Filters cleared")}
            />
          </div>
        </section>

        {/* Moment Cards Demo */}
        <section className="demo-section">
          <h2 className="section-title">
            🎬 Marketplace Moment Cards (with Video Hover)
          </h2>
          <div className="cards-grid">
            {sampleMoments.map((moment) => (
              <MarketplaceMomentCard
                key={moment.id}
                momentName={moment.momentName}
                studio={moment.studio}
                lowestAsk={moment.lowestAsk}
                avgSale={moment.avgSale}
                sold={moment.sold}
                total={moment.total}
                rarity={moment.rarity}
                videoPreviewUrl={moment.videoPreviewUrl}
                thumbnailUrl={moment.thumbnailUrl}
                momentId={moment.id}
              />
            ))}
          </div>
        </section>

        {/* Builder.io Integration Notes */}
        <section className="demo-section">
          <h2 className="section-title">🔧 Builder.io Integration</h2>
          <div className="integration-notes">
            <div className="note-card">
              <h3>✅ Components Registered</h3>
              <ul>
                <li>
                  <strong>Marketplace Moment Card</strong> - Video hover
                  functionality, pricing, stats
                </li>
                <li>
                  <strong>Marketplace Filter Sidebar</strong> - Collapsible
                  filters with search
                </li>
                <li>
                  <strong>Sort and Search Bar</strong> - Tabs, search input,
                  sort dropdown
                </li>
              </ul>
            </div>

            <div className="note-card">
              <h3>🎯 Key Features</h3>
              <ul>
                <li>
                  <strong>Video Hover:</strong> Auto-play muted video on card
                  hover
                </li>
                <li>
                  <strong>Responsive Design:</strong> Mobile, tablet, desktop
                  breakpoints
                </li>
                <li>
                  <strong>Glassmorphism:</strong> Blur effects matching existing
                  design system
                </li>
                <li>
                  <strong>Interactive Filters:</strong> Dynamic filter states
                  and clearing
                </li>
              </ul>
            </div>

            <div className="note-card">
              <h3>📱 Next Steps</h3>
              <ul>
                <li>Connect to Flow blockchain for live data</li>
                <li>Implement functional filtering and search</li>
                <li>Add pagination or infinite scroll</li>
                <li>Connect buy buttons to purchase flow</li>
              </ul>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default MarketplaceDemoScreen;
