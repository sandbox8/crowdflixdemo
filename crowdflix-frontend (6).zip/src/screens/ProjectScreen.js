import React, { useEffect, useState } from 'react';

import { ProgressBar } from 'react-bootstrap';
import { PersonFill } from 'react-bootstrap-icons';
import { Link, useNavigate, useParams } from 'react-router-dom';

import { loadStripe } from '@stripe/stripe-js';
import { doc, getDoc } from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import { useSelector } from "react-redux";
import { selectUser } from "../features/user/userSlice";
import { db, functions } from "../firebase";
import ProfileAvatar from '../components/ProfileAvatar';
import LoadingIndicator from '../components/LoadingIndicator';

function ProjectScreen() {
    const navigate = useNavigate();

    const { id } = useParams();
    const [loading, setLoading] = useState(true);
    const [project, setProject] = useState(null);
    const [user, setUser] = useState(null);
    const authUser = useSelector(selectUser);

    const [backingAmount, setBackingAmount] = useState('');
    const [isBacking, setIsBacking] = useState(false);

    const [timestampString, setTimestampString] = useState('...');

    function parseEndDate(endDateData) {
        if (typeof endDateData === 'number') {
            return new Date(endDateData).getTime();
        } else if (endDateData && endDateData.seconds !== undefined) {
            return new Date(endDateData.seconds * 1000 + endDateData.nanoseconds / 1000000).getTime();
        } else if (typeof endDateData === 'string') {
            return new Date(endDateData).getTime();
        } else {
            return null;
        }
    }

    const fetchProjectAndUser = async () => {
        const docRef = doc(db, "projects", id);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
            console.log("Document data:", docSnap.data());
            const projectData = docSnap.data();
            projectData.endDate = parseEndDate(projectData.endDate);
            setProject(projectData);
            const userDocRef = doc(db, "users", docSnap.data().projectCreatorId);
            const userDocSnap = await getDoc(userDocRef);

            if (userDocSnap.exists()) {
                setUser(userDocSnap.data());
            } else {
                console.log("No such user document!");
            }
        } else {
            console.log("No such project document!");
        }
        setLoading(false);
    };

    const calculateDaysToGo = (endDateMillis) => {
        const now = new Date();
        const end = new Date(endDateMillis);
        const millisecondsPerDay = 24 * 60 * 60 * 1000;
        return Math.round((end - now) / millisecondsPerDay);
    };
    const daysToGo = project ? calculateDaysToGo(project.endDate) : null;

    function formatTimestamp(timestamp) {
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return new Date(timestamp).toLocaleDateString(undefined, options);
    }

    useEffect(() => {
        fetchProjectAndUser();
    }, [id]);

    useEffect(() => {
        if (project) {
            const timestamp = project.timestamp;
            if (timestamp && timestamp.seconds) {
                const createdDate = new Date(timestamp.seconds * 1000); // Convert seconds to milliseconds
                setTimestampString(`Created on ${formatTimestamp(createdDate)}`);
            }
        }
    }, [project]);

    const createStripeCheckout = httpsCallable(functions, 'createStripeCheckout');
    const stripePromise = loadStripe('pk_test_51O7DMJCDXLNQ7lQDzacjvpKY8pul9oLesizAxUWUhdTR3iAHd8nwktWpjNtEtWIFFKVFot7cqLcagX7px1KcnQh900qwnIxtqY');
    const backProject = () => {
        if (authUser == null) {
            navigate('/sign-in');
            return;
        }

        if (isNaN(backingAmount) || backingAmount <= 0 || backingAmount === '') {
            alert('Please enter a valid amount');
            return;
        }

        const amountInCents = parseInt(backingAmount * 100);
        setIsBacking(true);

        createStripeCheckout({
            amount: amountInCents,
            projectId: id,
            userId: authUser.id
        })
            .then(async (response) => {
                const sessionId = response.data.id;
                const stripe = await stripePromise;
                stripe.redirectToCheckout({ sessionId: sessionId });
                setIsBacking(false);
            })
            .catch(error => {
                setIsBacking(false);
                console.error("Error in redirectToCheckout: ", error);
            });
    };

    if (loading) {
        return LoadingIndicator();
    }

    return (
        <div className="container mb-3" id='project-screen'>
            <header className="my-4 my-md-5 d-flex flex-column align-items-center text-center">
                <h1 className='fs-1'>{project.projectName}</h1>
            </header>

            <div className="row d-flex align-items-center px-lg-3 py-lg-3 rounded-4">
                <div className="col-lg-8 mb-2">
                    <div className='image-container'>
                        <img
                            src={project.projectImage}
                            className="card-img-top"
                            alt={project.projectName}
                        />
                    </div>
                </div>
                <div className="col-lg-4 mb-2">
                    <div className="d-flex justify-content-center  border border-1 border-dark rounded-2">
                        <div className="w-100 text-center">
                            <div className="card testimonial-card dark-bg">

                                <div
                                    className="card-up d-flex justify-content-start align-items-start"
                                    style={{
                                        backgroundImage: user.profilePicture ? `url(${user.profilePicture})` : 'none',
                                    }}
                                >
                                </div>
                                <ProfileAvatar profilePicture={user?.profilePicture} />

                                <div className="card-body">
                                    <h3>
                                        <Link
                                            to={`/profile/${user.id}`}
                                            className="my-link text-white"
                                        >{user.displayName}</Link>
                                    </h3>
                                    <p>{user.biography}</p>

                                    <hr style={{ borderColor: 'white' }} />

                                    <p className="mt-4">
                                        {timestampString}
                                    </p>

                                    {!isNaN(daysToGo) &&
                                        <p className="mt-4">
                                            {
                                                daysToGo >= 1
                                                    ? `${daysToGo} days to go!`
                                                    : 'Project has ended!'
                                            }
                                        </p>
                                    }

                                    <p className="mt-4">
                                        {project.backers.length} backer{project.backers.length === 1 ? '' : 's'}
                                    </p>
                                </div>
                                <div className="card-footer border-dark p-3">
                                    <div className="d-flex justify-content-between align-items-center text-white">
                                        <div className="fw-bold">
                                            <span className="fs-5">${project.funded}</span>
                                            <span className="fs-6"> funded</span>
                                        </div>

                                        <div className="fw-bold">
                                            <span className="fs-5">${project.fundingGoal}</span>
                                            <span className="fs-6"> goal</span>
                                        </div>
                                    </div>

                                    <ProgressBar
                                        now={(project.funded / project.fundingGoal) * 100}
                                        variant='primary'
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <hr style={{ borderColor: 'white' }} />

            <div className="row mb-4">
                <div className="col-lg-8 text-center">
                    <p className='md-lead'>{project.projectDescription}</p>
                </div>

                <div className="col-lg-4 d-flex justify-content-center align-items-start">
                    <div className="w-100 d-flex align-items-center justify-content-center">
                        <input
                            name="backingAmount"
                            type="text"
                            placeholder="Amount (USD)"
                            className="form-control bg-dark border-dark text-white mx-2"
                            value={backingAmount}
                            onChange={(e) => setBackingAmount(e.target.value)}
                        />
                        <button className='btn btn-primary w-75'
                            onClick={backProject}
                            disabled={isBacking || !daysToGo >= 1} >{
                                isBacking ? 'Backing...'
                                    : daysToGo >= 1
                                        ? 'Back this Project!'
                                        : 'Project has ended!'
                            }</button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ProjectScreen;
