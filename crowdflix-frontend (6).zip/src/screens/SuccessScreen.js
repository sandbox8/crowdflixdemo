import React from 'react';

function SuccessScreen() {
    return (
        <div className="alert alert-info h-75 text-black">
            <h2 className='fs-4'>Thank you for your payment!</h2>
        </div>
    );
}

export default SuccessScreen;