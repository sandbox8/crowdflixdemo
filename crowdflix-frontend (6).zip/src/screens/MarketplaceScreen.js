import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar";
import MyCollectionsSection from "../components/MyCollectionsSection";
import EmojiFilterPanel from "../components/EmojiFilterPanel";
import HorizontalFilterBar from "../components/HorizontalFilterBar";
import ActiveFilters from "../components/ActiveFilters";
import MarketplaceGroupedGrid from "../components/MarketplaceGroupedGrid";
import LoadingSpinner from "../components/LoadingSpinner";

const MarketplaceScreen = () => {
  const [filters, setFilters] = useState({
    genre: [],
    emotion: [],
    characterType: [],
    era: [],
    theme: [],
    priceRange: [0, 10000],
  });

  const [isLoading, setIsLoading] = useState(true);
  const [isFiltering, setIsFiltering] = useState(false);
  const [error, setError] = useState(null);

  // Simulate initial loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  // Handle filter changes with loading state
  const handleFiltersChange = (newFilters) => {
    setIsFiltering(true);
    setError(null);

    // Simulate API call delay
    setTimeout(() => {
      setFilters(newFilters);
      setIsFiltering(false);
      console.log("Filters changed:", newFilters);
    }, 500);
  };

  // Handle horizontal filter changes
  const handleHorizontalFiltersChange = (newHorizontalFilters) => {
    setIsFiltering(true);
    setError(null);

    // Simulate API call delay
    setTimeout(() => {
      setIsFiltering(false);
      console.log("Horizontal filters changed:", newHorizontalFilters);
    }, 300);
  };

  // Remove individual filter with loading state
  const handleRemoveFilter = (category, value) => {
    setIsFiltering(true);

    setTimeout(() => {
      const newFilters = { ...filters };

      if (category === "priceRange") {
        newFilters.priceRange = [0, 10000];
      } else if (Array.isArray(newFilters[category])) {
        newFilters[category] = newFilters[category].filter(
          (item) => item !== value,
        );
      }

      setFilters(newFilters);
      setIsFiltering(false);
    }, 300);
  };

  // Clear all filters with loading state
  const handleClearAllFilters = () => {
    setIsFiltering(true);

    setTimeout(() => {
      const clearedFilters = {
        genre: [],
        emotion: [],
        characterType: [],
        era: [],
        theme: [],
        priceRange: [0, 10000],
      };
      setFilters(clearedFilters);
      setIsFiltering(false);
    }, 300);
  };

  // Check if any filters are active
  const hasActiveFilters = () => {
    return Object.values(filters).some((filterValues) => {
      if (Array.isArray(filterValues)) {
        return filterValues.length > 0;
      }
      return false;
    });
  };

  if (isLoading) {
    return (
      <div className="marketplace-screen">
        <Navbar />
        <div style={{ paddingTop: "100px", minHeight: "100vh" }}>
          <LoadingSpinner
            size="large"
            message="Loading marketplace..."
            fullscreen={true}
          />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="marketplace-screen">
        <Navbar />
        <div
          style={{
            paddingTop: "100px",
            minHeight: "100vh",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            color: "#fff",
            textAlign: "center",
            padding: "40px",
          }}
        >
          <h2
            style={{ fontSize: "32px", marginBottom: "20px", color: "#FF4A3C" }}
          >
            Oops! Something went wrong
          </h2>
          <p style={{ fontSize: "18px", marginBottom: "30px", opacity: 0.8 }}>
            We&apos;re having trouble loading the marketplace. Please try again.
          </p>
          <button
            onClick={() => window.location.reload()}
            style={{
              padding: "15px 30px",
              backgroundColor: "#FFC03F",
              color: "#000",
              border: "none",
              borderRadius: "25px",
              fontSize: "16px",
              fontWeight: 600,
              cursor: "pointer",
              transition: "background-color 0.3s ease",
            }}
            onMouseOver={(e) => (e.target.style.backgroundColor = "#FFD700")}
            onMouseOut={(e) => (e.target.style.backgroundColor = "#FFC03F")}
          >
            Refresh Page
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="marketplace-screen">
      {/* Navigation */}
      <Navbar />

      {/* My Collections Section - 3-Tab Interface */}
      <MyCollectionsSection />

      {/* Marketplace Discovery Section */}
      <div className="marketplace-discovery">
        <div className="marketplace-discovery__container">
          {/* Discovery Header */}
          <div className="marketplace-discovery__header">
            <h2 className="marketplace-discovery__title">Discover Moments</h2>
            <p className="marketplace-discovery__subtitle">
              Explore emotion through story, collect your taste, trade your
              cinematic soul
            </p>
          </div>

          {/* Horizontal Filter Bar - NBA Top Shot Style */}
          <div className="marketplace-discovery__horizontal-filters">
            <HorizontalFilterBar
              onFiltersChange={handleHorizontalFiltersChange}
              className="marketplace-horizontal-filter-bar"
            />
          </div>

          {/* Filter Panel */}
          <div className="marketplace-discovery__filters">
            <EmojiFilterPanel
              onFiltersChange={handleFiltersChange}
              className="marketplace-filter-panel"
              disabled={isFiltering}
            />
          </div>

          {/* Active Filters */}
          {hasActiveFilters() && (
            <ActiveFilters
              filters={filters}
              onRemoveFilter={handleRemoveFilter}
              onClearAll={handleClearAllFilters}
              className="marketplace-active-filters"
              disabled={isFiltering}
            />
          )}

          {/* Loading overlay for filtering */}
          {isFiltering && (
            <div
              style={{
                position: "relative",
                minHeight: "200px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <LoadingSpinner size="medium" message="Applying filters..." />
            </div>
          )}

          {/* Grouped Grid */}
          {!isFiltering && (
            <MarketplaceGroupedGrid
              filters={filters}
              className="marketplace-grid"
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default MarketplaceScreen;
