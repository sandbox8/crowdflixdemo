import React, { useState } from 'react';

import { Link, useNavigate } from 'react-router-dom';

import { sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '../firebase';

import crowdflix_logo from '../assets/images/crowdflix_logo.png';

function ForgotPasswordScreen() {
    const navigate = useNavigate();

    const [email, setEmail] = useState('');
    const [success, setSuccess] = useState('');
    const [error, setError] = useState('');

    const resetPassword = (e) => {
        e.preventDefault();

        sendPasswordResetEmail(auth, email)
            .then(() => {
                setSuccess('Password reset email sent!');
                setTimeout(() => {
                    navigate('/sign-in');
                }, 3500);
            })
            .catch((error) => {
                const errorCode = error.code;
                const errorMessage = error.message;
                setError(errorMessage);
            });
    };

    return (
        <div className="container">
            <div className="row my-5">
                <div className="col-lg-6 d-none d-lg-flex align-items-center justify-content-center">
                    <img src={crowdflix_logo} style={{ maxHeight: '450px' }} alt="description" />
                </div>

                <div className=" col-12 col-lg-6 d-flex justify-content-center align-items-center">
                    <div className="form-container d-flex justify-content-center align-items-center flex-column dark-bg rounded py-4">
                        <h3 className='text-white'>Forgotten your Password?</h3>
                        <form
                            action=""
                            className="text-center p-4"
                            id='sign-in-form'
                            onSubmit={resetPassword}
                        >
                            <input
                                name="email"
                                type="email"
                                placeholder="Email"
                                className="form-control bg-dark border-dark text-white mb-3"
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                            />

                            {error && <div className="alert alert-danger w-100 mt-3">{error}</div>}

                            {success && <div className="alert alert-info w-100 mt-3">{success}</div>}

                            <button className="btn btn-primary px-4" type="submit" id='signup-btn'>
                                Reset Password
                            </button>
                        </form>

                        <div className="">
                            <Link to='/sign-up' className='my-link'>Don&apos;t have an account?</Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ForgotPasswordScreen;