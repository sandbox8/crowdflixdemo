import React, { useState, useCallback, useMemo, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import ProfileLoadingScreen from "../components/ProfileLoadingStates";
import SocialMediaIcons from "../components/SocialMediaIcons";

// Optimized Components
const ProfileHeader = React.memo(({ user, onEdit, onShare }) => (
  <div className="profile-header">
    <div className="profile-header-background">
      <div className="header-gradient-overlay" />
    </div>

    <div className="profile-header-content">
      <div className="profile-avatar">
        <img src={user.profileImage} alt={user.username} loading="lazy" />
        <div className="avatar-status-indicator" />
      </div>

      <div className="profile-info">
        <h1 className="profile-name">{user.username}</h1>
        <div className="profile-meta">
          <span className="join-date">Joined {user.joinedDate}</span>
          <span className="location">{user.location}</span>
        </div>

        <div className="profile-stats-mini">
          <div className="stat">
            <span className="stat-value">{user.totalMoments}</span>
            <span className="stat-label">Moments</span>
          </div>
          <div className="stat">
            <span className="stat-value">{user.portfolioValue}</span>
            <span className="stat-label">Portfolio</span>
          </div>
          <div className="stat">
            <span className="stat-value">{user.rank}</span>
            <span className="stat-label">Global Rank</span>
          </div>
        </div>

        {/* Social Media Icons */}
        {user.socials &&
          Object.keys(user.socials).some((key) => user.socials[key]) && (
            <div className="profile-social-section">
              <SocialMediaIcons
                socials={user.socials}
                variant="profile"
                size="default"
              />
            </div>
          )}

        <div className="profile-actions">
          <button className="action-btn primary" onClick={onEdit}>
            <svg width="16" height="16" fill="currentColor">
              <path d="M11.013 1.427a1.75 1.75 0 012.474 0l1.086 1.086a1.75 1.75 0 010 2.474l-8.61 8.61c-.21.21-.47.364-.756.445l-3.251.93a.75.75 0 01-.927-.928l.929-3.25a1.75 1.75 0 01.445-.758l8.61-8.61z" />
            </svg>
            Edit Profile
          </button>
          <button className="action-btn secondary" onClick={onShare}>
            <svg width="16" height="16" fill="currentColor">
              <path d="M7.25 11.25V3.5H8.75V11.25L11.125 8.875L12.189 9.939L8.5 13.63L4.811 9.939L5.875 8.875L7.25 11.25Z" />
            </svg>
            Share
          </button>
        </div>
      </div>
    </div>
  </div>
));

ProfileHeader.displayName = "ProfileHeader";

const TabNavigation = React.memo(({ tabs, activeTab, onTabChange }) => (
  <div className="tab-navigation">
    <div className="tab-container">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          className={`tab ${activeTab === tab.id ? "active" : ""}`}
          onClick={() => onTabChange(tab.id)}
          aria-pressed={activeTab === tab.id}
        >
          {tab.icon && <span className="tab-icon">{tab.icon}</span>}
          <span className="tab-label">{tab.label}</span>
          {tab.count && <span className="tab-count">{tab.count}</span>}
        </button>
      ))}
    </div>
  </div>
));

TabNavigation.displayName = "TabNavigation";

const MomentCard = React.memo(({ moment, onSelect }) => (
  <div className="moment-card" onClick={() => onSelect(moment)}>
    <div className="moment-image-container">
      <img
        src={moment.thumbnail}
        alt={moment.title}
        loading="lazy"
        className="moment-image"
      />
      <div className="moment-overlay">
        <div className={`rarity-badge ${moment.rarity.toLowerCase()}`}>
          {moment.rarity}
        </div>
        <div className="moment-actions">
          <button className="action-icon share" aria-label="Share moment">
            <svg width="16" height="16" fill="currentColor">
              <path d="M7.25 11.25V3.5H8.75V11.25L11.125 8.875L12.189 9.939L8.5 13.63L4.811 9.939L5.875 8.875L7.25 11.25Z" />
            </svg>
          </button>
          <button
            className="action-icon favorite"
            aria-label="Add to favorites"
          >
            <svg width="16" height="16" fill="currentColor">
              <path d="M8 12.5L3.5 8.5L4.7 7.3L8 10.6L11.3 7.3L12.5 8.5L8 12.5Z" />
            </svg>
          </button>
        </div>
      </div>
    </div>

    <div className="moment-content">
      <h3 className="moment-title">{moment.title}</h3>
      <p className="moment-franchise">{moment.franchise}</p>

      <div className="moment-stats">
        <div className="stat-group">
          <span className="stat-label">Value</span>
          <span className="stat-value">{moment.currentValue}</span>
        </div>
        <div className="stat-group">
          <span className="stat-label">Owned</span>
          <span className="stat-value">{moment.ownedDate}</span>
        </div>
      </div>

      <div className="moment-actions-footer">
        <button className="view-btn">View Details</button>
        <div className="value-change positive">+{moment.valueChange}</div>
      </div>
    </div>
  </div>
));

MomentCard.displayName = "MomentCard";

const CollectionOverview = React.memo(({ stats, topMoments }) => (
  <div className="collection-overview">
    <div className="overview-grid">
      {/* Portfolio Performance */}
      <div className="overview-card portfolio">
        <div className="card-header">
          <h3>Portfolio Performance</h3>
          <div className="performance-indicator positive">
            <svg width="16" height="16" fill="currentColor">
              <path d="M8 2L11 8H9V14H7V8H5L8 2Z" />
            </svg>
            +12.4%
          </div>
        </div>
        <div className="card-content">
          <div className="main-metric">
            <span className="metric-value">{stats.totalValue}</span>
            <span className="metric-label">Total Portfolio Value</span>
          </div>
          <div className="sub-metrics">
            <div className="sub-metric">
              <span className="label">30d Change</span>
              <span className="value positive">+$2,340</span>
            </div>
            <div className="sub-metric">
              <span className="label">Best Performer</span>
              <span className="value">{stats.bestPerformer}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Collection Stats */}
      <div className="overview-card collection">
        <div className="card-header">
          <h3>Collection Stats</h3>
        </div>
        <div className="card-content">
          <div className="stats-grid">
            <div className="stat-item">
              <span className="stat-icon">🏆</span>
              <div className="stat-info">
                <span className="stat-number">{stats.legendary}</span>
                <span className="stat-label">Legendary</span>
              </div>
            </div>
            <div className="stat-item">
              <span className="stat-icon">🎬</span>
              <div className="stat-info">
                <span className="stat-number">{stats.franchises}</span>
                <span className="stat-label">Franchises</span>
              </div>
            </div>
            <div className="stat-item">
              <span className="stat-icon">⭐</span>
              <div className="stat-info">
                <span className="stat-number">{stats.completionRate}%</span>
                <span className="stat-label">Complete</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="overview-card activity">
        <div className="card-header">
          <h3>Recent Activity</h3>
          <button className="view-all-btn">View All</button>
        </div>
        <div className="card-content">
          <div className="activity-list">
            {stats.recentActivity.map((activity, index) => (
              <div key={index} className="activity-item">
                <div className="activity-icon">
                  <span className={`icon ${activity.type}`}>
                    {activity.icon}
                  </span>
                </div>
                <div className="activity-content">
                  <span className="activity-action">{activity.action}</span>
                  <span className="activity-target">{activity.target}</span>
                  <span className="activity-time">{activity.time}</span>
                </div>
                {activity.value && (
                  <span className="activity-value">{activity.value}</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>

    {/* Top Moments Showcase */}
    <div className="top-moments-showcase">
      <div className="showcase-header">
        <h3>Featured Collection</h3>
        <button className="customize-btn">Customize</button>
      </div>
      <div className="showcase-grid">
        {topMoments.map((moment, index) => (
          <div key={moment.id} className="showcase-moment">
            <div className="showcase-rank">#{index + 1}</div>
            <div className="showcase-image">
              <img src={moment.image} alt={moment.title} loading="lazy" />
              <div className={`showcase-rarity ${moment.rarity.toLowerCase()}`}>
                {moment.rarity}
              </div>
            </div>
            <div className="showcase-info">
              <h4 className="showcase-title">{moment.title}</h4>
              <p className="showcase-franchise">{moment.franchise}</p>
              <div className="showcase-value">
                <span className="current-value">{moment.value}</span>
                <span className="value-change positive">{moment.change}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
));

CollectionOverview.displayName = "CollectionOverview";

const SearchAndFilter = React.memo(
  ({ searchTerm, onSearchChange, onFilterToggle, filterCount }) => (
    <div className="search-filter-container">
      <div className="search-input-container">
        <svg className="search-icon" width="16" height="16" fill="currentColor">
          <path d="M11.5 9.5L15 13M6.5 12C9.26142 12 11.5 9.76142 11.5 7C11.5 4.23858 9.26142 2 6.5 2C3.73858 2 1.5 4.23858 1.5 7C1.5 9.76142 3.73858 12 6.5 12Z" />
        </svg>
        <input
          type="text"
          placeholder="Search your collection..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          className="search-input"
        />
        {searchTerm && (
          <button
            className="clear-search"
            onClick={() => onSearchChange("")}
            aria-label="Clear search"
          >
            ×
          </button>
        )}
      </div>

      <button className="filter-toggle" onClick={onFilterToggle}>
        <svg width="16" height="16" fill="currentColor">
          <path d="M3 6L9 12L15 6H3Z" />
        </svg>
        Filters
        {filterCount > 0 && <span className="filter-count">{filterCount}</span>}
      </button>

      <div className="view-toggles">
        <button className="view-toggle active" aria-label="Grid view">
          <svg width="16" height="16" fill="currentColor">
            <path d="M2 2H6V6H2V2ZM8 2H12V6H8V2ZM2 8H6V12H2V8ZM8 8H12V12H8V8Z" />
          </svg>
        </button>
        <button className="view-toggle" aria-label="List view">
          <svg width="16" height="16" fill="currentColor">
            <path d="M2 4H14V6H2V4ZM2 8H14V10H2V8ZM2 12H14V14H2V12Z" />
          </svg>
        </button>
      </div>
    </div>
  ),
);

SearchAndFilter.displayName = "SearchAndFilter";

const OptimizedProfileScreen = () => {
  const { username } = useParams();
  const navigate = useNavigate();

  // State management
  const [activeTab, setActiveTab] = useState("overview");
  const [searchTerm, setSearchTerm] = useState("");
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [sortBy] = useState("recent");
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Simulate data loading
  useEffect(() => {
    const loadProfileData = async () => {
      try {
        setIsLoading(true);
        // Simulate API call with shorter delay
        await new Promise((resolve) => setTimeout(resolve, 300));
        setError(null);
      } catch (err) {
        setError("Failed to load profile data");
      } finally {
        setIsLoading(false);
      }
    };

    if (username) {
      loadProfileData();
    }
  }, [username]);

  // Mock data - in real app would come from API
  const mockUser = useMemo(
    () => ({
      id: "james-blackwood",
      username: "James Blackwood",
      profileImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/5f169eedaef56da042fcfbf6a0bb57dfb38ee65b",
      joinedDate: "Nov 2024",
      location: "United States",
      totalMoments: 8,
      portfolioValue: "$124.6K",
      rank: "#2,847",
      verified: true,
      socials: {
        youtube: "https://youtube.com/@jamesblackwood",
        twitter: "https://twitter.com/jamesblackwood",
        discord: "https://discord.gg/jamesblackwood",
        twitch: "https://twitch.tv/jamesblackwood",
        reddit: "https://reddit.com/u/jamesblackwood",
        tiktok: "https://tiktok.com/@jamesblackwood",
      },
    }),
    [],
  );

  const mockStats = useMemo(
    () => ({
      totalValue: "$124,680",
      bestPerformer: "Iron Man Reveal",
      legendary: 3,
      franchises: 6,
      completionRate: 67,
      recentActivity: [
        {
          type: "purchase",
          icon: "🎬",
          action: "Acquired",
          target: "Dune - Paul vs Feyd-Rautha",
          time: "2 days ago",
          value: "$2,100",
        },
        {
          type: "showcase",
          icon: "⭐",
          action: "Added to Showcase",
          target: "The Snap - Avengers: Endgame",
          time: "1 week ago",
        },
        {
          type: "achievement",
          icon: "🏆",
          action: "Achievement Unlocked",
          target: "Legendary Collector",
          time: "2 weeks ago",
        },
      ],
    }),
    [],
  );

  const mockMoments = useMemo(
    () => [
      {
        id: 1,
        title: "Iron Man Reveal",
        franchise: "Marvel",
        thumbnail:
          "https://cdn.builder.io/api/v1/image/assets/TEMP/392c23981a1ba4a806624e3c38b765e54eea65bd",
        rarity: "Legendary",
        currentValue: "$25,950",
        valueChange: "12.4%",
        ownedDate: "2 months ago",
      },
      {
        id: 2,
        title: "The Snap",
        franchise: "Marvel",
        thumbnail:
          "https://cdn.builder.io/api/v1/image/assets/TEMP/ea88a267200b7dc1e4b87644bb23269578ea6c41",
        rarity: "Legendary",
        currentValue: "$31,200",
        valueChange: "8.7%",
        ownedDate: "3 months ago",
      },
      // ... more moments
    ],
    [],
  );

  const tabs = useMemo(
    () => [
      { id: "overview", label: "Overview", icon: "📊" },
      {
        id: "moments",
        label: "Moments",
        icon: "🎬",
        count: mockUser.totalMoments,
      },
      { id: "showcase", label: "Showcase", icon: "⭐" },
      { id: "activity", label: "Activity", icon: "📈" },
      { id: "settings", label: "Settings", icon: "⚙️" },
    ],
    [mockUser.totalMoments],
  );

  // Event handlers
  const handleTabChange = useCallback((tabId) => {
    setActiveTab(tabId);
  }, []);

  const handleSearchChange = useCallback((term) => {
    setSearchTerm(term);
  }, []);

  const handleMomentSelect = useCallback(
    (moment) => {
      navigate(`/moment/${moment.id}`);
    },
    [navigate],
  );

  const handleEdit = useCallback(() => {
    console.log("Edit profile");
  }, []);

  const handleShare = useCallback(async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: `${mockUser.username}'s Profile - CrowdFlix`,
          url: window.location.href,
        });
      } else {
        await navigator.clipboard.writeText(window.location.href);
        // Show toast notification
      }
    } catch (err) {
      console.error("Share failed:", err);
    }
  }, [mockUser.username]);

  const filteredMoments = useMemo(() => {
    let filtered = mockMoments;

    if (searchTerm) {
      filtered = filtered.filter(
        (moment) =>
          moment.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          moment.franchise.toLowerCase().includes(searchTerm.toLowerCase()),
      );
    }

    // Sort by selected criteria
    switch (sortBy) {
      case "value": {
        filtered.sort(
          (a, b) =>
            parseFloat(b.currentValue.replace(/[$,]/g, "")) -
            parseFloat(a.currentValue.replace(/[$,]/g, "")),
        );
        break;
      }
      case "rarity": {
        const rarityOrder = { Legendary: 3, Ultimate: 2, Fan: 1 };
        filtered.sort(
          (a, b) => (rarityOrder[b.rarity] || 0) - (rarityOrder[a.rarity] || 0),
        );
        break;
      }
      default:
        // Keep original order (recent)
        break;
    }

    return filtered;
  }, [mockMoments, searchTerm, sortBy]);

  // Render different tab content
  const renderTabContent = () => {
    switch (activeTab) {
      case "overview":
        return (
          <CollectionOverview
            stats={mockStats}
            topMoments={mockMoments.slice(0, 3)}
          />
        );

      case "moments":
        return (
          <div className="moments-tab-content">
            <SearchAndFilter
              searchTerm={searchTerm}
              onSearchChange={handleSearchChange}
              onFilterToggle={() => setIsFilterOpen(!isFilterOpen)}
              filterCount={0}
            />

            <div className="moments-grid">
              {filteredMoments.map((moment) => (
                <MomentCard
                  key={moment.id}
                  moment={moment}
                  onSelect={handleMomentSelect}
                />
              ))}
            </div>

            {filteredMoments.length === 0 && (
              <div className="empty-state">
                <div className="empty-state-icon">🔍</div>
                <h3>No moments found</h3>
                <p>Try adjusting your search or filters</p>
              </div>
            )}
          </div>
        );

      case "showcase":
        return (
          <div className="showcase-tab-content">
            <div className="showcase-intro">
              <h2>Your Showcase</h2>
              <p>
                Highlight your most prized moments for other collectors to see
              </p>
            </div>
            <div className="showcase-featured">
              {mockMoments.slice(0, 3).map((moment, index) => (
                <div key={moment.id} className="featured-moment">
                  <div className="featured-rank">#{index + 1}</div>
                  <img
                    src={moment.thumbnail}
                    alt={moment.title}
                    loading="lazy"
                  />
                  <div className="featured-info">
                    <h4>{moment.title}</h4>
                    <p>{moment.franchise}</p>
                    <span className="featured-value">
                      {moment.currentValue}
                    </span>
                  </div>
                </div>
              ))}
            </div>
            <button className="customize-showcase-btn">
              Customize Showcase
            </button>
          </div>
        );

      default:
        return (
          <div className="tab-content-placeholder">
            <div className="coming-soon">
              <h3>{tabs.find((t) => t.id === activeTab)?.label}</h3>
              <p>Coming soon...</p>
            </div>
          </div>
        );
    }
  };

  // Loading state
  if (isLoading) {
    return <ProfileLoadingScreen />;
  }

  // Error state
  if (error) {
    return (
      <div className="profile-error-screen">
        <div className="error-content">
          <div className="error-icon">⚠️</div>
          <h2>Unable to load profile</h2>
          <p>{error}</p>
          <button
            className="retry-button"
            onClick={() => window.location.reload()}
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="optimized-profile-screen">
      <ProfileHeader
        user={mockUser}
        onEdit={handleEdit}
        onShare={handleShare}
      />

      <TabNavigation
        tabs={tabs}
        activeTab={activeTab}
        onTabChange={handleTabChange}
      />

      <main className="profile-main-content">{renderTabContent()}</main>
    </div>
  );
};

// PropTypes
ProfileHeader.propTypes = {
  user: PropTypes.object.isRequired,
  onEdit: PropTypes.func.isRequired,
  onShare: PropTypes.func.isRequired,
};

TabNavigation.propTypes = {
  tabs: PropTypes.array.isRequired,
  activeTab: PropTypes.string.isRequired,
  onTabChange: PropTypes.func.isRequired,
};

MomentCard.propTypes = {
  moment: PropTypes.object.isRequired,
  onSelect: PropTypes.func.isRequired,
};

CollectionOverview.propTypes = {
  stats: PropTypes.object.isRequired,
  topMoments: PropTypes.array.isRequired,
};

SearchAndFilter.propTypes = {
  searchTerm: PropTypes.string.isRequired,
  onSearchChange: PropTypes.func.isRequired,
  onFilterToggle: PropTypes.func.isRequired,
  filterCount: PropTypes.number.isRequired,
};

export default OptimizedProfileScreen;
