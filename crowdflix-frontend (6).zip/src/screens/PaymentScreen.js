import React, { useState, useEffect, useMemo, useCallback, memo } from "react";
import PropTypes from "prop-types";
import { useParams, useNavigate } from "react-router-dom";

// Memoized sample payment data
const samplePaymentData = {
  "iron-man-reveal": {
    id: "iron-man-reveal",
    number: "#1024",
    title: "Tron: Ares",
    creator: "Crowdflix Admin",
    soldTotal: "3533/5000",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel velit sem. Nullam nec tincidunt velit. Donec odio dolor, sollicitudin lacinia bibendum nec, laoreet eu sem. Cras ac urna mattis arcu convallis semper. Curabitur efficitur nisi augue, eu egestas nibh efficitur eu.",
    mainThumbnail:
      "https://cdn.builder.io/api/v1/image/assets/TEMP/main-thumbnail",
    thumbnails: Array(7).fill(
      "https://cdn.builder.io/api/v1/image/assets/TEMP/thumbnail",
    ),
    metadata: {
      director: "N/A",
      writers: "N/A",
      producers: "N/A",
      composers: "N/A",
      cinematographer: "N/A",
      releaseDate: "N/A",
      totalSupply: "N/A",
    },
    pricing: {
      lowestAsk: "$13.00",
      avgSale: "$14.00",
      forSale: "50",
    },
    ownershipStats: [
      { label: "Unlisted (Owned)", value: "306" },
      { label: "For Sale (Owned)", value: "80" },
      { label: "Locked (Owned)", value: "15" },
      { label: "Hidden In Packs", value: "1,200" },
      { label: "In The Locker", value: "00" },
      { label: "Burned", value: "01" },
    ],
  },
};

// Memoized components for better performance
const ThumbnailPlaceholder = memo(({ index }) => (
  <div key={index} className="side-thumbnail">
    <div className="side-thumbnail-content">
      <div className="thumbnail-bg-small"></div>
      <div className="thumbnail-border-small"></div>
      <div className="play-icon-circle-small"></div>
      <svg
        className="play-icon-small-1"
        width="25"
        height="18"
        viewBox="0 0 25 18"
        fill="none"
      >
        <path
          d="M3.74102 17.3395C3.03664 18.0338 1.89953 18.0289 1.20121 17.3285C0.502886 16.6282 0.5078 15.4975 1.21218 14.8032L15.9832 0.242676L24.3086 7.44284C25.0569 8.09008 25.1359 9.218 24.485 9.96212C23.834 10.7062 22.6997 10.7848 21.9513 10.1375L16.143 5.11425L3.74102 17.3395Z"
          fill="#A0A0A0"
        />
      </svg>
      <svg
        className="play-icon-small-2"
        width="38"
        height="27"
        viewBox="0 0 38 27"
        fill="none"
      >
        <path
          d="M3.21631 26.334C2.51498 27.0314 1.37786 27.0314 0.676466 26.3341C-0.0249235 25.6367 -0.0249742 24.5061 0.676353 23.8087L24.3133 0.304199L37.2537 11.5938C37.9992 12.2443 38.0733 13.3726 37.4191 14.1139C36.765 14.8552 35.6302 14.9288 34.8847 14.2784L24.4738 5.19557L3.21631 26.334Z"
          fill="#A0A0A0"
        />
      </svg>
    </div>
  </div>
));

ThumbnailPlaceholder.displayName = "ThumbnailPlaceholder";
ThumbnailPlaceholder.propTypes = {
  index: PropTypes.number.isRequired,
};

const NavItem = memo(({ children, active = false, onClick }) => (
  <div
    className={`nav-item ${active ? "active" : ""}`}
    onClick={onClick}
    role="button"
    tabIndex={0}
    onKeyDown={(e) => e.key === "Enter" && onClick?.()}
  >
    {children}
  </div>
));

NavItem.displayName = "NavItem";
NavItem.propTypes = {
  children: PropTypes.node.isRequired,
  active: PropTypes.bool,
  onClick: PropTypes.func,
};

const MetadataItem = memo(({ label, value }) => (
  <div className="metadata-item">
    <span className="meta-label">{label}: </span>
    <span className="meta-value">{value}</span>
  </div>
));

MetadataItem.displayName = "MetadataItem";
MetadataItem.propTypes = {
  label: PropTypes.string.isRequired,
  value: PropTypes.string.isRequired,
};

const StatCard = memo(({ stat }) => (
  <div className="stat-card">
    <div className="stat-label">{stat.label}</div>
    <div className="stat-number">{stat.value}</div>
  </div>
));

StatCard.displayName = "StatCard";
StatCard.propTypes = {
  stat: PropTypes.shape({
    label: PropTypes.string.isRequired,
    value: PropTypes.string.isRequired,
  }).isRequired,
};

const CollapsibleSection = memo(({ title, isExpanded, onToggle, children }) => (
  <div className="section-card">
    <div
      className="section-header"
      onClick={onToggle}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === "Enter" && onToggle()}
      aria-expanded={isExpanded}
    >
      <h3 className="section-title">{title}</h3>
      <svg
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        className={`section-chevron ${isExpanded ? "expanded" : ""}`}
        aria-hidden="true"
      >
        <path
          d="M11.9998 8.65551C11.8793 8.65551 11.7671 8.67476 11.6633 8.71326C11.5594 8.75176 11.4607 8.81776 11.367 8.91126L6.87276 13.4055C6.73442 13.544 6.66359 13.7181 6.66026 13.9278C6.65709 14.1373 6.72792 14.3145 6.87276 14.4595C7.01776 14.6043 7.19342 14.6768 7.39976 14.6768C7.60609 14.6768 7.78176 14.6043 7.92676 14.4595L11.9998 10.3863L16.0728 14.4595C16.2113 14.5978 16.3853 14.6687 16.595 14.672C16.8045 14.6752 16.9818 14.6043 17.1268 14.4595C17.2716 14.3145 17.344 14.1388 17.344 13.9325C17.344 13.7262 17.2716 13.5505 17.1268 13.4055L12.6325 8.91126C12.5388 8.81776 12.4401 8.75176 12.3363 8.71326C12.2324 8.67476 12.1203 8.65551 11.9998 8.65551Z"
          fill="#181818"
        />
      </svg>
    </div>
    {isExpanded && <div className="section-content">{children}</div>}
  </div>
));

CollapsibleSection.displayName = "CollapsibleSection";
CollapsibleSection.propTypes = {
  title: PropTypes.string.isRequired,
  isExpanded: PropTypes.bool.isRequired,
  onToggle: PropTypes.func.isRequired,
  children: PropTypes.node.isRequired,
};

function PaymentScreen() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [moment, setMoment] = useState(null);
  const [expandedSections, setExpandedSections] = useState({
    descriptions: true,
    properties: false,
    salesHistory: false,
    bids: false,
  });

  // Memoized callbacks
  const toggleSection = useCallback((sectionName) => {
    setExpandedSections((prev) => ({
      ...prev,
      [sectionName]: !prev[sectionName],
    }));
  }, []);

  const handleNavigation = useCallback(
    (path) => {
      navigate(path);
    },
    [navigate],
  );

  const handleBackToMoment = useCallback(() => {
    navigate(`/moment/${id}`);
  }, [navigate, id]);

  // Memoized moment data
  const momentData = useMemo(() => {
    return samplePaymentData[id] || samplePaymentData["iron-man-reveal"];
  }, [id]);

  // Memoized thumbnail elements
  const thumbnailElements = useMemo(
    () =>
      momentData.thumbnails.map((_, index) => (
        <ThumbnailPlaceholder key={index} index={index} />
      )),
    [momentData.thumbnails],
  );

  // Memoized metadata elements
  const metadataElements = useMemo(
    () =>
      Object.entries(momentData.metadata).map(([key, value]) => (
        <MetadataItem
          key={key}
          label={key.charAt(0).toUpperCase() + key.slice(1)}
          value={value}
        />
      )),
    [momentData.metadata],
  );

  // Memoized stat elements
  const statElements = useMemo(
    () =>
      momentData.ownershipStats.map((stat, index) => (
        <StatCard key={index} stat={stat} />
      )),
    [momentData.ownershipStats],
  );

  useEffect(() => {
    setMoment(momentData);
  }, [momentData]);

  if (!moment) {
    return (
      <div className="payment-loading">
        <div className="enhanced-loading">
          <div className="loading-container">
            <div className="loading-spinner"></div>
            <div className="loading-text">Loading payment details...</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="payment-screen">
      {/* Navigation Bar */}
      <nav
        className="payment-navbar"
        role="navigation"
        aria-label="Main navigation"
      >
        <div className="navbar-content">
          <div className="nav-left">
            <img
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/2b277229eb4e3a488d74ea637c8bd3e06ab053fc"
              alt="CrowdFlix Logo"
              className="nav-logo"
              loading="eager"
              decoding="async"
            />
          </div>
          <div className="nav-center">
            <NavItem onClick={() => handleNavigation("/")}>Home</NavItem>
            <NavItem active onClick={() => handleNavigation("/marketplace")}>
              Marketplace
            </NavItem>
            <NavItem onClick={() => handleNavigation("/u/james-blackwood")}>
              My Collection
            </NavItem>
            <NavItem>Wallet</NavItem>
            <NavItem>History</NavItem>
            <NavItem>Settings</NavItem>
          </div>
          <div className="nav-right">
            <div className="search-container">
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                aria-hidden="true"
              >
                <g opacity="0.5">
                  <path
                    d="M9.51955 15.6153C7.81188 15.6153 6.36571 15.023 5.18105 13.8385C3.99655 12.6538 3.4043 11.2077 3.4043 9.50002C3.4043 7.79235 3.99655 6.34618 5.18105 5.16152C6.36571 3.97702 7.81188 3.38477 9.51955 3.38477C11.2272 3.38477 12.6734 3.97702 13.858 5.16152C15.0425 6.34618 15.6348 7.79235 15.6348 9.50002C15.6348 10.2142 15.515 10.8963 15.2753 11.5463C15.0355 12.1963 14.7155 12.7616 14.3155 13.2423L20.0695 18.9963C20.208 19.1346 20.2789 19.3086 20.282 19.5183C20.2852 19.7279 20.2144 19.9052 20.0695 20.05C19.9247 20.1948 19.749 20.2673 19.5425 20.2673C19.3362 20.2673 19.1606 20.1948 19.0158 20.05L13.2618 14.296C12.7618 14.7088 12.1868 15.0319 11.5368 15.2653C10.8868 15.4986 10.2144 15.6153 9.51955 15.6153ZM9.51955 14.1155C10.808 14.1155 11.8994 13.6683 12.7935 12.774C13.6879 11.8798 14.135 10.7885 14.135 9.50002C14.135 8.21152 13.6879 7.12018 12.7935 6.22601C11.8994 5.33168 10.808 4.88452 9.51955 4.88452C8.23105 4.88452 7.13971 5.33168 6.24555 6.22601C5.35121 7.12018 4.90405 8.21152 4.90405 9.50002C4.90405 10.7885 5.35121 11.8798 6.24555 12.774C7.13971 13.6683 8.23105 14.1155 9.51955 14.1155Z"
                    fill="white"
                  />
                </g>
              </svg>
              <span>Search projects</span>
            </div>
            <div className="user-avatar">
              <span>KP</span>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="payment-content">
        <div className="payment-container">
          {/* Trending Films Section */}
          <section
            className="trending-section"
            aria-labelledby="moment-details"
          >
            <div className="moment-gallery">
              {/* Main Thumbnail */}
              <div className="main-thumbnail">
                <div className="thumbnail-placeholder">
                  <div className="thumbnail-content">
                    <div className="thumbnail-bg"></div>
                    <div className="thumbnail-border"></div>
                    <div className="play-icon-circle"></div>
                    <svg
                      className="play-icon-1"
                      width="56"
                      height="41"
                      viewBox="0 0 56 41"
                      fill="none"
                      aria-hidden="true"
                    >
                      <path
                        d="M7.24063 39.1876C5.64873 40.7568 3.07885 40.7457 1.50064 39.1629C-0.0775605 37.58 -0.0664529 35.0248 1.52545 33.4556L34.908 0.548828L53.7232 16.8212C55.4146 18.284 55.5931 20.8331 54.122 22.5148C52.6508 24.1965 50.0871 24.374 48.3958 22.9112L35.2691 11.5586L7.24063 39.1876Z"
                        fill="#A0A0A0"
                      />
                    </svg>
                    <svg
                      className="play-icon-2"
                      width="86"
                      height="61"
                      viewBox="0 0 86 61"
                      fill="none"
                      aria-hidden="true"
                    >
                      <path
                        d="M7.6946 59.1749C6.1096 60.751 3.53969 60.7511 1.95455 59.1751C0.369415 57.5992 0.3693 55.0439 1.9543 53.4678L55.3738 0.347656L84.619 25.8622C86.304 27.3323 86.4714 29.8821 84.993 31.5575C83.5145 33.2328 80.9501 33.3993 79.2651 31.9293L55.7366 11.4021L7.6946 59.1749Z"
                        fill="#A0A0A0"
                      />
                    </svg>
                  </div>
                </div>
              </div>

              {/* Side Thumbnails */}
              <div className="side-thumbnails">{thumbnailElements}</div>
            </div>

            {/* Moment Details */}
            <div className="moment-details">
              <header className="moment-header" id="moment-details">
                <div className="moment-info">
                  <div className="moment-number">{moment.number}</div>
                  <h1 className="moment-title">{moment.title}</h1>
                  <div className="moment-creator">{moment.creator}</div>
                </div>
                <div className="sold-badge">
                  <span>Sold/Total: </span>
                  <span className="sold-numbers">{moment.soldTotal}</span>
                </div>
              </header>

              <p className="moment-description">{moment.description}</p>

              <div className="moment-metadata">{metadataElements}</div>

              <div className="pricing-section">
                <div className="pricing-left">
                  <div className="lowest-ask-label">Lowest Ask:</div>
                  <div className="price-display">
                    <span className="price-amount">$13.00 </span>
                    <span className="price-currency">USD</span>
                  </div>
                </div>
                <div className="pricing-stats">
                  <div className="pricing-stat">
                    <span className="stat-label">Avg Sale:</span>
                    <span className="stat-value"> $14.00 USD</span>
                  </div>
                  <div className="stat-divider">|</div>
                  <div className="pricing-stat">
                    <span className="stat-value">50 for Sale</span>
                  </div>
                </div>
              </div>

              <div className="action-buttons">
                <button
                  className="make-offer-btn"
                  aria-label="Make an offer for this moment"
                >
                  Make an offer
                </button>
                <button
                  className="select-buy-btn"
                  onClick={handleBackToMoment}
                  aria-label="Go back to moment details"
                >
                  Back to Moment
                </button>
              </div>
            </div>
          </section>

          {/* Collapsible Sections */}
          <section
            className="collapsible-sections"
            aria-label="Additional information"
          >
            <CollapsibleSection
              title="Descriptions"
              isExpanded={expandedSections.descriptions}
              onToggle={() => toggleSection("descriptions")}
            >
              <p className="description-text">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Praesent vel velit sem. Nullam nec tincidunt velit. Donec odio
                dolor, sollicitudin lacinia bibendum nec, laoreet eu sem. Cras
                ac urna mattis arcu convallis semper. Curabitur efficitur nisi
                augue, eu egestas nibh efficitur eu. Nam vestibulum a sapien at
                blandit. Pellentesque lacinia est vel ipsum vehicula gravida.
                Morbi varius, urna ut egestas euismod, ipsum orci aliquet massa,
                in commodo nunc massa in orci. Curabitur et enim id risus
                tincidunt posuere sit amet et orci. In vehicula lacinia felis
                imperdiet mattis. Duis tincidunt leo sapien, sed dictum eros
                rutrum ut. Praesent turpis nulla, interdum et elit a, semper
                pulvinar metus. Curabitur non bibendum libero. Nunc laoreet
                tempus ex et tempor. Pellentesque habitant morbi tristique
                senectus et netus et malesuada fames ac turpis egestas.
                Suspendisse tempor, orci porttitor vulputate tincidunt, ex
                libero faucibus lorem, sed sollicitudin erat leo sed mi.
              </p>
              <p className="description-text">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Praesent vel velit sem. Nullam nec tincidunt velit. Donec odio
                dolor, sollicitudin lacinia bibendum nec, laoreet eu sem. Cras
                ac urna mattis arcu convallis semper. Curabitur efficitur nisi
                augue, eu egestas nibh efficitur eu. Nam vestibulum a sapien at
                blandit. Pellentesque lacinia est vel ipsum vehicula gravida.
              </p>

              <div className="ownership-stats">{statElements}</div>
            </CollapsibleSection>

            <CollapsibleSection
              title="Properties"
              isExpanded={expandedSections.properties}
              onToggle={() => toggleSection("properties")}
            >
              <div>Properties content would go here</div>
            </CollapsibleSection>

            <CollapsibleSection
              title="Sales History"
              isExpanded={expandedSections.salesHistory}
              onToggle={() => toggleSection("salesHistory")}
            >
              <div>Sales history content would go here</div>
            </CollapsibleSection>

            <CollapsibleSection
              title="Bids"
              isExpanded={expandedSections.bids}
              onToggle={() => toggleSection("bids")}
            >
              <div>Bids content would go here</div>
            </CollapsibleSection>
          </section>
        </div>
      </main>
    </div>
  );
}

export default memo(PaymentScreen);
