import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import ProfileHeader from "../components/ProfileHeader";
import VaultSnapshot from "../components/VaultSnapshot";
import ProfileTabs from "../components/ProfileTabs";
import FollowedStudios from "../components/FollowedStudios";
import LeaderboardsBadges from "../components/LeaderboardsBadges";
import performanceOptimizer from "../utils/performanceOptimizer";

const PublicProfileScreen = () => {
  const { username } = useParams();
  const [activeTab, setActiveTab] = useState("vault");
  const [isFollowing, setIsFollowing] = useState(false);

  // Sample profile data - would come from API
  const profileData = {
    username: username || "theFinalCut",
    displayName: "Elena Rodriguez",
    avatar:
      "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F5e148d405afb49af9f0c88cf18b93bf7",
    tagline: "I collect heartbreak and revenge.",
    isVerified: true,
    letterboxdConnected: false,
    followerCount: 2847,
    followingCount: 395,
    badges: [
      {
        id: "vault-architect",
        name: "Vault Architect",
        icon: "����",
        rarity: "legendary",
      },
      { id: "remix-legend", name: "Remix Legend", icon: "🎧", rarity: "epic" },
      { id: "first-drop", name: "First Drop OG", icon: "🟡", rarity: "rare" },
      {
        id: "vault-streak",
        name: "Vault Streak (30 days)",
        icon: "🔥",
        rarity: "immortal",
      },
      {
        id: "scene-influencer",
        name: "Scene Influencer",
        icon: "📣",
        rarity: "legendary",
      },
    ],
    stats: {
      vaultedMoments: 247,
      tradesCompleted: 18,
      remixesCreated: 12,
      mostCollectedEmotion: "💔 Loss",
      totalVaultValue: "$45,200",
      joinDate: "March 2023",
    },
    topMoments: [
      {
        id: "top-1",
        title: "I Am Iron Man",
        filmSeries: "Iron Man",
        emotionTag: "💥 Defiance",
        rarity: "immortal",
        thumbnailUrl:
          "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F35be60d44b714f869e2fd177463466d3",
        videoUrl:
          "https://cdn.builder.io/o/assets%2FYJIGb4i01jvw0SRdL5Bt%2Fd27731a526464deba0016216f5f9e570%2Fcompressed",
        caption: "This scene raised me.",
        owned: true,
      },
      {
        id: "top-2",
        title: "The Snap",
        filmSeries: "Avengers: Infinity War",
        emotionTag: "💔 Loss",
        rarity: "legendary",
        thumbnailUrl:
          "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fa3cb973601e7471a9b4d0c02a2bafd37",
        caption: "First time I cried in a theater.",
        owned: true,
      },
      {
        id: "top-3",
        title: "Wilson!",
        filmSeries: "Cast Away",
        emotionTag: "💔 Loss",
        rarity: "epic",
        thumbnailUrl:
          "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F5a1c0dbf6e324f6a88e34e2230cae9b7",
        caption: "Friendship beyond words.",
        owned: true,
      },
      {
        id: "top-4",
        title: "Here's Johnny!",
        filmSeries: "The Shining",
        emotionTag: "😱 Terror",
        rarity: "legendary",
        thumbnailUrl:
          "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F12d9e666c7e049b6a4d62f67ffdc2e27",
        caption: "Peak horror perfection.",
        owned: true,
      },
      {
        id: "top-5",
        title: "Mufasa's Death",
        filmSeries: "The Lion King",
        emotionTag: "💔 Grief",
        rarity: "epic",
        thumbnailUrl:
          "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F6ebffc23d7d44c2190d242565dd9fdb9",
        caption: "Childhood heartbreak defined.",
        owned: true,
      },
      {
        id: "top-6",
        title: "Dance Scene",
        filmSeries: "Pulp Fiction",
        emotionTag: "✨ Cool",
        rarity: "rare",
        thumbnailUrl:
          "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F0edbd217878f45f8b5d952459c17a199",
        caption: "Style and substance.",
        owned: true,
      },
    ],
    followedStudios: [
      { name: "A24", logo: "🎭", type: "studio" },
      { name: "Lionsgate", logo: "🦁", type: "studio" },
      { name: "Crunchyroll", logo: "🍥", type: "platform" },
    ],
    joinedTribes: [
      { name: "Team Anti-Hero", logo: "😈", memberCount: 15420 },
      { name: "Sad Girl Canon", logo: "💙", memberCount: 8932 },
      { name: "Anime Vault Builders", logo: "🌸", memberCount: 12054 },
    ],
    leaderboards: [
      { title: "Top Vault XP", rank: 8, total: 50000, icon: "🔥" },
      { title: "Remix Leaderboard", rank: 15, period: "monthly", icon: "👑" },
      {
        title: "Fastest Collector",
        rank: 3,
        period: "Last 30 Days",
        icon: "📈",
      },
    ],
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  const handleFollow = () => {
    setIsFollowing(!isFollowing);
  };

  // Optimize performance for profile page
  useEffect(() => {
    // Re-observe elements after profile content loads
    setTimeout(() => {
      performanceOptimizer.observeElements();
    }, 100);
  }, [username]);

  return (
    <div className="public-profile">
      {/* Header Block - Identity Snapshot */}
      <ProfileHeader
        profile={profileData}
        isFollowing={isFollowing}
        onFollow={handleFollow}
      />

      {/* Vault Snapshot - Above the Fold */}
      <VaultSnapshot moments={profileData.topMoments} />

      {/* Main Content Area */}
      <div className="public-profile__main">
        {/* Main Tabs */}
        <ProfileTabs
          activeTab={activeTab}
          onTabChange={handleTabChange}
          profile={profileData}
        />

        {/* Sidebar Content */}
        <div className="public-profile__sidebar">
          {/* Followed Studios + Tribes */}
          <FollowedStudios
            studios={profileData.followedStudios}
            tribes={profileData.joinedTribes}
          />

          {/* Leaderboards + Progress Badges */}
          <LeaderboardsBadges
            leaderboards={profileData.leaderboards}
            badges={profileData.badges}
          />
        </div>
      </div>
    </div>
  );
};

PublicProfileScreen.propTypes = {
  // Props would be defined here if needed
};

export default PublicProfileScreen;
