import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addMomentToFirestore } from '../features/moments/momentSlice';
import { selectTiers } from '../features/tiers/tierSlice';
import Multiselect from 'multiselect-react-dropdown';
import { collection, addDoc } from 'firebase/firestore';
import { storage } from "../firebase";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
import Countdown from '../assets/videos/countdown.mp4';
import Crowdflix from '../assets/images/crowdflix_logo.png'

function CreateMomentScreen() {


    const dispatch = useDispatch();
    const tiers = useSelector(selectTiers); // Get tiers from Redux

    // Dummy moments array
    const dummyMoments = [
        {
            momentName: "The Final Duel",
            momentDescription: "An intense sword fight that decides the fate of the kingdom.",
            momentMovie: "The Last Warrior",
            productionHouse: "Legendary Pictures",
            momentThumbnailImg: "https://i.ibb.co/NdTVZDK3/image.webp",
            momentThumbnailVideo: "https://www.w3schools.com/html/mov_bbb.mp4",
            tier: tiers.find(t => t.tierName === "Legendary"),
            lowestAsk: 500,
            averageSale: 450
        },
        {
            momentName: "First Encounter",
            momentDescription: "The hero meets the villain for the first time.",
            momentMovie: "Dark Shadows",
            productionHouse: "Warner Bros",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video2.mp4",
            tier: tiers.find(t => t.tierName === "Ultimate"),
            lowestAsk: 350,
            averageSale: 300
        },
        {
            momentName: "Spaceship Launch",
            momentDescription: "A breathtaking scene of the first intergalactic voyage.",
            momentMovie: "Galactic Odyssey",
            productionHouse: "Universal Pictures",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video3.mp4",
            tier: tiers.find(t => t.tierName === "Rare"),
            lowestAsk: 200,
            averageSale: 180
        },
        {
            momentName: "Dystopian Escape",
            momentDescription: "The protagonist breaks free from the oppressive system.",
            momentMovie: "Rebel City",
            productionHouse: "20th Century Studios",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video4.mp4",
            tier: tiers.find(t => t.tierName === "Fan"),
            lowestAsk: 100,
            averageSale: 90
        },
        {
            momentName: "Cliffhanger Decision",
            momentDescription: "The hero must choose between saving a friend or the city.",
            momentMovie: "The Last Stand",
            productionHouse: "Paramount Pictures",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video5.mp4",
            tier: tiers.find(t => t.tierName === "Legendary"),
            lowestAsk: 450,
            averageSale: 420
        },
        {
            momentName: "Underwater Rescue",
            momentDescription: "A tense moment as the team rescues a trapped diver.",
            momentMovie: "Deep Blue",
            productionHouse: "20th Century Studios",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video6.mp4",
            tier: tiers.find(t => t.tierName === "Rare"),
            lowestAsk: 250,
            averageSale: 230
        },
        {
            momentName: "Superhero Unveiled",
            momentDescription: "The protagonist finally embraces their superpowers.",
            momentMovie: "Rise of the Guardian",
            productionHouse: "Marvel Studios",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video7.mp4",
            tier: tiers.find(t => t.tierName === "Ultimate"),
            lowestAsk: 500,
            averageSale: 470
        },
        {
            momentName: "Race Against Time",
            momentDescription: "The team works together to defuse a bomb.",
            momentMovie: "High Stakes",
            productionHouse: "Columbia Pictures",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video8.mp4",
            tier: tiers.find(t => t.tierName === "Fan"),
            lowestAsk: 150,
            averageSale: 130
        },
        {
            momentName: "Alien Contact",
            momentDescription: "Scientists make first contact with extraterrestrial life.",
            momentMovie: "Beyond Earth",
            productionHouse: "Universal Pictures",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video9.mp4",
            tier: tiers.find(t => t.tierName === "Rare"),
            lowestAsk: 300,
            averageSale: 280
        },
        {
            momentName: "Escape from the Lab",
            momentDescription: "The protagonist flees a top-secret research facility.",
            momentMovie: "The Experiment",
            productionHouse: "Warner Bros",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video10.mp4",
            tier: tiers.find(t => t.tierName === "Legendary"),
            lowestAsk: 400,
            averageSale: 390
        },
        {
            momentName: "The Betrayal",
            momentDescription: "A trusted ally turns against the hero.",
            momentMovie: "Dark Betrayal",
            productionHouse: "20th Century Studios",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video11.mp4",
            tier: tiers.find(t => t.tierName === "Ultimate"),
            lowestAsk: 350,
            averageSale: 330
        },
        {
            momentName: "The Heist",
            momentDescription: "A team of specialists pulls off an impossible heist.",
            momentMovie: "Ocean's Secret",
            productionHouse: "Paramount Pictures",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video12.mp4",
            tier: tiers.find(t => t.tierName === "Rare"),
            lowestAsk: 280,
            averageSale: 250
        },
        {
            momentName: "Lost in Space",
            momentDescription: "Astronauts stranded in deep space fight for survival.",
            momentMovie: "Void",
            productionHouse: "Universal Pictures",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video13.mp4",
            tier: tiers.find(t => t.tierName === "Fan"),
            lowestAsk: 120,
            averageSale: 110
        },
        {
            momentName: "The Grand Reveal",
            momentDescription: "A shocking truth is unveiled, changing everything.",
            momentMovie: "Twist of Fate",
            productionHouse: "Columbia Pictures",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video14.mp4",
            tier: tiers.find(t => t.tierName === "Legendary"),
            lowestAsk: 420,
            averageSale: 400
        },
        {
            momentName: "The Last Goodbye",
            momentDescription: "A heart-wrenching farewell scene.",
            momentMovie: "Final Moments",
            productionHouse: "Warner Bros",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video15.mp4",
            tier: tiers.find(t => t.tierName === "Ultimate"),
            lowestAsk: 300,
            averageSale: 280
        },
        {
            momentName: "Epic Car Chase",
            momentDescription: "A high-speed chase through the city streets.",
            momentMovie: "Speed Run",
            productionHouse: "20th Century Studios",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video16.mp4",
            tier: tiers.find(t => t.tierName === "Rare"),
            lowestAsk: 220,
            averageSale: 200
        },
        {
            momentName: "Legendary Battle",
            momentDescription: "A battle that will be remembered for ages.",
            momentMovie: "Mythic Wars",
            productionHouse: "Paramount Pictures",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video17.mp4",
            tier: tiers.find(t => t.tierName === "Legendary"),
            lowestAsk: 600,
            averageSale: 550
        },
        {
            momentName: "The Ultimate Sacrifice",
            momentDescription: "A hero makes the ultimate sacrifice to save the world.",
            momentMovie: "Hero’s Destiny",
            productionHouse: "Marvel Studios",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video18.mp4",
            tier: tiers.find(t => t.tierName === "Legendary"),
            lowestAsk: 550,
            averageSale: 500
        },
        {
            momentName: "The Secret Unveiled",
            momentDescription: "A long-hidden secret is finally revealed, shocking everyone.",
            momentMovie: "The Hidden Truth",
            productionHouse: "Warner Bros",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video19.mp4",
            tier: tiers.find(t => t.tierName === "Ultimate"),
            lowestAsk: 320,
            averageSale: 290
        },
        {
            momentName: "Escape from the Volcano",
            momentDescription: "The team races against time to escape an erupting volcano.",
            momentMovie: "Lava Run",
            productionHouse: "Universal Pictures",
            momentThumbnailImg: "https://via.placeholder.com/300",
            momentThumbnailVideo: "https://www.example.com/video20.mp4",
            tier: tiers.find(t => t.tierName === "Rare"),
            lowestAsk: 210,
            averageSale: 190
        }
    ];

    // Function to upload dummy data to Firestore

    const uploadVideo = async () => {
        const storageRef = ref(storage, `moment_data/countdown.mp4`);
    
        try {
            // Fetch the video file as a blob
            const response = await fetch(Countdown);
            const blob = await response.blob(); // Convert to Blob
    
            // Upload the Blob to Firebase Storage
            await uploadBytes(storageRef, blob); 
            const videoURL = await getDownloadURL(storageRef); // Get file URL
            console.log('Uploaded Video URL:', videoURL);
    
        } catch (error) {
            console.error("Error uploading video:", error.message);
        }
    };

    const uploadPic = async () => {
        const storageRef = ref(storage, `moment_data/crowdflix.png`);
    
        try {
            // Fetch the video file as a blob
            const response = await fetch(Crowdflix);
            const blob = await response.blob(); // Convert to Blob
    
            // Upload the Blob to Firebase Storage
            await uploadBytes(storageRef, blob); 
            const videoURL = await getDownloadURL(storageRef); // Get file URL
            console.log('Uploaded Video URL:', videoURL);
    
        } catch (error) {
            console.error("Error uploading video:", error.message);
        }
    };


    const addMomentsToFirestore = async () => {
        if (!tiers || tiers.length === 0) {
            alert("Tiers data not available. Make sure tiers are loaded.");
            return;
        }

        try {
            for (let moment of dummyMoments) {
                if (!moment.tier) {
                    console.error(`Tier not found for moment: ${moment.momentName}`);
                    continue; // Skip if tier is missing
                }
                await dispatch(addMomentToFirestore(moment)).unwrap();
                console.log(`Added: ${moment.momentName}`);
            }

            alert("Dummy moments added successfully!");
        } catch (error) {
            console.error("Error adding moment:", error);
            alert("Failed to add moment. You might not have admin rights.");
        }
    };

    return (
        <div className="container text-center my-4">
            <h2>Add Dummy Movie Moments</h2>
            <button className="btn btn-primary" onClick={uploadVideo}>
                Add Dummy Moments
            </button>
        </div>
    );
}

export default CreateMomentScreen;