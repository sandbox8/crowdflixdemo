import React, { useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";

const PaymentSuccessScreen = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const purchaseData = location.state;

  useEffect(() => {
    // Redirect to home if no purchase data
    if (!purchaseData) {
      navigate("/");
    }
  }, [purchaseData, navigate]);

  const handleGoToCollection = () => {
    navigate("/profile/collection"); // Adjust route as needed
  };

  if (!purchaseData) {
    return null;
  }

  return (
    <div className="payment-success-screen">
      {/* Animated background */}
      <div className="success-background">
        <img
          className="background-pattern-1"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/725ab1c76e2888ba1cb8ef564c12b73bc1d8f486"
          alt=""
        />
        <img
          className="background-pattern-2"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/adf600249b784f2f110be06ec183884adc0643e0"
          alt=""
        />
      </div>

      {/* Header */}
      <div className="success-header">
        <button
          className="back-button"
          onClick={() => navigate("/")}
          aria-label="Go back"
        >
          <svg
            width="42"
            height="42"
            viewBox="0 0 42 42"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <rect
              x="1"
              y="1"
              width="40"
              height="40"
              rx="20"
              fill="#FD4725"
              fillOpacity="0.05"
            />
            <rect
              x="1"
              y="1"
              width="40"
              height="40"
              rx="20"
              stroke="#2AA2FD"
              strokeOpacity="0.35"
              strokeLinejoin="bevel"
            />
            <path
              d="M12.9985 21.0001H28.9919"
              stroke="white"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M12.9985 27.4974H28.9919"
              stroke="white"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M12.9985 14.5027H28.9919"
              stroke="white"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>

        <div className="logo">
          <svg
            width="35"
            height="40"
            viewBox="0 0 35 40"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M0 10.8902L18.8981 0L34.8935 8.90519V13.2702L26.3615 18.0689L18.8981 13.48L11.7161 17.7307L7.94454 15.3791L18.8981 8.90519L26.3615 13.48L30.5174 10.8902L18.7341 4.36595L3.92284 12.8715V17.7307L18.8981 26.6319L27.0863 21.7084L34.8935 26.4318V30.9741L18.7341 40L0 28.9657L0 24.2025L18.8981 35.5739L31.0341 28.7468L27.0863 26.4318L18.8981 30.9741L0 20L0 10.8902Z"
              fill="white"
            />
          </svg>
          <span className="logo-text">CROWDFLIX</span>
        </div>

        <div className="user-avatar">
          <img
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/0be9141cd3a2cd490a87bf9bab2add354433a845"
            alt="User"
          />
        </div>
      </div>

      {/* Success content */}
      <div className="success-content">
        <div className="success-modal">
          {/* Success checkmark and animated background */}
          <div className="success-visual">
            <div className="success-images">
              <img
                className="matrix-bg-1"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/72acecf703dbecde68e72d1436d9eb62dbc19570"
                alt=""
              />
              <img
                className="matrix-bg-2"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/72acecf703dbecde68e72d1436d9eb62dbc19570"
                alt=""
              />
            </div>

            <div className="success-icon">
              <svg
                width="32"
                height="32"
                viewBox="0 0 32 32"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M8.5 15.7621L13.9545 21.0002L23.5 11.8335"
                  stroke="white"
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
          </div>

          {/* Success message */}
          <div className="success-message">
            <h1 className="success-title">Payment successful</h1>
            <p className="success-description">
              Thank you for your payment. We will be in contact with more
              details shortly
            </p>
          </div>

          {/* Action button */}
          <button
            className="go-to-collection-button"
            onClick={handleGoToCollection}
          >
            Go to Collection
          </button>
        </div>
      </div>
    </div>
  );
};

export default PaymentSuccessScreen;
