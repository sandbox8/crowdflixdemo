import React, { useState, useEffect } from 'react';

import { useSelector } from 'react-redux';
import { selectCategories } from '../features/categories/categorySlice';
import CategorySelector from '../components/CategorySelector';
import ProjectCardsContainer from '../components/ProjectCardsContainer';
import { selectProjects } from '../features/projects/projectSlice';

function ProjectsScreen() {
    const categories = useSelector(selectCategories);
    const isProjectsLoading = useSelector((state) => state.projects.loading);
    const projects = useSelector(selectProjects);

    const [selectedCategory, setSelectedCategory] = useState({ category: 'All', rank: 0, id: 'category-all' });
    const [filteredProjects, setFilteredProjects] = useState([]);
    const [numProjectsToShow, setNumProjectsToShow] = useState(6);
    const [isExpanded, setIsExpanded] = useState(false);

    const handleCategoryChange = (category) => {
        setSelectedCategory(category);
    };

    const toggleExpandCollapse = () => {
        if (isExpanded) {
            setNumProjectsToShow(6);
        } else {
            setNumProjectsToShow(12);
        }

        setIsExpanded(!isExpanded);
    };

    const resetExpandCollapse = () => {
        setNumProjectsToShow(6);
        setIsExpanded(false);
    };

    useEffect(() => {
        const filtered = selectedCategory.category === 'All'
            ? projects.slice()
            : projects.filter((project) =>
                project.categories.some(cat => cat.category === selectedCategory.category)
            );

        // const sorted = filtered.slice().sort((a, b) => b.funded - a.funded);
        setFilteredProjects(filtered);
    }, [selectedCategory, projects]);

    return (
        <div className="container" id="projects-screen">
            <header className="my-4 mt-md-5 d-flex flex-column align-items-center text-center">
                <h1 className='fs-1'>Projects</h1>
            </header>

            {/* Projects Container */}
            <div className=''>
                <CategorySelector
                    categories={[{ category: 'All', rank: 0, id: 'category-all' }, ...categories]}
                    selectedCategory={selectedCategory}
                    onCategoryChange={handleCategoryChange}
                />

                <ProjectCardsContainer
                    projects={filteredProjects}
                    numProjectsToShow={numProjectsToShow}
                    isExpanded={isExpanded}
                    isLoading={isProjectsLoading}
                    toggleExpandCollapse={toggleExpandCollapse}
                    resetExpandCollapse={resetExpandCollapse}
                />
            </div>
        </div>
    );
}

export default ProjectsScreen;