import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";

import './styles/styles.scss';

import React, { useEffect } from 'react';

import { RouterProvider } from "react-router-dom";
import router from './Routes';

import { onAuthStateChanged } from "firebase/auth";
import { useDispatch } from 'react-redux';
import { fetchCategories } from './features/categories/categorySlice';
import { fetchTiers } from './features/tiers/tierSlice';
import { fetchProjects } from "./features/projects/projectSlice";
import { fetchMoments } from "./features/moments/momentSlice";
import { fetchUserDetails, login, logout, updateUserDetails } from "./features/user/userSlice";
import { auth } from "./firebase";

function App() {
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(fetchCategories());
        dispatch(fetchTiers());
        
        dispatch(fetchProjects());
        dispatch(fetchMoments());

        onAuthStateChanged(auth, (userAuth) => {
            if (userAuth) {
                const userData = {
                    email: userAuth.email,
                    id: userAuth.uid,
                    displayName: userAuth.displayName,
                    profilePicture: userAuth.photoURL,
                };
                dispatch(login(userData));

                dispatch(fetchUserDetails(userAuth.uid)).then((action) => {
                    if (fetchUserDetails.fulfilled.match(action)) {
                        dispatch(updateUserDetails({ userDetails: action.payload }));
                    }
                });
            } else {
                dispatch(logout());
            }
        });
    }, []);

    return (
        <RouterProvider router={router} />
    );
}

export default App;