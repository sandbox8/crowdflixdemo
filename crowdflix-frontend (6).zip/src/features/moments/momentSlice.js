import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { addDoc, collection, doc, getDoc, getDocs, serverTimestamp } from 'firebase/firestore';
import { db } from '../../firebase';

// Async thunk for fetching moments
export const fetchMoments = createAsyncThunk('moments/fetchMoments', async () => {
    console.log('fetching moments');
    // Fetch all documents without ordering on Firestore
    const querySnapshot = await getDocs(collection(db, "moments"));

    const moments = querySnapshot.docs.map((doc) => {
        const data = doc.data();
        return {
            ...data,
            id: doc.id,
            // Convert Firestore Timestamp to a serializable ISO string if it exists
            createdAt: data.createdAt ? data.createdAt.toDate().toISOString() : null,
        };
    });

    // Custom sort: items with a valid createdAt first (ascending order), then items with null
    moments.sort((a, b) => {
        if (a.createdAt && b.createdAt) {
            return new Date(a.createdAt) - new Date(b.createdAt);
        }
        if (a.createdAt && !b.createdAt) {
            return -1;
        }
        if (!a.createdAt && b.createdAt) {
            return 1;
        }
        return 0;
    });

    return moments;
});

// Async thunk for adding a new moment
export const addMomentToFirestore = createAsyncThunk('moments/addMoment', async (momentData) => {
    const docRef = await addDoc(collection(db, "moments"), {
        ...momentData,
        createdAt: serverTimestamp(),
    });

    // Fetch the document to get the correct timestamp
    const snapshot = await getDoc(doc(db, "moments", docRef.id));
    const data = snapshot.data();

    return {
        id: docRef.id,
        ...data,
        // Ensure the createdAt field is serializable
        createdAt: data.createdAt ? data.createdAt.toDate().toISOString() : null,
    };
});

// Slice
const momentSlice = createSlice({
    name: 'moments',
    initialState: {
        entities: [],
        loading: false
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchMoments.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchMoments.fulfilled, (state, action) => {
                state.entities = action.payload;
                state.loading = false;
            })
            .addCase(fetchMoments.rejected, (state) => {
                state.loading = false;
            })
            .addCase(addMomentToFirestore.fulfilled, (state, action) => {
                state.entities.unshift(action.payload);
            });
    },
});

export const selectMoments = (state) => state.moments.entities;

export default momentSlice.reducer;