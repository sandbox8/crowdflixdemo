import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';

import { doc, getDoc } from 'firebase/firestore';
import { db } from '../../firebase';

// Async thunk for fetching user details from Firestore
export const fetchUserDetails = createAsyncThunk(
    'user/fetchUserDetails',
    async (userId, thunkAPI) => {
        try {
            const docRef = doc(db, "users", userId);
            const docSnap = await getDoc(docRef);

            if (docSnap.exists()) {
                return docSnap.data();
            } else {
                return thunkAPI.rejectWithValue('User does not exist');
            }
        } catch (error) {
            return thunkAPI.rejectWithValue(error.message);
        }
    }
);

export const userSlice = createSlice({
    name: 'user',
    initialState: {
        user: null,
    },
    reducers: {
        login: (state, action) => {
            state.user = action.payload;
        },
        updateUserDetails: (state, action) => {
            state.user = { ...state.user, ...action.payload.userDetails };
        },
        logout: (state) => {
            state.user = null;
        },
    },
    extraReducers: (builder) => {
        builder.addCase(fetchUserDetails.fulfilled, (state, action) => {
            state.user = { ...state.user, ...action.payload };
        });
    },
});

export const { login, logout, updateUserDetails } = userSlice.actions;

// Selectors
export const selectUser = (state) => state.user.user;

export default userSlice.reducer;