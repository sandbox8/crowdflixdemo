import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { collection, getDocs, orderBy, query } from 'firebase/firestore';
import { db } from '../../firebase';

// Async thunk for fetching categories from Firestore
export const fetchCategories = createAsyncThunk('categories/fetchCategories', async () => {
    console.log('fetching categories');
    const querySnapshot = await getDocs(
        query(collection(db, "categories"), orderBy("rank", "asc"))
    );
    return querySnapshot.docs.map((doc) => ({
        ...doc.data(),
        id: doc.id
    }));
});

// Slice for categories with initial state
const categorySlice = createSlice({
    name: 'categories',
    initialState: {
        entities: [],
        loading: false
    },
    reducers: {
        // Reducers for other sync actions if needed
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchCategories.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchCategories.fulfilled, (state, action) => {
                state.entities = action.payload;
                state.loading = false;
            })
            .addCase(fetchCategories.rejected, (state) => {
                state.loading = false;
            });
    },
});

// Selectors
export const selectCategories = (state) => state.categories.entities;

export default categorySlice.reducer;
