import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { collection, getDocs, orderBy, query } from 'firebase/firestore';
import { db } from '../../firebase';

// Async thunk for fetching tiers from Firestore
export const fetchTiers = createAsyncThunk('tiers/fetchTiers', async () => {
    console.log('fetching tiers');
    const querySnapshot = await getDocs(
        query(collection(db, "tiers"), orderBy("rank", "asc"))
    );
    return querySnapshot.docs.map((doc) => ({
        ...doc.data(),
        id: doc.id
    }));
});

// Slice for tiers with initial state
const tierSlice = createSlice({
    name: 'tiers',
    initialState: {
        entities: [],
        loading: false
    },
    reducers: {
        // Reducers for other sync actions if needed
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchTiers.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchTiers.fulfilled, (state, action) => {
                state.entities = action.payload;
                state.loading = false;
            })
            .addCase(fetchTiers.rejected, (state) => {
                state.loading = false;
            });
    },
});

// Selectors
export const selectTiers = (state) => state.tiers.entities;

export default tierSlice.reducer;
