import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { collection, getDocs, orderBy, query } from 'firebase/firestore';
import { db } from '../../firebase';

// Async thunk for fetching projects from Firestore
export const fetchProjects = createAsyncThunk('projects/fetchProjects', async () => {
    console.log('fetching projects');
    const querySnapshot = await getDocs(
        query(collection(db, "projects"), orderBy("timestamp", "desc"))
    );
    return querySnapshot.docs.map((doc) => {
        let parsedTimestamp = null;
        let parsedEndDate = null;

        try {
            const timestampData = doc.data().timestamp;
            if (timestampData) {
                parsedTimestamp = new Date(timestampData.seconds * 1000 + timestampData.nanoseconds / 1000000).toISOString();
            }
        } catch (error) {
            console.error('Error parsing timestamp', error);
        }

        try {
            const endDateData = doc.data().endDate;
            if (typeof endDateData === 'number') {
                // endDate is a numeric timestamp
                parsedEndDate = new Date(endDateData).toISOString();
            } else if (endDateData && endDateData.seconds !== undefined) {
                // endDate is a Firestore timestamp object
                parsedEndDate = new Date(endDateData.seconds * 1000 + endDateData.nanoseconds / 1000000).toISOString();
            } else if (typeof endDateData === 'string') {
                // endDate is a string, assume ISO format
                parsedEndDate = new Date(endDateData).toISOString();
            }
        } catch (error) {
            console.error('Error parsing endDate', error);
        }

        return {
            ...doc.data(),
            id: doc.id,
            timestamp: parsedTimestamp,
            endDate: parsedEndDate
        };
    });
});




// Slice for projects with initial state
const projectSlice = createSlice({
    name: 'projects',
    initialState: {
        entities: [],
        loading: false
    },
    reducers: {
        addProject: (state, action) => {
            state.entities.unshift(action.payload.newProject);
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchProjects.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchProjects.fulfilled, (state, action) => {
                state.entities = action.payload;
                state.loading = false;
            })
            .addCase(fetchProjects.rejected, (state) => {
                state.loading = false;
            });
    },
});

export const { addProject } = projectSlice.actions;

// Selectors
export const selectProjects = (state) => state.projects.entities;

// Selector for created projects
export const selectCreatedProjects = (state, createdProjectIds) => {
    return state.projects.entities.filter(project => createdProjectIds.includes(project.id));
};

// Selector for backed projects
export const selectBackedProjects = (state, backedProjectIds) => {
    return state.projects.entities.filter(project => backedProjectIds.includes(project.id));
};

export default projectSlice.reducer;
