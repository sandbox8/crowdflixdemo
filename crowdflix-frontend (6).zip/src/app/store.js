import { configureStore } from '@reduxjs/toolkit';

import categoryReducer from '../features/categories/categorySlice';
import momentReducer from '../features/moments/momentSlice';
import projectReducer from '../features/projects/projectSlice';
import tierReducer from '../features/tiers/tierSlice';
import userReducer from '../features/user/userSlice';

export const store = configureStore({
    reducer: {
        categories: categoryReducer,
        tiers: tierReducer,

        projects: projectReducer,
        moments: momentReducer,
        
        user: userReducer,
        // other reducers...
    },
});
