const userTemplate = {
  displayName: "",
  backedProjects: [],
  createdProjects: [],
  biography: "",
  profilePicture: "",
  socials: {
    youtube: "",
    pinterest: "",
    twitch: "",
    netflix: "",
    reddit: "",
    tiktok: "",
    twitter: "",
    x: "",
    messenger: "",
    zoom: "",
    discord: "",
    facebook: "",
    linkedin: "",
    instagram: "",
  },
  videos: [],
};

export default userTemplate;
