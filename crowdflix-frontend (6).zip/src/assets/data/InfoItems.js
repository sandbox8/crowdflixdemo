const InfoItems = [
    {
        id: 1,
        title: 'Sandbox8 Teams Up with USC and HBCU',
        body: "Crowdflix, Sandbox8's innovative film crowdfunding platform, is proud to announce a dynamic partnership with USC School of Cinematic Arts and HBCU Next. Together, we're elevating Crowdflix as the premier destination for empowering a new generation of creators. This collaboration will spotlight the unique visions of USC and HBCU filmmakers, providing them with the resources to bring diverse narratives to life. Join us in shaping the future of film: Crowdflix, where creators' dreams become the audience's reality."
    },
    {
        id: 2,
        title: 'Crowdflix: A New Era of Fan-Driven Content Creation with NFTs',
        body: "Crowdflix is pioneering a new wave in entertainment as the first fan-based crowdfunding platform that integrates NFTs, offering unparalleled value to fans. As active participants, fans can now engage with content beyond traditional support; they can own a piece of their favorite projects through NFTs. This novel approach empowers fans to take part in the creative process, ensuring that they are not just spectators but stakeholders in the stories they cherish. Crowdflix is redefining fan engagement, enabling a vibrant community where content is fueled by passion and participation."
    },
    // Add more items as needed
];

export default InfoItems;