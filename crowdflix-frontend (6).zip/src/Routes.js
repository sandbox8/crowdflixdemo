import React, { Suspense, lazy } from "react";
import PropTypes from "prop-types";
import { useSelector } from "react-redux";
import {
  Navigate,
  Outlet,
  useLocation,
  createBrowserRouter,
} from "react-router-dom";
import { selectUser } from "./features/user/userSlice";

import Navbar from "./components/Navbar";
import EnhancedFooter from "./components/EnhancedFooter";

// Lazy load screens for better performance and code splitting
const HomeScreen = lazy(() => import("./screens/HomeScreen"));
const AboutUsScreen = lazy(() => import("./screens/AboutUsScreen"));
const MarketplaceScreen = lazy(() => import("./screens/MarketplaceScreen"));
const MomentScreen = lazy(() => import("./screens/MomentScreen"));
const MobileFooterDemoScreen = lazy(
  () => import("./screens/MobileFooterDemoScreen"),
);
const PaymentScreen = lazy(() => import("./screens/PaymentScreen"));
const OfferOptionsScreen = lazy(() => import("./screens/OfferOptionsScreen"));
const PaymentSuccessScreen = lazy(
  () => import("./screens/PaymentSuccessScreen"),
);
const UniversePage = lazy(() => import("./screens/UniversePage"));
const SuccessScreen = lazy(() => import("./screens/SuccessScreen"));
const SignInScreen = lazy(() => import("./screens/SignInScreen"));
const SignUpScreen = lazy(() => import("./screens/SignUpScreen"));
const ForgotPasswordScreen = lazy(
  () => import("./screens/ForgotPasswordScreen"),
);
const CreateMomentScreen = lazy(() => import("./screens/CreateMomentScreen"));
const ProfileScreen = lazy(() => import("./screens/ProfileScreen"));
const OptimizedProfileScreen = lazy(
  () => import("./screens/OptimizedProfileScreen"),
);
const PublicProfileScreen = lazy(() => import("./screens/PublicProfileScreen"));
const StudioScreen = lazy(() => import("./screens/StudioScreen"));
const ProjectScreen = lazy(() => import("./screens/ProjectScreen"));
const StartProjectScreen = lazy(() => import("./screens/StartProjectScreen"));

// Lazy load legal screens
const PrivacyPolicyScreen = lazy(
  () => import("./screens/legal/PrivacyPolicyScreen"),
);
const CookiePolicyScreen = lazy(
  () => import("./screens/legal/CookiePolicyScreen"),
);
const TermsOfUseScreen = lazy(() => import("./screens/legal/TermsOfUseScreen"));
const CopyrightTrademarksScreen = lazy(
  () => import("./screens/legal/CopyrightTrademarksScreen"),
);

const NoPage = lazy(() => import("./screens/NoPage"));

// Error Boundary Component
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("Error caught by boundary:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="error-boundary">
          <div className="error-content">
            <h2>Something went wrong</h2>
            <p>We&apos;re sorry, but something unexpected happened.</p>
            <button
              onClick={() => window.location.reload()}
              className="retry-button"
            >
              Refresh Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

ErrorBoundary.propTypes = {
  children: PropTypes.node.isRequired,
};

// Enhanced Loading Component
const EnhancedLoadingIndicator = () => (
  <div className="enhanced-loading">
    <div className="loading-container">
      <div className="loading-spinner"></div>
      <div className="loading-text">Loading...</div>
    </div>
  </div>
);

const Layout = () => {
  const { pathname } = useLocation();
  const user = useSelector(selectUser);

  // If accessing secure pages without authentication, redirect to sign-in with a toast message in state
  if (pathname.includes("secure") && !user) {
    return (
      <Navigate
        to="/sign-in"
        state={{ toastMessage: "You must be signed on to access this page" }}
      />
    );
  }

  const centeredRoutes = [
    "/secure/start-project",
    "/sign-in",
    "/sign-up",
    "/forgot-password",
    "/success",
  ];

  // Routes that don't need the default footer (have their own)
  const customFooterRoutes = ["/"];

  const contentClass = centeredRoutes.includes(pathname)
    ? "content-wrap vertically-centered-content"
    : "content-wrap";

  // Home page gets special treatment with no default navbar/footer wrapper
  if (pathname === "/") {
    return (
      <ErrorBoundary>
        <div style={{ position: "relative", minHeight: "100vh" }}>
          <Navbar />
          <Suspense fallback={<EnhancedLoadingIndicator />}>
            <Outlet />
          </Suspense>
        </div>
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary>
      <div className="page-container">
        <Navbar />
        <div className={contentClass}>
          <Suspense fallback={<EnhancedLoadingIndicator />}>
            <Outlet />
          </Suspense>
        </div>
        {!customFooterRoutes.includes(pathname) && <EnhancedFooter />}
      </div>
    </ErrorBoundary>
  );
};

const router = createBrowserRouter([
  {
    element: <Layout />,
    children: [
      { path: "/", element: <HomeScreen /> },
      { path: "/about", element: <AboutUsScreen /> },
      { path: "/marketplace", element: <MarketplaceScreen /> },
      { path: "/moment/:id", element: <MomentScreen /> },
      { path: "/mobile-footer-demo", element: <MobileFooterDemoScreen /> },
      { path: "/payment/:id", element: <PaymentScreen /> },
      { path: "/offer-options/:id", element: <OfferOptionsScreen /> },
      { path: "/purchase-success", element: <PaymentSuccessScreen /> },
      { path: "/universe/:slug", element: <UniversePage /> },
      { path: "/success", element: <SuccessScreen /> },
      { path: "/sign-in", element: <SignInScreen /> },
      { path: "/sign-up", element: <SignUpScreen /> },
      { path: "/forgot-password", element: <ForgotPasswordScreen /> },
      { path: "/profile/:id", element: <OptimizedProfileScreen /> },
      { path: "/profile-legacy/:id", element: <ProfileScreen /> },
      { path: "/u/:username", element: <PublicProfileScreen /> },
      { path: "/:studioSlug", element: <StudioScreen /> },
      { path: "/project/:id", element: <ProjectScreen /> },
      { path: "/secure/start-project", element: <StartProjectScreen /> },
      { path: "/secure/create-moment", element: <CreateMomentScreen /> },
      { path: "/privacy-policy", element: <PrivacyPolicyScreen /> },
      { path: "/cookie-policy", element: <CookiePolicyScreen /> },
      { path: "/terms", element: <TermsOfUseScreen /> },
      { path: "/copyright", element: <CopyrightTrademarksScreen /> },
      { path: "/*", element: <NoPage /> },
    ],
  },
]);

export default router;
