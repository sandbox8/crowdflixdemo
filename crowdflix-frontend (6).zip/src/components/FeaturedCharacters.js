import React from "react";
import PropTypes from "prop-types";

const FeaturedCharacters = ({ characters = [] }) => {
  return (
    <div className="featured-characters-section">
      <div className="section-header">
        <h2 className="section-title">Featured Characters</h2>
        <p className="section-subtitle">
          Discover the iconic characters from this universe
        </p>
      </div>

      <div className="characters-grid">
        {characters.map((character) => (
          <CharacterCard key={character.id} character={character} />
        ))}
      </div>
    </div>
  );
};

const CharacterCard = ({ character }) => {
  return (
    <div className="character-card">
      <div className="character-image-container">
        <img
          src={character.image}
          alt={character.name}
          className="character-image"
        />
        <div className="character-overlay">
          <div className="character-info">
            <h3 className="character-name">{character.name}</h3>
            <p className="character-description">{character.description}</p>
          </div>
        </div>
      </div>

      <div className="character-content">
        <h3 className="character-title">{character.name}</h3>
        <div className="character-stats">
          <div className="stat">
            <span className="stat-label">Moments</span>
            <span className="stat-value">24</span>
          </div>
          <div className="stat">
            <span className="stat-label">Avg Price</span>
            <span className="stat-value">$89</span>
          </div>
        </div>

        <button className="view-character-btn">View Collection</button>
      </div>
    </div>
  );
};

CharacterCard.propTypes = {
  character: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    image: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
  }).isRequired,
};

FeaturedCharacters.propTypes = {
  characters: PropTypes.arrayOf(PropTypes.object),
};

export default FeaturedCharacters;
