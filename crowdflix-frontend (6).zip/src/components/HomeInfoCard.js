import React from 'react';

import PropTypes from 'prop-types';

const HomeInfoCard = ({ title, value, theme }) => {
    const themeStyles = {
        universe: {
            background: "linear-gradient(135deg, #ff8c00, #ff2e63)",
            border: "1px solid #ff2e63",
        },
        character: {
            background: "linear-gradient(135deg, #1e90ff, #0a74da)",
            border: "1px solid #0a74da",
        },
        rarity: {
            background: "linear-gradient(135deg, #8e44ad, #c0392b)",
            border: "1px solid #c0392b",
        },
        default: {
            background: "#141414", // Fallback dark background
            border: "1px solid #323232",
        }
    };

    return (
        <div className="col-md-4 text-white">
            <div className="info-card mb-4 rounded p-4 text-center" style={themeStyles[theme] || themeStyles.default}>
                <div className="fw-bold fs-4">{value}</div>
                <div className="mt-2">{title}</div>
            </div>
        </div>
    );
};

HomeInfoCard.propTypes = {
    title: PropTypes.string.isRequired,
    value: PropTypes.string.isRequired,
    theme: PropTypes.oneOf(["universe", "character", "rarity", "default"]), // Ensures valid themes
};

HomeInfoCard.defaultProps = {
    theme: "default",
};

export default HomeInfoCard;