import React, { useEffect } from 'react';

import PropTypes from 'prop-types';
import { ChevronDown, ChevronUp } from 'react-bootstrap-icons';

import ProjectCard from './ProjectCard';
import LoadingIndicator from './LoadingIndicator';

const ProjectCardsContainer = ({ projects, numProjectsToShow, isExpanded, isLoading, toggleExpandCollapse, resetExpandCollapse }) => {
    useEffect(() => {
        if (resetExpandCollapse) {
            resetExpandCollapse();
        }
    }, [projects]);

    if (isLoading) {
        return LoadingIndicator();
    }

    return (
        <div className="">
            {projects.length === 0 ? (
                <div className="text-center p-5"><p>No projects found 😕</p></div>
            ) : (
                <div>
                    <div className="row text-center mt-3">
                        {(numProjectsToShow ? projects.slice(0, numProjectsToShow) : projects).map((project) => (
                            <ProjectCard key={project.id} project={project} />
                        ))}
                    </div>

                    {projects.length <= 6 ? null : (
                        <div
                            onClick={toggleExpandCollapse}
                            style={{ textAlign: 'right', cursor: 'pointer' }}
                        >
                            <div className="d-flex justify-content-end align-items-center">
                                {isExpanded ? (
                                    <div className='my-link'>
                                        Collapse <ChevronUp />
                                    </div>
                                ) : (
                                    <div className='my-link'>
                                        Expand <ChevronDown />
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

ProjectCardsContainer.propTypes = {
    projects: PropTypes.array.isRequired,
    numProjectsToShow: PropTypes.number,
    isExpanded: PropTypes.bool,
    isLoading: PropTypes.bool,
    toggleExpandCollapse: PropTypes.func,
    resetExpandCollapse: PropTypes.func,
};

export default ProjectCardsContainer;