import React from "react";
import PropTypes from "prop-types";

const OfferSelectionList = ({
  offers,
  selectedOffer,
  onOfferSelect,
  availableCount = 6,
}) => {
  return (
    <div className="offer-selection-container">
      <div className="offer-header">
        <div className="available-count">{availableCount} Available</div>
        <button className="filter-button" aria-label="Filter offers">
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M23.5 22.5L28.707 17.293C28.895 17.105 29 16.851 29 16.586V14C29 13.448 28.552 13 28 13H14C13.448 13 13 13.448 13 14V16.586C13 16.851 13.105 17.106 13.293 17.293L18.5 22.5"
              stroke="white"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M18.5 22.5V28.749C18.5 29.562 19.264 30.159 20.053 29.962L22.553 29.337C23.109 29.198 23.5 28.698 23.5 28.124V22.5"
              stroke="white"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
      </div>

      <div className="offer-table-header">
        <div className="check-column">
          <svg
            width="12"
            height="12"
            viewBox="0 0 12 12"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M2.48438 5.88546L5.04403 8.39941L9.52344 4"
              stroke="white"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
              opacity="0.45"
            />
          </svg>
        </div>
        <div className="price-column">Price</div>
        <div className="serial-column">Serial</div>
        <div className="seller-column">Seller</div>
      </div>

      <div className="offers-list">
        {offers.map((offer) => (
          <div
            key={offer.id}
            className={`offer-item ${selectedOffer?.id === offer.id ? "selected" : ""}`}
            onClick={() => onOfferSelect(offer)}
          >
            <div className="radio-button">
              {selectedOffer?.id === offer.id ? (
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <rect
                    x="0.5"
                    y="0.5"
                    width="23"
                    height="23"
                    rx="11.5"
                    stroke="url(#paint0_linear)"
                  />
                  <circle cx="12" cy="12" r="7" fill="#EF3D37" />
                  <defs>
                    <linearGradient
                      id="paint0_linear"
                      x1="-11.7098"
                      y1="9.80272"
                      x2="9.30582"
                      y2="34.7622"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stopColor="#FF4A3C" stopOpacity="0.440778" />
                      <stop
                        offset="1"
                        stopColor="#AF0A22"
                        stopOpacity="0.683676"
                      />
                    </linearGradient>
                  </defs>
                </svg>
              ) : (
                <div className="radio-empty" />
              )}
            </div>
            <div className="offer-price">${offer.price.toFixed(2)}</div>
            <div className="offer-serial">#{offer.serial}</div>
            <div className="offer-seller">@{offer.seller}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

OfferSelectionList.propTypes = {
  offers: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      price: PropTypes.number.isRequired,
      serial: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
        .isRequired,
      seller: PropTypes.string.isRequired,
    }),
  ).isRequired,
  selectedOffer: PropTypes.object,
  onOfferSelect: PropTypes.func.isRequired,
  availableCount: PropTypes.number,
};

export default OfferSelectionList;
