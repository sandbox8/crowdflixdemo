import React from 'react';

import PropTypes from 'prop-types';
import ProgressBar from 'react-bootstrap/ProgressBar';
import { Link } from 'react-router-dom';

const ProjectCard = ({ project }) => {
    const fundingProgress = (project.funded / project.fundingGoal) * 100;
    const descriptionLength = 101;

    const truncateDescription = (description, maxLength) => {
        if (description.length > maxLength) {
            return description.slice(0, maxLength) + '...';
        }
        return description;
    };

    return (
        <div className="col-12 col-md-6 col-lg-4 mb-4">
            <div className="card h-100 shadow dark-bg white-text border-dark">
                <div style={{ position: 'relative', paddingBottom: '56.25%', overflow: 'hidden' }}>
                    <img
                        src={project.projectImage}
                        className="card-img-top"
                        alt={project.projectName}
                        style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', objectFit: 'cover' }}
                    />
                </div>

                <div className="card-body">
                    <div className="d-flex justify-content-between">
                        <Link
                            className='my-link text-white text-end'
                            to={`/project/${project.id}`}
                        >
                            <h5 className="card-title">{project.projectName}</h5>
                        </Link>
                        <Link
                            className="my-link text-end"
                            to={`/profile/${project.projectCreatorId}`}
                        >{project.projectCreator}</Link>
                    </div>

                    <p className="card-text grey-text">
                        {truncateDescription(project.projectDescription, descriptionLength)}
                    </p>
                </div>

                <div className="card-footer border-dark">
                    <div className="d-flex justify-content-between align-items-center">
                        <div className="fw-bold">
                            <span className="fs-5">${project.funded}</span>
                            <span className="fs-6"> funded</span>
                        </div>

                        <div className="fw-bold">
                            <span className="fs-5">${project.fundingGoal}</span>
                            <span className="fs-6"> goal</span>
                        </div>
                    </div>

                    <ProgressBar
                        now={fundingProgress}
                        variant='primary'
                    />
                </div>
            </div>
        </div>
    );
};

ProjectCard.propTypes = {
    project: PropTypes.shape({
        funded: PropTypes.number.isRequired,
        id: PropTypes.string.isRequired,
        fundingGoal: PropTypes.number.isRequired,
        projectImage: PropTypes.string.isRequired,
        projectName: PropTypes.string.isRequired,
        projectCreator: PropTypes.string.isRequired,
        projectCreatorId: PropTypes.string,
        projectDescription: PropTypes.string.isRequired,
    }).isRequired,
};

export default ProjectCard;
