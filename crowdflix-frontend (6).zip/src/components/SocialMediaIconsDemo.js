import React from "react";
import SocialMediaIcons from "./SocialMediaIcons";

const SocialMediaIconsDemo = () => {
  // Demo social media links
  const demoSocials = {
    youtube: "https://youtube.com/@demo",
    pinterest: "https://pinterest.com/demo",
    twitch: "https://twitch.tv/demo",
    netflix: "https://netflix.com/demo",
    reddit: "https://reddit.com/u/demo",
    tiktok: "https://tiktok.com/@demo",
    twitter: "https://twitter.com/demo",
    x: "https://x.com/demo",
    messenger: "https://messenger.com/demo",
    zoom: "https://zoom.us/demo",
    discord: "https://discord.gg/demo",
  };

  const partialSocials = {
    youtube: "https://youtube.com/@example",
    twitter: "https://twitter.com/example",
    discord: "https://discord.gg/example",
  };

  return (
    <div
      style={{
        padding: "40px",
        background: "#000",
        minHeight: "100vh",
        color: "#fff",
      }}
    >
      <h1>Social Media Icons Demo</h1>

      <div style={{ marginBottom: "40px" }}>
        <h2>All Icons - Profile Variant</h2>
        <div
          style={{
            padding: "20px",
            background: "rgba(255,255,255,0.05)",
            borderRadius: "12px",
            marginBottom: "20px",
          }}
        >
          <SocialMediaIcons
            socials={demoSocials}
            variant="profile"
            size="default"
          />
        </div>
      </div>

      <div style={{ marginBottom: "40px" }}>
        <h2>Partial Icons - Card Variant</h2>
        <div
          style={{
            padding: "20px",
            background: "rgba(255,255,255,0.05)",
            borderRadius: "12px",
            marginBottom: "20px",
          }}
        >
          <SocialMediaIcons
            socials={partialSocials}
            variant="card"
            size="small"
          />
        </div>
      </div>

      <div style={{ marginBottom: "40px" }}>
        <h2>Footer Variant - Large Size</h2>
        <div
          style={{
            padding: "20px",
            background: "rgba(255,255,255,0.05)",
            borderRadius: "12px",
            marginBottom: "20px",
          }}
        >
          <SocialMediaIcons
            socials={demoSocials}
            variant="footer"
            size="large"
          />
        </div>
      </div>

      <div style={{ marginBottom: "40px" }}>
        <h2>Individual Platform Examples</h2>

        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          {Object.keys(demoSocials).map((platform) => (
            <div
              key={platform}
              style={{
                padding: "15px",
                background: "rgba(255,255,255,0.03)",
                borderRadius: "8px",
                display: "flex",
                alignItems: "center",
                gap: "15px",
              }}
            >
              <SocialMediaIcons
                socials={{ [platform]: demoSocials[platform] }}
                variant="profile"
                size="default"
              />
              <span
                style={{
                  fontSize: "16px",
                  fontWeight: "500",
                  textTransform: "capitalize",
                }}
              >
                {platform}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SocialMediaIconsDemo;
