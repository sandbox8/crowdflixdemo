import React from "react";
import { Twitter } from "react-bootstrap-icons";

const EnhancedFooter = () => {
  return (
    <div
      style={{
        width: "100%",
        height: "120px",
        background: "#000",
        padding: "0 68px",
        position: "relative",
      }}
    >
      {/* Background Elements */}
      <div
        style={{
          position: "absolute",
          left: "-240px",
          top: "-174px",
          width: "1920px",
          height: "380px",
          background: "#000",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            left: "249px",
            top: "177px",
            width: "88px",
            height: "48px",
            backgroundImage:
              'url("data:image/svg+xml,%3Csvg viewBox="0 0 88 48" xmlns="http://www.w3.org/2000/svg"%3E%3Cdefs%3E%3Cfilter id="blur"%3E%3CfeGaussianBlur stdDeviation="20"/%3E%3C/filter%3E%3C/defs%3E%3Ccircle cx="44" cy="24" r="20" fill="%23ff4a3c" opacity="0.3" filter="url(%23blur)"/%3E%3C/svg%3E")',
          }}
        />
      </div>

      {/* Main Footer Content */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          height: "100%",
          maxWidth: "1280px",
          margin: "0 auto",
          position: "relative",
        }}
      >
        {/* Logo Section */}
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "flex-start",
            gap: "22px",
          }}
        >
          {/* Copyright and Links */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "20px",
            }}
          >
            <div
              style={{
                color: "#85CBFF",
                fontFamily: "Outfit, sans-serif",
                fontSize: "12px",
                fontWeight: 400,
                lineHeight: "12px",
                opacity: 0.5,
              }}
            >
              © 2024 CrowdFlix
            </div>

            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "20px",
              }}
            >
              {[
                "Terms",
                "Privacy",
                "Cookies",
                "About",
                "FAQ",
                "Share with Letterboxd",
              ].map((link) => (
                <a
                  key={link}
                  href="#"
                  style={{
                    color: "#85CBFF",
                    fontFamily: "Outfit, sans-serif",
                    fontSize: "12px",
                    fontWeight: 400,
                    lineHeight: "12px",
                    textDecoration: "none",
                  }}
                >
                  {link}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Social Media Icons */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "20px",
          }}
        >
          <Twitter
            style={{
              color: "#85CBFF",
              fontSize: "24px",
              cursor: "pointer",
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default EnhancedFooter;
