import React from 'react';

import { Col, Container, ListGroup, Row } from 'react-bootstrap';
import { Facebook, Instagram, Linkedin, Twitter } from 'react-bootstrap-icons';
import { Link, useNavigate } from 'react-router-dom';

import crowdflix_logo from '../assets/images/crowdflix_logo.png';

function Footer() {
    const navigate = useNavigate();

    const crowdflixImg = <img
        src={crowdflix_logo}
        alt="crowdflix logo"
        className='img-fluid'
        style={{ cursor: 'pointer' }}
        onClick={() => { navigate('/'); }}
    />;

    return (
        <footer id="footer" className="pt-md-5 pb-md-2 py-3 dark-bg">
            <Container>
                <Row>
                    <Col lg={5} md={8} xs={12} className='mb-2 d-lg-flex d-none'>
                        <div className="footer-img-container row d-flex align-items-center justify-content-center">
                            <div className="col-5">
                                {crowdflixImg}
                            </div>
                        </div>
                    </Col>

                    <Col lg={2} md={4} xs={6} className='mb-2'>
                        <h3>About</h3>
                        <ListGroup variant="flush">
                            <ListGroup.Item ><Link className='my-link' to="/about">About Us</Link></ListGroup.Item>
                            <ListGroup.Item ><Link className='my-link' to="/projects">Explore</Link></ListGroup.Item>
                            <ListGroup.Item ><Link className='my-link' to="/sign-in">Sign In</Link></ListGroup.Item>
                            <ListGroup.Item ><Link className='my-link' to="/secure/start-project">Start Project</Link></ListGroup.Item>
                        </ListGroup>
                    </Col>

                    <Col lg={2} md={4} xs={6} className='mb-2'>
                        <h3>Info</h3>
                        <ListGroup variant="flush">
                            <ListGroup.Item ><Link className='my-link' to="/privacy-policy">Privacy Policy</Link></ListGroup.Item>
                            <ListGroup.Item ><Link className='my-link' to="/terms">Terms of Use</Link></ListGroup.Item>
                            <ListGroup.Item ><Link className='my-link' to="/cookie-policy">Cookie Policy</Link></ListGroup.Item>
                            <ListGroup.Item ><Link className='my-link' to="/copyright">Copyright & TM</Link></ListGroup.Item>
                        </ListGroup>
                    </Col>

                    <Col lg={3} md={4} className='mb-2 d-block'>
                        <div className="">
                            <h3 className='d-none d-md-block'>Follow us</h3>
                            <div className="social">
                                <a href="https://www.linkedin.com/company/sandbox8/"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                ><Linkedin /></a>
                                <a href="#"><Instagram /></a>
                                <a href="#"><Twitter /></a>
                                <a href="#"><Facebook /></a>
                            </div>
                        </div>

                        <div className="footer-img-container row align-items-center d-lg-none mt-3 justify-content-center">
                            <div className="col-6 d-flex justify-content-center">
                                {crowdflixImg}
                            </div>
                        </div>
                    </Col>
                </Row>

                <Row >
                    <Col md={12} className="text-center">
                        <hr />
                        <p>All rights reserved © SandBox8 LLC 2023</p>
                    </Col>
                </Row>
            </Container>
        </footer>
    );
}

export default Footer;
