import React from "react";

const MyCollectionsHero = () => {
  const handleSeeCollections = () => {
    // Navigate to collections page or section
    console.log("Navigating to collections...");
  };

  return (
    <section className="my-collections-hero">
      <div className="collections-hero-container">
        <div className="collections-hero-content">
          <div className="collections-hero-text">
            <h1 className="collections-hero-title">My Collections</h1>
            <p className="collections-hero-description">
              Discover, buy, and sell unique digital assets securely on our NFT
              marketplace. Explore a world of exclusive art, collectibles, and
              more!
            </p>
          </div>

          <div className="collections-hero-actions">
            <button
              className="collections-cta-button"
              onClick={handleSeeCollections}
            >
              See My Collections
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MyCollectionsHero;
