import React from "react";
import PropTypes from "prop-types";
import "../styles/components/_auth-layout.scss";

const AuthLayout = ({ children, title, subtitle }) => {
  return (
    <div className="auth-layout">
      {/* Background Elements */}
      <div className="auth-background">
        <div className="auth-gradient-overlay"></div>
      </div>

      {/* Close Button */}
      <button className="auth-close-btn" onClick={() => window.history.back()}>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path
            d="M18 6L6 18M6 6L18 18"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </button>

      {/* Logo */}
      <div className="auth-logo">
        <div className="logo-icon">
          <svg width="35" height="40" viewBox="0 0 35 40" fill="none">
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M0 10.8902L18.8981 0L34.8935 8.90519V13.2702L26.3615 18.0689L18.8981 13.48L11.7161 17.7307L7.94454 15.3791L18.8981 8.90519L26.3615 13.48L30.5174 10.8902L18.7341 4.36595L3.92284 12.8715V17.7307L18.8981 26.6319L27.0863 21.7084L34.8935 26.4318V30.9741L18.7341 40L0 28.9657L0 24.2025L18.8981 35.5739L31.0341 28.7468L27.0863 26.4318L18.8981 30.9741L0 20L0 10.8902Z"
              fill="white"
            />
          </svg>
        </div>
        <span className="logo-text">CROWDFLIX</span>
      </div>

      {/* Left Side - Hero Content */}
      <div className="auth-hero">
        <div className="hero-content">
          <div className="hero-title">
            <span className="title-line-1">OWN</span>
            <span className="title-line-2">THE BOX</span>
            <span className="title-line-3">OFFICE</span>
          </div>

          {/* Movie Cards Display */}
          <div className="movie-cards-display">
            {/* These would be the movie cards from your design */}
            <div className="movie-card card-1">
              <div
                className="card-image"
                style={{
                  backgroundImage: `url(https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fc9d6315880a149ee987f3d0fb742141f?format=webp&width=400)`,
                }}
              >
                <div className="card-overlay">
                  <div className="card-title">FORGE</div>
                  <div className="card-subtitle">IN STOCK</div>
                </div>
              </div>
            </div>

            <div className="movie-card card-2">
              <div
                className="card-image"
                style={{
                  backgroundImage: `url(https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fcf5f070783c342d7be22fc26d83cefc2?format=webp&width=400)`,
                }}
              >
                <div className="card-overlay">
                  <div className="card-title">CYBERPUNK</div>
                  <div className="card-subtitle">LEGENDARY</div>
                </div>
              </div>
            </div>

            <div className="movie-card card-3">
              <div
                className="card-image"
                style={{
                  backgroundImage: `url(https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F83506646054b44a8b58b6ba4df37997b?format=webp&width=400)`,
                }}
              >
                <div className="card-overlay">
                  <div className="card-title">ATHLETIC</div>
                  <div className="card-subtitle">FORCES</div>
                </div>
              </div>
            </div>

            <div className="movie-card card-4">
              <div
                className="card-image"
                style={{
                  backgroundImage: `url(https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F3ceee87b0d8c4a2e91243eaf240e838b?format=webp&width=400)`,
                }}
              >
                <div className="card-overlay">
                  <div className="card-title">THE MUMMY</div>
                  <div className="card-subtitle">LEGENDARY</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Auth Form */}
      <div className="auth-form-container">
        <div className="auth-form-wrapper">
          <div className="auth-form-content">
            {title && (
              <div className="auth-header">
                <h1 className="auth-title">{title}</h1>
                {subtitle && <p className="auth-subtitle">{subtitle}</p>}
              </div>
            )}

            <div className="auth-form">{children}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

AuthLayout.propTypes = {
  children: PropTypes.node.isRequired,
  title: PropTypes.string,
  subtitle: PropTypes.string,
};

export default AuthLayout;
