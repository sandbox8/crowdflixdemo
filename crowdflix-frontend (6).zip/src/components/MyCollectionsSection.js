import React, { useState, useRef, useEffect } from "react";
import MomentCard from "./MomentCard";

const MyCollectionsSection = () => {
  const [activeTab, setActiveTab] = useState("vault");
  const [isDragging, setIsDragging] = useState(false);
  const vaultScrollRef = useRef(null);
  const packsScrollRef = useRef(null);
  const tradeablesScrollRef = useRef(null);

  // Sample data for each tab
  const vaultMoments = [
    {
      id: "vault-1",
      title: "The Snap",
      filmSeries: "Avengers: Infinity War",
      emotionTag: "Power",
      rarity: "immortal",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fa3cb973601e7471a9b4d0c02a2bafd37",
      videoUrl:
        "https://cdn.builder.io/api/v1/video/assets/TEMP/sample-thanos.mp4",
      owned: true,
      tradeable: true,
      price: "2,500",
    },
    {
      id: "vault-2",
      title: "I Am Iron Man",
      filmSeries: "Iron Man",
      emotionTag: "Identity",
      rarity: "legendary",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F5a1c0dbf6e324f6a88e34e2230cae9b7",
      videoUrl:
        "https://cdn.builder.io/api/v1/video/assets/TEMP/sample-ironman.mp4",
      owned: true,
      tradeable: false,
    },
    {
      id: "vault-3",
      title: "I Lied to You",
      filmSeries: "SINNERS",
      emotionTag: "Defiance",
      rarity: "epic",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fa789a94d3a384c60b95383d5540565a2",
      owned: true,
      tradeable: true,
    },
    {
      id: "vault-4",
      title: "May the Force Be With You",
      filmSeries: "Star Wars",
      emotionTag: "Hope",
      rarity: "rare",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F029e6e3c535149dc944bb2dfb9bfb60d",
      owned: true,
      tradeable: false,
    },
  ];

  const packMoments = [
    {
      id: "pack-1",
      title: "Marvel Legends Pack",
      filmSeries: "Marvel Cinematic Universe",
      emotionTag: "Epic",
      rarity: "legendary",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fcccaf5c58da14ed2b47b067a04844b25?format=webp",
      owned: true,
      opened: false,
      packCount: 5,
    },
    {
      id: "pack-2",
      title: "Horror Classics",
      filmSeries: "Universal Monsters",
      emotionTag: "Fear",
      rarity: "epic",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Ffbebd21e73894f4b9a279ffcbd94e53c",
      owned: true,
      opened: true,
      packCount: 3,
    },
    {
      id: "pack-3",
      title: "Starter Pack",
      filmSeries: "Blade Runner",
      emotionTag: "Wonder",
      rarity: "rare",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fe76b04022f0d48f5b95702af628645a6",
      owned: true,
      opened: false,
      packCount: 7,
    },
  ];

  const tradeableMoments = [
    {
      id: "trade-1",
      title: "Redemption Arc",
      filmSeries: "The Dark Knight",
      emotionTag: "Redemption",
      rarity: "epic",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/e318dad147db92f5d6487c15728ee9a42eb4a65b",
      owned: true,
      tradeable: true,
      listedPrice: "850",
    },
    {
      id: "trade-2",
      title: "Final Battle",
      filmSeries: "Endgame",
      emotionTag: "Triumph",
      rarity: "legendary",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/e318dad147db92f5d6487c15728ee9a42eb4a65b",
      owned: true,
      tradeable: true,
      listedPrice: "1,200",
    },
  ];

  // Scroll functionality
  const scroll = (ref, direction) => {
    if (ref.current) {
      const scrollAmount = 240; // Card width + gap
      const newScrollPosition =
        ref.current.scrollLeft +
        (direction === "left" ? -scrollAmount : scrollAmount);
      ref.current.scrollTo({
        left: newScrollPosition,
        behavior: "smooth",
      });
    }
  };

  // Handle drag scrolling for touch devices
  const handleMouseDown = (e) => {
    setIsDragging(true);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  useEffect(() => {
    const handleGlobalMouseUp = () => setIsDragging(false);
    document.addEventListener("mouseup", handleGlobalMouseUp);
    return () => document.removeEventListener("mouseup", handleGlobalMouseUp);
  }, []);

  // Handle moment actions
  const handleMomentAction = (actionType, momentId) => {
    console.log(`${actionType} action for moment:`, momentId);

    switch (actionType) {
      case "buy":
        // Navigate to purchase flow
        break;
      case "view":
        // Navigate to moment detail
        break;
      case "trade":
        // Open trade modal
        break;
      case "open":
        // Open pack
        break;
      default:
        break;
    }
  };

  // Get current scroll ref
  const getCurrentScrollRef = () => {
    switch (activeTab) {
      case "vault":
        return vaultScrollRef;
      case "packs":
        return packsScrollRef;
      case "tradeables":
        return tradeablesScrollRef;
      default:
        return vaultScrollRef;
    }
  };

  // Get current data
  const getCurrentData = () => {
    switch (activeTab) {
      case "vault":
        return vaultMoments;
      case "packs":
        return packMoments;
      case "tradeables":
        return tradeableMoments;
      default:
        return vaultMoments;
    }
  };

  // Get collection stats
  const getCollectionStats = (tabType) => {
    switch (tabType) {
      case "vault":
        return { count: vaultMoments.length, label: "Moments" };
      case "packs":
        return {
          count: packMoments.length,
          label: "Packs",
          unopened: packMoments.filter((p) => !p.opened).length,
        };
      case "tradeables":
        return { count: tradeableMoments.length, label: "Listed" };
      default:
        return { count: 0, label: "Items" };
    }
  };

  return (
    <section className="my-collections-section">
      <div className="collections-container">
        {/* Header */}
        <div className="collections-header">
          <h2 className="collections-title">My Collections</h2>
          <p className="collections-subtitle">
            Your cinematic journey, moments that matter, stories worth owning
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="collections-tabs">
          {["vault", "packs", "tradeables"].map((tab) => {
            const stats = getCollectionStats(tab);
            return (
              <button
                key={tab}
                className={`collections-tab ${activeTab === tab ? "collections-tab--active" : ""}`}
                onClick={() => setActiveTab(tab)}
              >
                <div className="collections-tab__content">
                  <span className="collections-tab__label">
                    {tab === "vault" && "🏛️ Vault"}
                    {tab === "packs" && "📦 Packs"}
                    {tab === "tradeables" && "🔄 Tradeables"}
                  </span>
                  <div className="collections-tab__stats">
                    <span className="collections-tab__count">
                      {stats.count}
                    </span>
                    <span className="collections-tab__meta">
                      {tab === "packs" && stats.unopened > 0
                        ? `${stats.unopened} unopened`
                        : stats.label}
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Collection Content */}
        <div className="collections-content">
          {/* Scroll Navigation */}
          <button
            className="collections-scroll-btn collections-scroll-btn--left"
            onClick={() => scroll(getCurrentScrollRef(), "left")}
            aria-label="Scroll left"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path
                d="M15 18L9 12L15 6"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>

          <button
            className="collections-scroll-btn collections-scroll-btn--right"
            onClick={() => scroll(getCurrentScrollRef(), "right")}
            aria-label="Scroll right"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path
                d="M9 18L15 12L9 6"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>

          {/* Moment Cards Carousel */}
          <div
            className={`collections-carousel collections-carousel--${activeTab}`}
            ref={getCurrentScrollRef()}
            onMouseDown={handleMouseDown}
            onMouseUp={handleMouseUp}
          >
            {getCurrentData().map((moment) => (
              <MomentCard
                key={moment.id}
                title={moment.title}
                filmSeries={moment.filmSeries}
                emotionTag={moment.emotionTag}
                rarity={moment.rarity}
                thumbnailUrl={moment.thumbnailUrl}
                videoUrl={moment.videoUrl}
                owned={moment.owned}
                tradeable={moment.tradeable}
                price={moment.price || moment.listedPrice}
                onAction={(action) => handleMomentAction(action, moment.id)}
                size="default"
                showStats={true}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default MyCollectionsSection;
