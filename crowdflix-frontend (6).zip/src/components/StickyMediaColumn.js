import React, { useState } from "react";
import PropTypes from "prop-types";

const StickyMediaColumn = ({ videoUrl, title, thumbnails = [] }) => {
  const [selectedThumbnail, setSelectedThumbnail] = useState(0);
  const [videoError, setVideoError] = useState(false);

  // Limit thumbnails to 3 max and filter out broken ones
  const validThumbnails = thumbnails
    .slice(0, 3)
    .filter((thumb) => thumb && thumb.length > 0);

  const handleVideoError = () => {
    setVideoError(true);
  };

  return (
    <div className="sticky-media-column">
      <div className="sticky-media-column__content">
        {/* Main Media Container */}
        <div className="sticky-media-column__main">
          <div className="media-wrapper">
            {!videoError && videoUrl ? (
              <video
                src={videoUrl}
                autoPlay
                loop
                muted
                playsInline
                className="main-video"
                poster={validThumbnails[selectedThumbnail]}
                onError={handleVideoError}
              />
            ) : (
              <img
                src={
                  validThumbnails[selectedThumbnail] ||
                  "https://via.placeholder.com/400x300/1a1a1a/ffffff?text=Video+Unavailable"
                }
                alt={title}
                className="fallback-image"
                onError={(e) => {
                  e.target.src =
                    "https://via.placeholder.com/400x300/1a1a1a/ffffff?text=Media+Unavailable";
                }}
              />
            )}

            {/* Video Title Overlay */}
            <div className="media-overlay">
              <h3 className="media-title">{title}</h3>
            </div>
          </div>
        </div>

        {/* Thumbnail Navigation - Only show if we have valid thumbnails */}
        {validThumbnails.length > 1 && (
          <div className="sticky-media-column__thumbnails">
            <div className="thumbnails-grid">
              {validThumbnails.map((thumbnail, index) => (
                <button
                  key={index}
                  className={`thumbnail-btn ${index === selectedThumbnail ? "thumbnail-btn--active" : ""}`}
                  onClick={() => setSelectedThumbnail(index)}
                  aria-label={`View thumbnail ${index + 1}`}
                >
                  <img
                    src={thumbnail}
                    alt={`Thumbnail ${index + 1}`}
                    className="thumbnail-image"
                    onError={(e) => {
                      e.target.src =
                        "https://via.placeholder.com/100x75/1a1a1a/ffffff?text=Thumb";
                    }}
                  />
                  <div className="thumbnail-overlay"></div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

StickyMediaColumn.propTypes = {
  videoUrl: PropTypes.string,
  title: PropTypes.string.isRequired,
  thumbnails: PropTypes.arrayOf(PropTypes.string),
};

StickyMediaColumn.defaultProps = {
  videoUrl: "",
  thumbnails: [],
};

export default StickyMediaColumn;
