import React, { useEffect, useState } from 'react';

import { Button, Form, Modal } from 'react-bootstrap';
import { Plus, Dash } from 'react-bootstrap-icons';

import { doc, updateDoc } from 'firebase/firestore';
import { useDispatch, useSelector } from 'react-redux';
import { selectUser, updateUserDetails } from '../features/user/userSlice';
import { db } from '../firebase';
import { getAuth, updateProfile } from 'firebase/auth';

import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { storage } from "../firebase";

const UpdateUserModal = () => {
    const dispatch = useDispatch();
    const user = useSelector(selectUser);
    const auth = getAuth();

    const [showModal, setShowModal] = useState(false);
    const [socials, setSocials] = useState(user?.socials || {});
    const [biography, setBiography] = useState(user?.biography || '');

    const [profilePictureFile, setProfilePictureFile] = useState(null);
    const [profilePicture, setProfilePicture] = useState(user?.profilePicture || '');

    const [errorMessage, setErrorMessage] = useState('');
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        if (user?.socials) {
            setSocials(user.socials);
        }
        if (user?.biography) {
            setBiography(user.biography);
        }
        if (user?.profilePicture) {
            setProfilePicture(user.profilePicture);
        }
    }, [user]);

    const handleSocialChange = (event) => {
        setSocials({ ...socials, [event.target.name]: event.target.value });
    };

    const handleBiographyChange = (event) => {
        setBiography(event.target.value);
    };

    const saveChanges = async () => {
        setErrorMessage('');
        setSubmitting(true);

        const auth = getAuth();
        if (!auth.currentUser) {
            setErrorMessage("You must be logged in to upload an image.");
            setSubmitting(false);
            return;
        }

        let profilePictureURL = profilePicture; // Default to existing URL

        // Upload new image if selected
        if (profilePictureFile) {
            const storageRef = ref(storage, `profile_pictures/${auth.currentUser.uid}`);

            try {
                await uploadBytes(storageRef, profilePictureFile); // Upload file
                profilePictureURL = await getDownloadURL(storageRef); // Get file URL
            } catch (error) {
                console.error("Error uploading image:", error.message);
                setErrorMessage(`Upload failed: ${error.message}`);
                setSubmitting(false);
                return;
            }
        }

        // Update user data with new profile picture URL
        const userDetailsToSave = {
            ...user,
            socials: { ...user.socials, ...socials },
            biography,
            profilePicture: profilePictureURL
        };

        const userRef = doc(db, 'users', user.id);
        try {
            await updateDoc(userRef, userDetailsToSave);
            dispatch(updateUserDetails({ userDetails: userDetailsToSave }));

            // Update Firebase Auth profile picture
            if (auth.currentUser && user.profilePicture !== profilePictureURL) {
                await updateProfile(auth.currentUser, { photoURL: profilePictureURL });
            }

            setSubmitting(false);
            setShowModal(false);
        } catch (error) {
            console.error("Error updating document:", error);
            setSubmitting(false);
        }
    };

    return (
        <>
            <Button variant='primary' className='m-3' onClick={() => setShowModal(true)}>
                Edit Profile
            </Button>

            <Modal show={showModal} onHide={() => setShowModal(false)} dialogClassName="modal-lg">
                <Modal.Header closeButton className='dark-bg text-white'>
                    <Modal.Title>Edit Profile</Modal.Title>
                </Modal.Header>
                <Modal.Body className='dark-bg text-white'>
                    <Form id='update-user-details-form' className='dark-bg text-white'>
                        <Form.Group className="mb-3">
                            <Form.Label>Profile Picture URL</Form.Label>
                            <Form.Control
                                type="file"
                                accept="image/*"
                                className="form-control bg-dark border-dark text-white mb-3"
                                onChange={(e) => setProfilePictureFile(e.target.files[0])}
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Biography</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={3}
                                value={biography}
                                className="form-control bg-dark border-dark text-white mb-3"
                                placeholder='Tell us about yourself! (100 characters)'
                                maxLength={200}
                                onChange={handleBiographyChange}
                            />
                        </Form.Group>

                        {/* Iterate over socials to create form inputs */}
                        {user.socials && Object.keys(user.socials).map((key) => (
                            <Form.Group className="mb-3" controlId={`social-${key}`} key={key}>
                                <Form.Label>{key.charAt(0).toUpperCase() + key.slice(1)}</Form.Label>
                                <Form.Control
                                    type="text"
                                    name={key}
                                    value={socials[key]}
                                    className="form-control bg-dark border-dark text-white mb-3"
                                    onChange={handleSocialChange}
                                    placeholder={`https://www.${key}.com`}
                                />
                            </Form.Group>
                        ))}

                        {errorMessage && <div className="alert alert-danger w-100 mt-3">{errorMessage}</div>}
                    </Form>
                </Modal.Body>
                <Modal.Footer className='dark-bg text-white'>
                    <Button variant="secondary" onClick={() => setShowModal(false)} disabled={submitting}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={saveChanges} disabled={submitting}>
                        Save Changes
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
};

export default UpdateUserModal;
