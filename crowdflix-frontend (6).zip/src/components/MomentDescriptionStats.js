import React from "react";
import PropTypes from "prop-types";
import "../styles/components/_moment-description-stats.scss";

const MomentDescriptionStats = ({
  description = "Description about moment",
  stats = [
    {
      label: "Unlisted",
      sublabel: "Owned",
      value: "306",
      color: "purple",
      bgColor: "rgba(118, 22, 156, 0.10)",
    },
    {
      label: "For Sale",
      sublabel: "Owned",
      value: "198",
      color: "blue",
      bgColor: "rgba(57, 65, 211, 0.10)",
    },
    {
      label: "Locked",
      sublabel: "Owned",
      value: "459",
      color: "cyan",
      bgColor: "rgba(55, 154, 184, 0.10)",
    },
    {
      label: "Hidden In Packs",
      sublabel: "",
      value: "1.389",
      color: "green",
      bgColor: "rgba(55, 154, 184, 0.10)",
    },
    {
      label: "In The Locker",
      sublabel: "",
      value: "94",
      color: "yellow",
      bgColor: "rgba(139, 127, 56, 0.10)",
    },
    {
      label: "Burned",
      sublabel: "",
      value: "35",
      color: "red",
      bgColor: "rgba(189, 67, 46, 0.10)",
    },
  ],
}) => {
  const getStatColor = (color) => {
    const colors = {
      purple: "#76169C",
      blue: "#3941D3",
      cyan: "#379AB8",
      green: "#388B38",
      yellow: "#8B7F38",
      red: "#BD432E",
    };
    return colors[color] || "#76169C";
  };

  return (
    <div className="moment-description-stats">
      <div className="description-section">
        <div className="section-header">
          <h3 className="section-title">Description</h3>
          <div className="expand-button">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <circle
                cx="9"
                cy="9"
                r="8"
                stroke="white"
                strokeWidth="1.15"
                strokeOpacity="0.5"
              />
              <path
                d="M9 5V13"
                stroke="white"
                strokeWidth="1.15"
                strokeOpacity="0.5"
              />
              <path
                d="M12 8L9 5L6 8"
                stroke="white"
                strokeWidth="1.15"
                strokeOpacity="0.5"
              />
            </svg>
          </div>
        </div>

        <div className="description-content">
          <p className="description-text">{description}</p>
        </div>

        <div className="statistics-grid">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="stat-card"
              style={{ backgroundColor: stat.bgColor }}
            >
              <div className="stat-visual">
                <div className="stat-bar-background"></div>
                <div
                  className="stat-bar"
                  style={{ backgroundColor: getStatColor(stat.color) }}
                ></div>
                <div className="stat-bars">
                  {Array.from({ length: 41 }, (_, i) => (
                    <div
                      key={i}
                      className="stat-bar-segment"
                      style={{ backgroundColor: getStatColor(stat.color) }}
                    ></div>
                  ))}
                </div>
              </div>

              <div className="stat-info">
                <div className="stat-label">
                  <span className="stat-primary">{stat.label}</span>
                  {stat.sublabel && (
                    <span className="stat-secondary">{stat.sublabel}</span>
                  )}
                </div>
                <div className="stat-value">{stat.value}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

MomentDescriptionStats.propTypes = {
  description: PropTypes.string,
  stats: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string,
      sublabel: PropTypes.string,
      value: PropTypes.string,
      color: PropTypes.string,
      bgColor: PropTypes.string,
    }),
  ),
};

export default MomentDescriptionStats;
