import React, { useState, useRef, useCallback, useEffect } from "react";
import PropTypes from "prop-types";
import "../styles/components/_moment-media-display.scss";

const MomentMediaDisplay = ({
  videoUrl = "https://cdn.builder.io/o/assets%2FYJIGb4i01jvw0SRdL5Bt%2Fd27731a526464deba0016216f5f9e570%2Fcompressed?apiKey=YJIGb4i01jvw0SRdL5Bt&token=d27731a526464deba0016216f5f9e570&alt=media&optimized=true",
  // eslint-disable-next-line no-unused-vars
  angle1,
  // eslint-disable-next-line no-unused-vars
  angle2,
  // eslint-disable-next-line no-unused-vars
  angle3,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [showControls, setShowControls] = useState(false);
  const videoRef = useRef(null);

  // Detect mobile device
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(
        window.innerWidth <= 768 ||
          /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
            navigator.userAgent,
          ),
      );
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);

    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  // Handle video play/pause
  const handleVideoPlayback = useCallback((shouldPlay) => {
    if (videoRef.current) {
      if (shouldPlay) {
        videoRef.current.play().catch(() => {
          // Autoplay failed, user interaction required
        });
        setIsPlaying(true);
      } else {
        videoRef.current.pause();
        setIsPlaying(false);
      }
    }
  }, []);

  // Handle audio toggle
  const handleAudioToggle = useCallback(() => {
    if (videoRef.current) {
      const newMutedState = !isMuted;
      videoRef.current.muted = newMutedState;
      setIsMuted(newMutedState);
    }
  }, [isMuted]);

  // Handle controls toggle
  const handleControlsToggle = useCallback(() => {
    setShowControls(!showControls);
    if (videoRef.current) {
      videoRef.current.controls = !showControls;
    }
  }, [showControls]);

  // Desktop hover handlers
  const handleMouseEnter = useCallback(() => {
    if (!isMobile) {
      setIsHovered(true);
      handleVideoPlayback(true);
    }
  }, [isMobile, handleVideoPlayback]);

  const handleMouseLeave = useCallback(() => {
    if (!isMobile) {
      setIsHovered(false);
      handleVideoPlayback(false);
    }
  }, [isMobile, handleVideoPlayback]);

  // Mobile tap handler
  const handleTap = useCallback(() => {
    if (isMobile) {
      handleVideoPlayback(!isPlaying);
    }
  }, [isMobile, isPlaying, handleVideoPlayback]);

  return (
    <div className="moment-media-display">
      <div
        className="video-viewer"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        onClick={handleTap}
      >
        <video
          ref={videoRef}
          poster="https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F5a1c0dbf6e324f6a88e34e2230cae9b7"
          controls={showControls}
          muted={isMuted}
          loop={true}
          playsInline
          className="moment-video"
        >
          <source
            type="video/mp4"
            src="https://cdn.builder.io/o/assets%2F92b18821349144eaae5d92cdfc438e52%2F6a936f3d11c94380a6e2d33e5da39a43%2Fcompressed?apiKey=92b18821349144eaae5d92cdfc438e52&token=6a936f3d11c94380a6e2d33e5da39a43&alt=media&optimized=true"
          />
          <source src={videoUrl} type="video/mp4" />
        </video>

        {/* Play/Pause Indicator for Mobile */}
        {isMobile && (
          <div
            className={`mobile-play-indicator ${isPlaying ? "playing" : "paused"}`}
          >
            {isPlaying ? (
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
                <rect
                  x="6"
                  y="4"
                  width="4"
                  height="16"
                  fill="white"
                  fillOpacity="0.9"
                />
                <rect
                  x="14"
                  y="4"
                  width="4"
                  height="16"
                  fill="white"
                  fillOpacity="0.9"
                />
              </svg>
            ) : (
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
                <path d="M8 5V19L19 12L8 5Z" fill="white" fillOpacity="0.9" />
              </svg>
            )}
          </div>
        )}

        {/* Hover Indicator for Desktop */}
        {!isMobile && isHovered && (
          <div className="desktop-hover-indicator">
            <div className="hover-ripple"></div>
          </div>
        )}

        {/* Video Control Buttons */}
        <div className="video-controls">
          <button
            className={`control-btn audio-btn ${isMuted ? "muted" : "unmuted"}`}
            onClick={handleAudioToggle}
            title={isMuted ? "Unmute Audio" : "Mute Audio"}
          >
            {isMuted ? (
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path
                  d="M16.5 12C16.5 10.23 15.5 8.71 14 7.97V10.18L16.45 12.63C16.48 12.43 16.5 12.22 16.5 12ZM19 12C19 12.94 18.8 13.82 18.46 14.64L19.97 16.15C20.63 14.91 21 13.5 21 12C21 7.72 18 4.14 14 3.23V5.29C16.89 6.15 19 8.83 19 12ZM4.27 3L3 4.27L7.73 9H3V15H7L12 20V13.27L16.25 17.53C15.58 18.04 14.83 18.45 14 18.7V20.77C15.38 20.45 16.63 19.82 17.68 18.96L19.73 21L21 19.73L12 10.73L4.27 3ZM12 4L9.91 6.09L12 8.18V4Z"
                  fill="currentColor"
                />
              </svg>
            ) : (
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path
                  d="M3 9V15H7L12 20V4L7 9H3ZM16.5 12C16.5 10.23 15.5 8.71 14 7.97V16.02C15.5 15.29 16.5 13.77 16.5 12ZM14 3.23V5.29C16.89 6.15 19 8.83 19 12C19 15.17 16.89 17.85 14 18.71V20.77C18.01 19.86 21 16.28 21 12C21 7.72 18.01 4.14 14 3.23Z"
                  fill="currentColor"
                />
              </svg>
            )}
          </button>

          <button
            className={`control-btn controls-btn ${showControls ? "active" : ""}`}
            onClick={handleControlsToggle}
            title={showControls ? "Hide Controls" : "Show Controls"}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path
                d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM10 17L5 12L6.41 10.59L10 14.17L17.59 6.58L19 8L10 17Z"
                fill="currentColor"
              />
            </svg>
          </button>
        </div>

        {/* Video Status Overlay */}
        <div
          className={`video-status-overlay ${isPlaying ? "playing" : "paused"}`}
        >
          <div className="status-indicator">
            <div className="status-dot"></div>
            <span className="status-text">
              {isPlaying
                ? isMuted
                  ? "Playing (Muted)"
                  : "Playing"
                : isMobile
                  ? "Tap to Play"
                  : "Hover to Play"}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

MomentMediaDisplay.propTypes = {
  videoUrl: PropTypes.string,
  // Keeping angle props for future Builder.io integration
  angle1: PropTypes.string,
  angle2: PropTypes.string,
  angle3: PropTypes.string,
};

export default MomentMediaDisplay;
