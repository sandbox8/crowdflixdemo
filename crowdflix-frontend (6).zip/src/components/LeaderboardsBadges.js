import React from "react";
import PropTypes from "prop-types";

const LeaderboardsBadges = ({ leaderboards, badges }) => {
  const getRarityColor = (rarity) => {
    switch (rarity) {
      case "immortal":
        return "#FFD700";
      case "legendary":
        return "#A356FB";
      case "epic":
        return "#9D4EDD";
      case "rare":
        return "#FBC956";
      default:
        return "#42A2FD";
    }
  };

  const getRankSuffix = (rank) => {
    if (rank % 10 === 1 && rank % 100 !== 11) return "st";
    if (rank % 10 === 2 && rank % 100 !== 12) return "nd";
    if (rank % 10 === 3 && rank % 100 !== 13) return "rd";
    return "th";
  };

  return (
    <div className="leaderboards-badges">
      {/* Leaderboards Section */}
      <div className="leaderboards-badges__section">
        <h4 className="leaderboards-badges__title">
          <span className="leaderboards-badges__icon">🏆</span>
          Leaderboards
        </h4>
        <div className="leaderboards-badges__leaderboards">
          {leaderboards.map((leaderboard) => (
            <div key={leaderboard.title} className="leaderboard-item">
              <div className="leaderboard-item__icon">{leaderboard.icon}</div>
              <div className="leaderboard-item__content">
                <span className="leaderboard-item__title">
                  {leaderboard.title}
                </span>
                <div className="leaderboard-item__rank">
                  <span className="leaderboard-item__rank-number">
                    #{leaderboard.rank}
                  </span>
                  <span className="leaderboard-item__rank-suffix">
                    {getRankSuffix(leaderboard.rank)}
                  </span>
                  {leaderboard.period && (
                    <span className="leaderboard-item__period">
                      ({leaderboard.period})
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Progress Badges Section */}
      <div className="leaderboards-badges__section">
        <h4 className="leaderboards-badges__title">
          <span className="leaderboards-badges__icon">🏅</span>
          Progress Badges
        </h4>
        <div className="leaderboards-badges__badges">
          {badges.slice(0, 6).map((badge) => (
            <div
              key={badge.id}
              className={`badge-item badge-item--${badge.rarity}`}
              title={badge.name}
              style={{ borderColor: getRarityColor(badge.rarity) }}
            >
              <div
                className="badge-item__icon"
                style={{ color: getRarityColor(badge.rarity) }}
              >
                {badge.icon}
              </div>
              <div className="badge-item__content">
                <span className="badge-item__name">{badge.name}</span>
                <span
                  className={`badge-item__rarity badge-item__rarity--${badge.rarity}`}
                  style={{ color: getRarityColor(badge.rarity) }}
                >
                  {badge.rarity}
                </span>
              </div>
            </div>
          ))}

          {badges.length > 6 && (
            <div className="badge-item badge-item--more">
              <div className="badge-item__icon">+</div>
              <div className="badge-item__content">
                <span className="badge-item__name">
                  {badges.length - 6} More Badges
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="leaderboards-badges__section">
        <h4 className="leaderboards-badges__title">
          <span className="leaderboards-badges__icon">📊</span>
          Quick Stats
        </h4>
        <div className="leaderboards-badges__quick-stats">
          <div className="quick-stat">
            <span className="quick-stat__value">Top 1%</span>
            <span className="quick-stat__label">Vault XP</span>
          </div>
          <div className="quick-stat">
            <span className="quick-stat__value">247</span>
            <span className="quick-stat__label">Moments</span>
          </div>
          <div className="quick-stat">
            <span className="quick-stat__value">18</span>
            <span className="quick-stat__label">Trades</span>
          </div>
        </div>
      </div>
    </div>
  );
};

LeaderboardsBadges.propTypes = {
  leaderboards: PropTypes.arrayOf(
    PropTypes.shape({
      title: PropTypes.string.isRequired,
      rank: PropTypes.number.isRequired,
      icon: PropTypes.string.isRequired,
      period: PropTypes.string,
    }),
  ).isRequired,
  badges: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      icon: PropTypes.string.isRequired,
      rarity: PropTypes.string.isRequired,
    }),
  ).isRequired,
};

export default LeaderboardsBadges;
