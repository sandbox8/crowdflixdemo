import React from "react";
import PropTypes from "prop-types";

const FollowedStudios = ({ studios, tribes }) => {
  return (
    <div className="followed-studios">
      {/* Followed Studios Section */}
      <div className="followed-studios__section">
        <h4 className="followed-studios__title">
          <span className="followed-studios__icon">🎬</span>
          Followed Studios
        </h4>
        <div className="followed-studios__list">
          {studios.map((studio) => (
            <div key={studio.name} className="studio-item">
              <span className="studio-item__logo">{studio.logo}</span>
              <span className="studio-item__name">{studio.name}</span>
              <span
                className={`studio-item__type studio-item__type--${studio.type}`}
              >
                {studio.type}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Joined Tribes Section */}
      <div className="followed-studios__section">
        <h4 className="followed-studios__title">
          <span className="followed-studios__icon">👥</span>
          Joined Tribes
        </h4>
        <div className="followed-studios__list">
          {tribes.map((tribe) => (
            <div key={tribe.name} className="tribe-item">
              <span className="tribe-item__logo">{tribe.logo}</span>
              <div className="tribe-item__content">
                <span className="tribe-item__name">{tribe.name}</span>
                <span className="tribe-item__members">
                  {tribe.memberCount.toLocaleString()} members
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

FollowedStudios.propTypes = {
  studios: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string.isRequired,
      logo: PropTypes.string.isRequired,
      type: PropTypes.string.isRequired,
    }),
  ).isRequired,
  tribes: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string.isRequired,
      logo: PropTypes.string.isRequired,
      memberCount: PropTypes.number.isRequired,
    }),
  ).isRequired,
};

export default FollowedStudios;
