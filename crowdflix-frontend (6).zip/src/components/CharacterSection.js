const CharacterSection = () => {
  return null;
};

export default CharacterSection;
