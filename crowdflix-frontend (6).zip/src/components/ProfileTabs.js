import React from "react";
import PropTypes from "prop-types";
import VaultTab from "./profile-tabs/VaultTab";
import StorylinesTab from "./profile-tabs/StorylinesTab";
import PacksTab from "./profile-tabs/PacksTab";
import TradeablesTab from "./profile-tabs/TradeablesTab";
import FriendsTab from "./profile-tabs/FriendsTab";
import StatsTab from "./profile-tabs/StatsTab";

const ProfileTabs = ({ activeTab, onTabChange, profile }) => {
  const tabs = [
    {
      id: "vault",
      label: "Vault",
      icon: "🏛️",
      count: profile.stats.vaultedMoments,
    },
    {
      id: "storylines",
      label: "Storylines",
      icon: "📚",
      count: 8, // Sample count of custom playlists
    },
    {
      id: "packs",
      label: "Packs",
      icon: "📦",
      count: 15, // Sample pack count
    },
    {
      id: "tradeables",
      label: "Tradeables",
      icon: "🔄",
      count: 23, // Sample tradeable count
    },
    {
      id: "friends",
      label: "Friends",
      icon: "👥",
      count: profile.followerCount,
    },
    {
      id: "stats",
      label: "Stats",
      icon: "📊",
      count: null,
    },
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case "vault":
        return <VaultTab profile={profile} />;
      case "storylines":
        return <StorylinesTab profile={profile} />;
      case "packs":
        return <PacksTab profile={profile} />;
      case "tradeables":
        return <TradeablesTab profile={profile} />;
      case "friends":
        return <FriendsTab profile={profile} />;
      case "stats":
        return <StatsTab profile={profile} />;
      default:
        return <VaultTab profile={profile} />;
    }
  };

  return (
    <div className="profile-tabs">
      {/* Tab Navigation */}
      <div className="profile-tabs__nav">
        <div className="profile-tabs__nav-container">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              className={`profile-tabs__tab ${
                activeTab === tab.id ? "profile-tabs__tab--active" : ""
              }`}
              onClick={() => onTabChange(tab.id)}
            >
              <span className="profile-tabs__tab-icon">{tab.icon}</span>
              <span className="profile-tabs__tab-label">{tab.label}</span>
              {tab.count !== null && (
                <span className="profile-tabs__tab-count">
                  {tab.count > 999
                    ? `${(tab.count / 1000).toFixed(1)}k`
                    : tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Active Tab Indicator */}
        <div
          className="profile-tabs__indicator"
          style={{
            transform: `translateX(${tabs.findIndex((tab) => tab.id === activeTab) * 100}%)`,
          }}
        />
      </div>

      {/* Tab Content */}
      <div className="profile-tabs__content">{renderTabContent()}</div>
    </div>
  );
};

ProfileTabs.propTypes = {
  activeTab: PropTypes.string.isRequired,
  onTabChange: PropTypes.func.isRequired,
  profile: PropTypes.object.isRequired,
};

export default ProfileTabs;
