import React from "react";
import PropTypes from "prop-types";

const SkeletonLoader = ({
  type = "text",
  width = "100%",
  height = "20px",
  borderRadius = "4px",
  count = 1,
  className = "",
}) => {
  const skeletonStyles = {
    width,
    height,
    borderRadius,
    background:
      "linear-gradient(90deg, rgba(255,255,255,0.1) 25%, rgba(255,255,255,0.2) 50%, rgba(255,255,255,0.1) 75%)",
    backgroundSize: "200% 100%",
    animation: "shimmer 1.5s infinite",
    display: "block",
    marginBottom: count > 1 ? "8px" : "0",
  };

  const cardSkeletonStyles = {
    padding: "20px",
    backgroundColor: "rgba(255, 255, 255, 0.05)",
    borderRadius: "12px",
    border: "1px solid rgba(255, 255, 255, 0.1)",
  };

  const presets = {
    text: { height: "20px", borderRadius: "4px" },
    title: { height: "32px", borderRadius: "6px" },
    button: { height: "44px", borderRadius: "22px" },
    avatar: { width: "40px", height: "40px", borderRadius: "50%" },
    card: { height: "200px", borderRadius: "12px" },
    image: { height: "150px", borderRadius: "8px" },
  };

  const currentPreset = presets[type] || presets.text;
  const finalStyles = {
    ...skeletonStyles,
    ...currentPreset,
    width: width,
  };

  if (type === "card") {
    return (
      <>
        <style>
          {`
            @keyframes shimmer {
              0% {
                background-position: -200% 0;
              }
              100% {
                background-position: 200% 0;
              }
            }
          `}
        </style>
        <div
          style={cardSkeletonStyles}
          className={className}
          role="status"
          aria-label="Loading content"
        >
          <div
            style={{
              ...finalStyles,
              width: "60%",
              height: "24px",
              marginBottom: "16px",
            }}
          ></div>
          <div
            style={{
              ...finalStyles,
              width: "100%",
              height: "16px",
              marginBottom: "8px",
            }}
          ></div>
          <div
            style={{
              ...finalStyles,
              width: "80%",
              height: "16px",
              marginBottom: "16px",
            }}
          ></div>
          <div style={{ ...finalStyles, width: "100%", height: "120px" }}></div>
        </div>
      </>
    );
  }

  return (
    <>
      <style>
        {`
          @keyframes shimmer {
            0% {
              background-position: -200% 0;
            }
            100% {
              background-position: 200% 0;
            }
          }
        `}
      </style>
      <div className={className} role="status" aria-label="Loading content">
        {Array.from({ length: count }, (_, index) => (
          <div
            key={index}
            style={{
              ...finalStyles,
              marginBottom: index < count - 1 ? "8px" : "0",
            }}
          ></div>
        ))}
      </div>
    </>
  );
};

SkeletonLoader.propTypes = {
  type: PropTypes.oneOf(["text", "title", "button", "avatar", "card", "image"]),
  width: PropTypes.string,
  height: PropTypes.string,
  borderRadius: PropTypes.string,
  count: PropTypes.number,
  className: PropTypes.string,
};

export default SkeletonLoader;
