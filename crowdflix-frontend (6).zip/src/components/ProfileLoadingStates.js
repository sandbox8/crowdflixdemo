import React from "react";

export const ProfileHeaderSkeleton = () => (
  <div className="profile-header-skeleton">
    <div className="skeleton-background" />
    <div className="skeleton-content">
      <div className="skeleton-avatar" />
      <div className="skeleton-info">
        <div className="skeleton-name" />
        <div className="skeleton-meta" />
        <div className="skeleton-stats">
          <div className="skeleton-stat" />
          <div className="skeleton-stat" />
          <div className="skeleton-stat" />
        </div>
        <div className="skeleton-actions">
          <div className="skeleton-button" />
          <div className="skeleton-button" />
        </div>
      </div>
    </div>
  </div>
);

export const MomentCardSkeleton = () => (
  <div className="moment-card-skeleton">
    <div className="skeleton-image" />
    <div className="skeleton-content">
      <div className="skeleton-title" />
      <div className="skeleton-franchise" />
      <div className="skeleton-stats">
        <div className="skeleton-stat-group" />
        <div className="skeleton-stat-group" />
      </div>
      <div className="skeleton-footer">
        <div className="skeleton-button-small" />
        <div className="skeleton-value" />
      </div>
    </div>
  </div>
);

export const OverviewCardSkeleton = () => (
  <div className="overview-card-skeleton">
    <div className="skeleton-header">
      <div className="skeleton-title" />
      <div className="skeleton-indicator" />
    </div>
    <div className="skeleton-main-metric" />
    <div className="skeleton-sub-metrics">
      <div className="skeleton-sub-metric" />
      <div className="skeleton-sub-metric" />
    </div>
  </div>
);

export const ProfileLoadingScreen = () => (
  <div className="profile-loading-screen">
    <ProfileHeaderSkeleton />

    <div className="skeleton-tabs">
      {[1, 2, 3, 4, 5].map((i) => (
        <div key={i} className="skeleton-tab" />
      ))}
    </div>

    <div className="skeleton-main-content">
      <div className="skeleton-overview-grid">
        <OverviewCardSkeleton />
        <OverviewCardSkeleton />
        <OverviewCardSkeleton />
      </div>

      <div className="skeleton-moments-grid">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <MomentCardSkeleton key={i} />
        ))}
      </div>
    </div>
  </div>
);

export default ProfileLoadingScreen;
