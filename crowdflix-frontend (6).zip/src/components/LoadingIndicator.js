import React from 'react';

function LoadingIndicator() {
    return <div className="py-5 d-flex justify-content-center">
        <div className="spinner"></div>
    </div>;
}

export default LoadingIndicator;