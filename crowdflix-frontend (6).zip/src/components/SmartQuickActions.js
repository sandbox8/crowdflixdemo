import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import PropTypes from "prop-types";

const SmartQuickActions = ({ className = "" }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isVisible, setIsVisible] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [userContext, setUserContext] = useState({});

  // Determine context-aware actions based on current route
  const contextualActions = useMemo(() => {
    const path = location.pathname;
    const baseActions = [
      {
        id: "search",
        icon: "🔍",
        label: "Search",
        shortcut: "⌘K",
        action: () => {
          // Trigger global search
          const searchEvent = new CustomEvent("openSearch");
          window.dispatchEvent(searchEvent);
        },
      },
    ];

    if (path.startsWith("/u/")) {
      // Profile page actions
      return [
        ...baseActions,
        {
          id: "follow",
          icon: "👤",
          label: "Follow",
          action: () => console.log("Follow user"),
        },
        {
          id: "message",
          icon: "💬",
          label: "Message",
          action: () => console.log("Send message"),
        },
        {
          id: "trade",
          icon: "🔄",
          label: "Trade",
          primary: true,
          action: () => navigate("/marketplace"),
        },
      ];
    } else if (path === "/marketplace") {
      // Marketplace actions
      return [
        ...baseActions,
        {
          id: "filter",
          icon: "⚡",
          label: "Smart Filter",
          action: () => console.log("Apply smart filters"),
        },
        {
          id: "watchlist",
          icon: "⭐",
          label: "Watchlist",
          action: () => console.log("View watchlist"),
        },
        {
          id: "portfolio",
          icon: "📊",
          label: "Portfolio",
          primary: true,
          action: () => navigate("/u/james-blackwood"),
        },
      ];
    } else if (path.startsWith("/moment/")) {
      // Moment detail actions
      return [
        ...baseActions,
        {
          id: "share",
          icon: "📤",
          label: "Share",
          action: () => navigator.share?.({ url: window.location.href }),
        },
        {
          id: "collect",
          icon: "🎯",
          label: "Collect",
          primary: true,
          action: () => console.log("Add to collection"),
        },
      ];
    }

    return baseActions;
  }, [location.pathname, navigate]);

  // Show/hide based on scroll and user activity
  useEffect(() => {
    let timeoutId;
    let lastScrollY = window.scrollY;

    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      const isScrollingDown = currentScrollY > lastScrollY;

      // Show on scroll up or when near top/bottom
      const shouldShow =
        !isScrollingDown ||
        currentScrollY < 100 ||
        window.innerHeight + currentScrollY >=
          document.documentElement.scrollHeight - 100;

      setIsVisible(shouldShow);
      lastScrollY = currentScrollY;

      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        setIsVisible(true); // Always show after scroll stops
      }, 1000);
    };

    const handleMouseMove = () => {
      setIsVisible(true);
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => setIsVisible(false), 3000);
    };

    window.addEventListener("scroll", handleScroll);
    window.addEventListener("mousemove", handleMouseMove);

    // Initial show
    setIsVisible(true);

    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("mousemove", handleMouseMove);
      clearTimeout(timeoutId);
    };
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeydown = (e) => {
      if (e.metaKey || e.ctrlKey) {
        switch (e.key) {
          case "k":
            e.preventDefault();
            contextualActions.find((a) => a.id === "search")?.action();
            break;
          case "1":
            e.preventDefault();
            contextualActions[1]?.action();
            break;
          case "2":
            e.preventDefault();
            contextualActions[2]?.action();
            break;
          default:
            break;
        }
      }
    };

    window.addEventListener("keydown", handleKeydown);
    return () => window.removeEventListener("keydown", handleKeydown);
  }, [contextualActions]);

  const handleToggleExpand = useCallback(() => {
    setIsExpanded(!isExpanded);
  }, [isExpanded]);

  const primaryAction = contextualActions.find((action) => action.primary);
  const secondaryActions = contextualActions.filter(
    (action) => !action.primary,
  );

  if (!isVisible && !isExpanded) return null;

  return (
    <div
      className={`smart-quick-actions ${isVisible ? "visible" : ""} ${isExpanded ? "expanded" : ""} ${className}`}
    >
      {/* Primary Action Button */}
      {primaryAction && (
        <button
          className="quick-action primary-action"
          onClick={primaryAction.action}
          title={primaryAction.label}
        >
          <span className="action-icon">{primaryAction.icon}</span>
          <span className="action-label">{primaryAction.label}</span>
        </button>
      )}

      {/* Secondary Actions */}
      <div className="secondary-actions">
        {secondaryActions
          .slice(0, isExpanded ? secondaryActions.length : 3)
          .map((action, index) => (
            <button
              key={action.id}
              className="quick-action secondary-action"
              onClick={action.action}
              title={action.label}
              style={{ "--delay": `${index * 50}ms` }}
            >
              <span className="action-icon">{action.icon}</span>
              {isExpanded && (
                <span className="action-label">{action.label}</span>
              )}
              {action.shortcut && !isExpanded && (
                <span className="action-shortcut">{action.shortcut}</span>
              )}
            </button>
          ))}

        {secondaryActions.length > 3 && (
          <button
            className="quick-action expand-action"
            onClick={handleToggleExpand}
            title={isExpanded ? "Show less" : "Show more"}
          >
            <span className="action-icon">{isExpanded ? "◀" : "▶"}</span>
          </button>
        )}
      </div>

      {/* Context Indicator */}
      <div className="context-indicator">
        <div className="context-dot"></div>
      </div>
    </div>
  );
};

SmartQuickActions.propTypes = {
  className: PropTypes.string,
};

export default SmartQuickActions;
