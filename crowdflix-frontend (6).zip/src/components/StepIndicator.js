import React from 'react';

import PropTypes from 'prop-types';

const StepIndicator = ({ steps, currentStep }) => {
    return (
        <div className="step-indicator-container">
            {Array.from({ length: steps }, (_, index) => (
                <div
                    key={index}
                    className={`step-indicator ${currentStep === index + 1 ? 'active' : ''}`}
                />
            ))}
        </div>
    );
};

StepIndicator.propTypes = {
    steps: PropTypes.number.isRequired,
    currentStep: PropTypes.number.isRequired,
};

export default StepIndicator;