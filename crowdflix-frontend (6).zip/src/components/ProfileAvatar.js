import React from 'react';
import PropTypes from 'prop-types'; // ✅ Import PropTypes
import { PersonFill } from 'react-bootstrap-icons';

const ProfileAvatar = ({ profilePicture }) => {
    return (
        <div
            className="avatar mx-auto dark-bg"
            style={{
                backgroundImage: profilePicture ? `url(${profilePicture})` : 'none',
            }}
        >
            {profilePicture ? (
                <img src={profilePicture} className="rounded-circle img-fluid" alt="Profile" />
            ) : (
                <PersonFill color='#c4c4c4' size={'90px'} />
            )}
        </div>
    );
};

// ✅ Add prop-types validation
ProfileAvatar.propTypes = {
    profilePicture: PropTypes.string, // Ensures profilePicture is a string (URL)
};

export default ProfileAvatar;