import React, { useState } from "react";
import PropTypes from "prop-types";
import "../styles/components/_bids-history-table.scss";

const BidsHistoryTable = ({
  timeFilter = "Today",
  bidHistory = [
    {
      id: 1,
      user: "@wemby",
      avatar: "user-3",
      price: "$8.00",
      time: "05:00 pm",
    },
    {
      id: 2,
      user: "@MaktW2n",
      avatar: "user-4",
      price: "$10.00",
      time: "05:25 pm",
    },
    {
      id: 3,
      user: "@SEAfanNSD",
      avatar: "user-5",
      price: "$11.00",
      time: "07:00 pm",
    },
  ],
  highestBid = {
    user: "@Twtbttttt",
    avatar: "user-6",
    price: "$13.00",
    time: "09:00 pm",
  },
}) => {
  const [selectedTimeFilter] = useState(timeFilter);

  const getAvatarColor = (avatar) => {
    const colors = {
      "user-1": "#87BF38",
      "user-2": "#FF2600",
      "user-3": "#FFB800",
      "user-4": "#00AAFF",
      "user-5": "#A02E0E",
      "user-6": "#FFB800",
    };
    return colors[avatar] || "#87BF38";
  };

  const renderUserRow = (userData, isHighlighted = false, key = null) => (
    <div key={key} className={`bid-row ${isHighlighted ? "highlighted" : ""}`}>
      <div className="bid-user">
        <div
          className="user-avatar"
          style={{ borderColor: getAvatarColor(userData.avatar) }}
        >
          <div className="avatar-placeholder"></div>
        </div>
        <span className="user-name">{userData.user}</span>
      </div>

      <div className="bid-details">
        <div className="bid-price">
          <span className="price-amount">{userData.price.split(".")[0]}</span>
          <span className="price-decimal">
            .{userData.price.split(".")[1]}{" "}
          </span>
          <span className="currency">USD</span>
        </div>
        <div className="bid-time">
          <span className="time-value">at {userData.time.split(" ")[0]} </span>
          <span className="time-period">{userData.time.split(" ")[1]}</span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="bids-history-table">
      <div className="section-header">
        <h3 className="section-title">Bids</h3>
        <div className="expand-button">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <circle
              cx="9"
              cy="9"
              r="8"
              stroke="white"
              strokeWidth="1.15"
              strokeOpacity="0.5"
            />
            <path
              d="M9 5V13"
              stroke="white"
              strokeWidth="1.15"
              strokeOpacity="0.5"
            />
            <path
              d="M12 8L9 5L6 8"
              stroke="white"
              strokeWidth="1.15"
              strokeOpacity="0.5"
            />
          </svg>
        </div>
      </div>

      <div className="table-controls">
        <div className="history-label">HISTORY</div>
        <div className="time-filter-dropdown">
          <span className="filter-text">{selectedTimeFilter}</span>
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path
              d="M9.95906 4.4751L6.69906 7.7351C6.31406 8.1201 5.68406 8.1201 5.29906 7.7351L2.03906 4.4751"
              stroke="white"
              strokeWidth="1.15"
              strokeOpacity="0.5"
            />
          </svg>
        </div>
      </div>

      <div className="bid-history">
        {bidHistory.map((bid) => renderUserRow(bid, false, bid.id || bid.user))}
      </div>

      <div className="highest-bid-section">
        <div className="highest-bid-label">Highest bid:</div>
        {renderUserRow(highestBid, true, `highest-${highestBid.user}`)}
      </div>
    </div>
  );
};

BidsHistoryTable.propTypes = {
  timeFilter: PropTypes.string,
  bidHistory: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number,
      user: PropTypes.string,
      avatar: PropTypes.string,
      price: PropTypes.string,
      time: PropTypes.string,
    }),
  ),
  highestBid: PropTypes.shape({
    user: PropTypes.string,
    avatar: PropTypes.string,
    price: PropTypes.string,
    time: PropTypes.string,
  }),
};

export default BidsHistoryTable;
