import React from "react";
import PropTypes from "prop-types";
import MomentCard from "./MomentCard";

const StudioContent = ({ studio, activeTab, onTabChange }) => {
  const tabs = [
    {
      id: "moments",
      label: "Latest Moments",
      count: studio.recentMoments.length,
    },
    { id: "packs", label: "Active Packs", count: studio.activePacks.length },
    { id: "updates", label: "Studio Updates", count: studio.updates.length },
    { id: "about", label: "About", count: null },
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case "moments":
        return (
          <div className="studio-content__moments">
            <div className="studio-moments-grid">
              {studio.recentMoments.map((moment) => (
                <MomentCard
                  key={moment.id}
                  title={moment.title}
                  filmSeries={moment.film}
                  emotionTag={moment.emotion}
                  rarity={moment.rarity}
                  thumbnailUrl={moment.thumbnail}
                  price={moment.price.replace("$", "")}
                  onAction={(action) => console.log(`${action} ${moment.id}`)}
                  size="default"
                  showStats={true}
                />
              ))}
            </div>

            <div className="studio-content__view-all">
              <button className="studio-content__view-all-btn">
                View All {studio.totalMoments} Moments
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M5 12H19M19 12L12 5M19 12L12 19"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
            </div>
          </div>
        );

      case "packs":
        return (
          <div className="studio-content__packs">
            <div className="studio-packs-grid">
              {studio.activePacks.map((pack) => (
                <div key={pack.id} className="studio-pack-card">
                  <div className="studio-pack-card__media">
                    <img
                      src={pack.thumbnail}
                      alt={pack.name}
                      className="studio-pack-card__image"
                    />
                    <div className="studio-pack-card__overlay">
                      <div className="studio-pack-card__rarity">
                        {pack.rarity}
                      </div>
                    </div>
                  </div>

                  <div className="studio-pack-card__content">
                    <h3 className="studio-pack-card__name">{pack.name}</h3>
                    <p className="studio-pack-card__description">
                      {pack.description}
                    </p>

                    <div className="studio-pack-card__stats">
                      <div className="studio-pack-card__stat">
                        <span className="label">Moments</span>
                        <span className="value">{pack.totalMoments}</span>
                      </div>
                      <div className="studio-pack-card__stat">
                        <span className="label">Owned</span>
                        <span className="value">
                          {pack.ownedMoments}/{pack.totalMoments}
                        </span>
                      </div>
                    </div>

                    <div className="studio-pack-card__footer">
                      <span className="studio-pack-card__price">
                        {pack.price}
                      </span>
                      <button className="studio-pack-card__buy-btn">
                        {pack.ownedMoments > 0 ? "Complete Pack" : "Buy Pack"}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case "updates":
        return (
          <div className="studio-content__updates">
            <div className="studio-updates-list">
              {studio.updates.map((update) => (
                <article key={update.id} className="studio-update">
                  <div className="studio-update__header">
                    <div className="studio-update__meta">
                      <span
                        className={`studio-update__type studio-update__type--${update.type}`}
                      >
                        {update.type === "announcement" && "📢"}
                        {update.type === "content" && "🎬"}
                        {update.type === "community" && "👥"}
                        {update.type.charAt(0).toUpperCase() +
                          update.type.slice(1)}
                      </span>
                      <span className="studio-update__timestamp">
                        {update.timestamp}
                      </span>
                    </div>
                  </div>

                  <h3 className="studio-update__title">{update.title}</h3>
                  <p className="studio-update__content">{update.content}</p>

                  <div className="studio-update__engagement">
                    <button className="studio-update__like-btn">
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                      >
                        <path
                          d="M20.84 4.61C20.3292 4.099 19.7228 3.69364 19.0554 3.41708C18.3879 3.14052 17.6725 2.99817 16.95 2.99817C16.2275 2.99817 15.5121 3.14052 14.8446 3.41708C14.1772 3.69364 13.5708 4.099 13.06 4.61L12 5.67L10.94 4.61C9.9083 3.5783 8.5091 2.9987 7.05 2.9987C5.5909 2.9987 4.1917 3.5783 3.16 4.61C2.1283 5.6417 1.5487 7.0409 1.5487 8.5C1.5487 9.9591 2.1283 11.3583 3.16 12.39L12 21.23L20.84 12.39C21.351 11.8792 21.7563 11.2728 22.0329 10.6054C22.3095 9.93789 22.4518 9.22248 22.4518 8.5C22.4518 7.77752 22.3095 7.06211 22.0329 6.39457C21.7563 5.72703 21.351 5.12063 20.84 4.61V4.61Z"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                      {update.engagement}
                    </button>

                    <button className="studio-update__share-btn">
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                      >
                        <path
                          d="M18 16.08C17.24 16.08 16.56 16.38 16.04 16.85L8.91 12.7C8.96 12.47 9 12.24 9 12C9 11.76 8.96 11.53 8.91 11.3L15.96 7.19C16.5 7.69 17.21 8 18 8C19.66 8 21 6.66 21 5C21 3.34 19.66 2 18 2C16.34 2 15 3.34 15 5C15 5.24 15.04 5.47 15.09 5.7L8.04 9.81C7.5 9.31 6.79 9 6 9C4.34 9 3 10.34 3 12C3 13.66 4.34 15 6 15C6.79 15 7.5 14.69 8.04 14.19L15.16 18.34C15.11 18.55 15.08 18.77 15.08 19C15.08 20.61 16.39 21.92 18 21.92C19.61 21.92 20.92 20.61 20.92 19C20.92 17.39 19.61 16.08 18 16.08Z"
                          fill="currentColor"
                        />
                      </svg>
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </div>
        );

      case "about":
        return (
          <div className="studio-content__about">
            <div className="studio-about">
              <section className="studio-about__section">
                <h3 className="studio-about__section-title">
                  About {studio.name}
                </h3>
                <p className="studio-about__section-text">
                  {studio.description}
                </p>
              </section>

              <section className="studio-about__section">
                <h3 className="studio-about__section-title">Studio Details</h3>
                <div className="studio-about__details">
                  <div className="studio-about__detail">
                    <span className="label">Founded</span>
                    <span className="value">{studio.founded}</span>
                  </div>
                  <div className="studio-about__detail">
                    <span className="label">Headquarters</span>
                    <span className="value">{studio.headquarters}</span>
                  </div>
                  {studio.website && (
                    <div className="studio-about__detail">
                      <span className="label">Website</span>
                      <a
                        href={studio.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="value link"
                      >
                        {studio.website.replace("https://", "")}
                      </a>
                    </div>
                  )}
                </div>
              </section>

              {studio.socialLinks && (
                <section className="studio-about__section">
                  <h3 className="studio-about__section-title">Connect</h3>
                  <div className="studio-about__social">
                    {studio.socialLinks.twitter && (
                      <a
                        href={`https://twitter.com/${studio.socialLinks.twitter.replace("@", "")}`}
                        className="studio-about__social-link"
                      >
                        <svg
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                        >
                          <path
                            d="M23 3A10.9 10.9 0 0 1 20.1 4.8 4.48 4.48 0 0 0 22.5 2C21.27 2.65 19.94 3.05 18.6 3.2A4.48 4.48 0 0 0 15.85 2A4.48 4.48 0 0 0 11.37 6.48V8.37A10.66 10.66 0 0 1 3.14 2.66S-1 8 5.25 11.15A4.48 4.48 0 0 1 2.78 10.5V10.89A4.48 4.48 0 0 0 6.36 15.36A4.48 4.48 0 0 1 4.5 15.42A4.48 4.48 0 0 0 8.68 18.81A10.66 10.66 0 0 1 1 20.54A15 15 0 0 0 23 3Z"
                            fill="currentColor"
                          />
                        </svg>
                        {studio.socialLinks.twitter}
                      </a>
                    )}
                    {studio.socialLinks.instagram && (
                      <a
                        href={`https://instagram.com/${studio.socialLinks.instagram.replace("@", "")}`}
                        className="studio-about__social-link"
                      >
                        <svg
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                        >
                          <rect
                            x="2"
                            y="2"
                            width="20"
                            height="20"
                            rx="5"
                            ry="5"
                            stroke="currentColor"
                            strokeWidth="2"
                          />
                          <path
                            d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37Z"
                            stroke="currentColor"
                            strokeWidth="2"
                          />
                          <line
                            x1="17.5"
                            y1="6.5"
                            x2="17.51"
                            y2="6.5"
                            stroke="currentColor"
                            strokeWidth="2"
                          />
                        </svg>
                        {studio.socialLinks.instagram}
                      </a>
                    )}
                  </div>
                </section>
              )}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="studio-content">
      {/* Tab Navigation */}
      <div className="studio-content__tabs">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            className={`studio-content__tab ${
              activeTab === tab.id ? "studio-content__tab--active" : ""
            }`}
            onClick={() => onTabChange(tab.id)}
          >
            <span className="studio-content__tab-label">{tab.label}</span>
            {tab.count !== null && (
              <span className="studio-content__tab-count">{tab.count}</span>
            )}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="studio-content__panel">{renderTabContent()}</div>
    </div>
  );
};

StudioContent.propTypes = {
  studio: PropTypes.object.isRequired,
  activeTab: PropTypes.string.isRequired,
  onTabChange: PropTypes.func.isRequired,
};

export default StudioContent;
