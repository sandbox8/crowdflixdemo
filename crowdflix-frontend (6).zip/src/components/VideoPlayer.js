import React from 'react';

import PropTypes from 'prop-types';
import ReactPlayer from 'react-player';

function VideoPlayer({ url }) {
    return (
        <div className="col-lg-6 mb-3">
            <div className="video-player-container">
                <ReactPlayer
                    className="react-player"
                    url={url}
                    controls
                    width="100%"
                    height="100%"
                />
            </div>
        </div>
    );
}

VideoPlayer.propTypes = {
    url: PropTypes.string.isRequired,
};

export default VideoPlayer;