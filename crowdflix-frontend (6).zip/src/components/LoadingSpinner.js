import React from "react";
import PropTypes from "prop-types";

const LoadingSpinner = ({
  size = "medium",
  color = "#FFC03F",
  message = "Loading...",
  fullscreen = false,
  className = "",
}) => {
  const sizes = {
    small: { width: "24px", height: "24px", borderWidth: "2px" },
    medium: { width: "40px", height: "40px", borderWidth: "3px" },
    large: { width: "60px", height: "60px", borderWidth: "4px" },
  };

  const currentSize = sizes[size] || sizes.medium;

  const spinnerStyles = {
    width: currentSize.width,
    height: currentSize.height,
    border: `${currentSize.borderWidth} solid rgba(255, 255, 255, 0.1)`,
    borderTop: `${currentSize.borderWidth} solid ${color}`,
    borderRadius: "50%",
    animation: "spin 1s linear infinite",
  };

  const containerStyles = fullscreen
    ? {
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        backgroundColor: "rgba(0, 0, 0, 0.8)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 10000,
        backdropFilter: "blur(10px)",
      }
    : {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: "20px",
      };

  return (
    <>
      <style>
        {`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
          
          .loading-pulse {
            animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
          }
          
          @keyframes pulse {
            0%, 100% {
              opacity: 1;
            }
            50% {
              opacity: .5;
            }
          }
        `}
      </style>
      <div
        style={containerStyles}
        className={className}
        role="status"
        aria-live="polite"
      >
        <div style={spinnerStyles}></div>
        {message && (
          <p
            style={{
              color: "#fff",
              fontFamily: "Outfit, sans-serif",
              fontSize: "16px",
              fontWeight: 400,
              marginTop: "20px",
              textAlign: "center",
            }}
            className="loading-pulse"
          >
            {message}
          </p>
        )}
      </div>
    </>
  );
};

LoadingSpinner.propTypes = {
  size: PropTypes.oneOf(["small", "medium", "large"]),
  color: PropTypes.string,
  message: PropTypes.string,
  fullscreen: PropTypes.bool,
  className: PropTypes.string,
};

export default LoadingSpinner;
