import React, { useState } from "react";
import PropTypes from "prop-types";

const HorizontalFilterBar = ({ onFiltersChange, className = "" }) => {
  const [activeFilters, setActiveFilters] = useState(new Set());

  // Filter options in NBA Top Shot style
  const filterOptions = [
    { id: "immortal", label: "Immortals", color: "#FFD700" },
    { id: "legendary", label: "Legendaries", color: "#FF6B35" },
    { id: "epic", label: "Epics", color: "#9D4EDD" },
    { id: "rare", label: "Rares", color: "#3F37C9" },
    { id: "common", label: "Commons", color: "#6C757D" },
    { id: "marvel", label: "Marvel Universe", color: "#E23636" },
    { id: "dc", label: "DC Universe", color: "#0078D4" },
    { id: "anime", label: "Anime Collection", color: "#FF9800" },
    { id: "horror", label: "Horror Classics", color: "#9C27B0" },
    { id: "action", label: "Action Scenes", color: "#FF5722" },
    { id: "drama", label: "Emotional Drama", color: "#2196F3" },
    { id: "debut", label: "CrowdFlix Debut", color: "#4CAF50" },
    { id: "exclusive", label: "Studio Exclusives", color: "#FF1744" },
    { id: "autograph", label: "Autographed", color: "#795548" },
    { id: "behind-scenes", label: "Behind Scenes", color: "#607D8B" },
  ];

  const toggleFilter = (filterId) => {
    const newActiveFilters = new Set(activeFilters);

    if (newActiveFilters.has(filterId)) {
      newActiveFilters.delete(filterId);
    } else {
      newActiveFilters.add(filterId);
    }

    setActiveFilters(newActiveFilters);
    onFiltersChange?.(Array.from(newActiveFilters));
  };

  const clearAllFilters = () => {
    setActiveFilters(new Set());
    onFiltersChange?.([]);
  };

  return (
    <div className={`horizontal-filter-bar ${className}`}>
      <div className="horizontal-filter-bar__container">
        <div className="horizontal-filter-bar__scroll">
          {filterOptions.map((filter) => (
            <button
              key={filter.id}
              className={`filter-pill-horizontal ${
                activeFilters.has(filter.id)
                  ? "filter-pill-horizontal--active"
                  : ""
              }`}
              style={{
                "--filter-color": filter.color,
                "--filter-color-alpha": `${filter.color}20`,
              }}
              onClick={() => toggleFilter(filter.id)}
            >
              {filter.label}
            </button>
          ))}
        </div>

        {activeFilters.size > 0 && (
          <button
            className="horizontal-filter-bar__clear"
            onClick={clearAllFilters}
          >
            Clear All
          </button>
        )}
      </div>
    </div>
  );
};

HorizontalFilterBar.propTypes = {
  onFiltersChange: PropTypes.func,
  className: PropTypes.string,
};

export default HorizontalFilterBar;
