import React from "react";
import { useNavigate } from "react-router-dom";

const FeaturedMomentBanner = () => {
  const navigate = useNavigate();

  const handleExploreClick = () => {
    navigate("/moment/iron-man-reveal");
  };

  return (
    <div className="featured-moment-banner">
      <div className="featured-banner__container">
        <div className="featured-banner__content">
          <div className="featured-banner__icon">🔥</div>
          <div className="featured-banner__text">
            <h3 className="featured-banner__title">
              Explore the Moment That Changed Everything
            </h3>
            <p className="featured-banner__subtitle">
              I Am Iron Man – The moment that launched the MCU
            </p>
          </div>
          <button className="featured-banner__cta" onClick={handleExploreClick}>
            Explore Now
          </button>
        </div>
      </div>
    </div>
  );
};

export default FeaturedMomentBanner;
