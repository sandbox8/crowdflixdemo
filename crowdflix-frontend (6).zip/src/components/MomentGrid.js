import React, { useState } from "react";
import PropTypes from "prop-types";
import { useInView } from "react-intersection-observer";
import MomentCard from "./MomentCard";
import LoadingIndicator from "./LoadingIndicator";

function MomentGrid({ moments, isLoading }) {
    const [visibleCount, setVisibleCount] = useState(9); // Load initial 9 moments

    // Observe when the last element is in view
    const { ref, inView } = useInView({
        threshold: 0.1, // Triggers when 10% of the element is visible
        rootMargin: "100px",
    });

    // Load more when inView is triggered
    React.useEffect(() => {
        if (inView) {
            console.log("Loading more moments...");
            setVisibleCount((prev) => prev + 6);
        }
    }, [inView]);

    if (isLoading) {
        return LoadingIndicator();
    }

    return (
        <div className="container">
            {moments.length === 0 ? (
                <div className="text-center p-5"><p>No moments found 😕</p></div>
            ) : (
                <div className="row g-3 text-center mt-3">
                    {moments.slice(0, visibleCount).map((moment, index) => (
                        <MomentCard key={moment.id} moment={moment} />
                    ))}
                </div>
            )}

            {/* Infinite scroll trigger element */}
            <div ref={ref} style={{ height: "20px", width: "100%" }}></div>
        </div>
    );
}

// ✅ PropTypes
MomentGrid.propTypes = {
    moments: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.string.isRequired,
            momentThumbnailImg: PropTypes.string.isRequired,
            momentName: PropTypes.string.isRequired,
            momentDescription: PropTypes.string.isRequired,
            productionHouse: PropTypes.string.isRequired,
        })
    ).isRequired,
    isLoading: PropTypes.bool.isRequired
};

export default MomentGrid;