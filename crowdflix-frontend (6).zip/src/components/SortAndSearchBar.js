import React, { useState } from "react";
import PropTypes from "prop-types";

const SortAndSearchBar = ({
  activeTab = "Moments",
  onTabChange = () => {},
  onSearchChange = () => {},
  // eslint-disable-next-line no-unused-vars
  onSortChange,
  onFilterToggle = () => {},
}) => {
  const [searchValue, setSearchValue] = useState("");
  const [sortBy] = useState("Latest");

  const tabs = ["All", "Moments", "Packs", "Latest Purchases", "Top Purchases"];

  const handleSearchChange = (e) => {
    setSearchValue(e.target.value);
    onSearchChange(e.target.value);
  };

  return (
    <div className="sort-and-search-bar">
      {/* Filter button */}
      <button className="filter-button" onClick={onFilterToggle}>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path
            d="M23.5 22.5L28.707 17.293C28.895 17.105 29 16.851 29 16.586V14C29 13.448 28.552 13 28 13H14C13.448 13 13 13.448 13 14V16.586C13 16.851 13.105 17.106 13.293 17.293L18.5 22.5"
            stroke="#2AA2FD"
            strokeWidth="1.15"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M18.5 22.5V28.749C18.5 29.562 19.264 30.159 20.053 29.962L22.553 29.337C23.109 29.198 23.5 28.698 23.5 28.124V22.5"
            stroke="#2AA2FD"
            strokeWidth="1.15"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </button>

      {/* Search input */}
      <div className="search-container">
        <div className="search-input">
          <svg
            className="search-icon"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
          >
            <path
              d="M25.747 15.187C28.663 18.103 28.663 22.831 25.747 25.747C22.831 28.663 18.103 28.663 15.187 25.747C12.271 22.831 12.271 18.103 15.187 15.187C18.103 12.271 22.831 12.271 25.747 15.187"
              stroke="#FFC03F"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M29 29L25.75 25.75"
              stroke="#FFC03F"
              strokeWidth="1.15"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <input
            type="text"
            placeholder="Search"
            value={searchValue}
            onChange={handleSearchChange}
          />
        </div>
      </div>

      {/* Sort dropdown */}
      <div className="sort-dropdown">
        <span className="sort-label">Release date</span>
        <span className="sort-value">{sortBy}</span>
        <svg
          className="dropdown-arrow"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
        >
          <path
            d="M8 10L12 14L16 10"
            stroke="#FFC03F"
            strokeWidth="1.15"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>

      {/* Tabs */}
      <div className="tabs-container">
        {tabs.map((tab) => (
          <button
            key={tab}
            className={`tab ${activeTab === tab ? "active" : ""}`}
            onClick={() => onTabChange(tab)}
          >
            {tab}
          </button>
        ))}
      </div>
    </div>
  );
};

SortAndSearchBar.propTypes = {
  activeTab: PropTypes.string,
  onTabChange: PropTypes.func,
  onSearchChange: PropTypes.func,
  onSortChange: PropTypes.func,
  onFilterToggle: PropTypes.func,
};

export default SortAndSearchBar;
