import React, { useState } from "react";
import PropTypes from "prop-types";

const MarketplaceFilterSidebar = ({
  onFilterChange = () => {},
  onClearAll = () => {},
}) => {
  const [filters, setFilters] = useState({
    status: ["Unlisted"],
    tier: ["Fandom"],
    universe: ["Marvel", "MonsterVerse"],
    characters: ["Doctor Strange"],
    priceRange: [130, 1000],
  });

  const [expandedSections, setExpandedSections] = useState({
    status: true,
    tier: false,
    universe: false,
    characters: false,
    price: false,
  });

  const toggleSection = (section) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const toggleFilter = (category, value) => {
    setFilters((prev) => {
      const updated = { ...prev };
      if (updated[category].includes(value)) {
        updated[category] = updated[category].filter((item) => item !== value);
      } else {
        updated[category] = [...updated[category], value];
      }
      onFilterChange(updated);
      return updated;
    });
  };

  const clearCategory = (category) => {
    setFilters((prev) => {
      const updated = { ...prev, [category]: [] };
      onFilterChange(updated);
      return updated;
    });
  };

  const handleClearAll = () => {
    setFilters({
      status: [],
      tier: [],
      universe: [],
      characters: [],
      priceRange: [0, 1000],
    });
    onClearAll();
  };

  const universeOptions = [
    {
      name: "Marvel",
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/431fb2fbec35e9d057c18620b00456d46bcf5bd6",
    },
    {
      name: "MonsterVerse",
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/39dec08162d0049257a83d8d49da949aadc543c2",
    },
  ];

  const characterOptions = [
    {
      name: "Doctor Strange",
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/8af1bfd88c2cd19662890a0729d111bef4e2b651",
    },
  ];

  return (
    <div className="marketplace-filter-sidebar">
      {/* Header */}
      <div className="filter-header">
        <div className="filter-title">Add filters</div>
        <button className="clear-all-btn" onClick={handleClearAll}>
          Clear All
        </button>
      </div>

      {/* Status Filter */}
      <div className="filter-section">
        <div
          className="filter-section-header"
          onClick={() => toggleSection("status")}
        >
          <span className="section-title">Status</span>
          <svg
            className={`chevron ${expandedSections.status ? "expanded" : ""}`}
            width="10"
            height="6"
            viewBox="0 0 10 6"
            fill="none"
          >
            <path
              opacity="0.5"
              d="M1 5L5 1L9 5"
              stroke="white"
              strokeWidth="1.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>

        {expandedSections.status && (
          <div className="filter-options">
            <div className="status-pills">
              <button
                className={`status-pill ${filters.status.includes("Listed") ? "active" : ""}`}
                onClick={() => toggleFilter("status", "Listed")}
              >
                Listed
              </button>
              <button
                className={`status-pill ${filters.status.includes("Unlisted") ? "active" : ""}`}
                onClick={() => toggleFilter("status", "Unlisted")}
              >
                Unlisted
              </button>
              <button className="status-pill-ampersand">&amp;</button>
            </div>
          </div>
        )}
      </div>

      {/* Tier Filter */}
      <div className="filter-section">
        <div
          className="filter-section-header"
          onClick={() => toggleSection("tier")}
        >
          <span className="section-title">Tier</span>
          <div className="header-actions">
            <button className="clear-btn" onClick={() => clearCategory("tier")}>
              Clear
            </button>
            <svg
              className={`chevron ${expandedSections.tier ? "expanded" : ""}`}
              width="10"
              height="6"
              viewBox="0 0 10 6"
              fill="none"
            >
              <path
                opacity="0.5"
                d="M1 5L5 1L9 5"
                stroke="white"
                strokeWidth="1.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
        </div>

        {expandedSections.tier && (
          <div className="filter-options">
            <div className="checkbox-list">
              {["Common", "Fandom", "Rare", "Legendary", "Ultimate"].map(
                (tier) => (
                  <div key={tier} className="checkbox-item">
                    <div
                      className={`checkbox ${filters.tier.includes(tier) ? "checked" : ""}`}
                      onClick={() => toggleFilter("tier", tier)}
                    >
                      {filters.tier.includes(tier) && (
                        <svg
                          width="10"
                          height="10"
                          viewBox="0 0 10 10"
                          fill="none"
                        >
                          <path
                            d="M1 5.52174L4.5 9L9 1"
                            stroke="#5D5D5D"
                            strokeWidth="1.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      )}
                    </div>
                    <span
                      className={`checkbox-label ${filters.tier.includes(tier) ? "active" : ""}`}
                    >
                      {tier}
                    </span>
                  </div>
                ),
              )}
            </div>
          </div>
        )}
      </div>

      {/* Universe Filter */}
      <div className="filter-section">
        <div
          className="filter-section-header"
          onClick={() => toggleSection("universe")}
        >
          <span className="section-title">Universe</span>
          <div className="header-actions">
            <button
              className="clear-btn"
              onClick={() => clearCategory("universe")}
            >
              Clear
            </button>
            <svg
              className={`chevron ${expandedSections.universe ? "expanded" : ""}`}
              width="10"
              height="6"
              viewBox="0 0 10 6"
              fill="none"
            >
              <path
                opacity="0.5"
                d="M1 5L5 1L9 5"
                stroke="white"
                strokeWidth="1.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
        </div>

        {expandedSections.universe && (
          <div className="filter-options">
            <div className="search-input">
              <input type="text" placeholder="Search here" />
              <svg
                className="dropdown-icon"
                width="10"
                height="6"
                viewBox="0 0 10 6"
                fill="none"
              >
                <path
                  opacity="0.5"
                  d="M9 1L5 5L1 1"
                  stroke="white"
                  strokeWidth="1.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>

            <div className="icon-list">
              {universeOptions.map((option) => (
                <div key={option.name} className="icon-item">
                  <div className="icon-item-content">
                    <img
                      src={option.icon}
                      alt={option.name}
                      className="universe-icon"
                    />
                    <span className="icon-label">{option.name}</span>
                  </div>
                  {filters.universe.includes(option.name) && (
                    <svg
                      className="check-icon"
                      width="10"
                      height="10"
                      viewBox="0 0 10 10"
                      fill="none"
                    >
                      <path
                        d="M1 5.52174L4.5 9L9 1"
                        stroke="white"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Characters Filter */}
      <div className="filter-section">
        <div
          className="filter-section-header"
          onClick={() => toggleSection("characters")}
        >
          <span className="section-title">Characters</span>
          <div className="header-actions">
            <button
              className="clear-btn"
              onClick={() => clearCategory("characters")}
            >
              Clear
            </button>
            <svg
              className={`chevron ${expandedSections.characters ? "expanded" : ""}`}
              width="10"
              height="6"
              viewBox="0 0 10 6"
              fill="none"
            >
              <path
                opacity="0.5"
                d="M1 5L5 1L9 5"
                stroke="white"
                strokeWidth="1.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
        </div>

        {expandedSections.characters && (
          <div className="filter-options">
            <div className="search-input">
              <input type="text" placeholder="Search here" />
              <svg
                className="dropdown-icon"
                width="10"
                height="6"
                viewBox="0 0 10 6"
                fill="none"
              >
                <path
                  opacity="0.5"
                  d="M9 1L5 5L1 1"
                  stroke="white"
                  strokeWidth="1.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>

            <div className="icon-list">
              {characterOptions.map((option) => (
                <div key={option.name} className="icon-item">
                  <div className="icon-item-content">
                    <img
                      src={option.icon}
                      alt={option.name}
                      className="character-icon"
                    />
                    <span className="icon-label">{option.name}</span>
                  </div>
                  {filters.characters.includes(option.name) && (
                    <svg
                      className="check-icon"
                      width="10"
                      height="10"
                      viewBox="0 0 10 10"
                      fill="none"
                    >
                      <path
                        d="M1 5.52174L4.5 9L9 1"
                        stroke="white"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Price Filter */}
      <div className="filter-section">
        <div
          className="filter-section-header"
          onClick={() => toggleSection("price")}
        >
          <span className="section-title">Price ( Lowest Ask )</span>
          <svg
            className={`chevron ${expandedSections.price ? "expanded" : ""}`}
            width="10"
            height="6"
            viewBox="0 0 10 6"
            fill="none"
          >
            <path
              opacity="0.5"
              d="M1 5L5 1L9 5"
              stroke="white"
              strokeWidth="1.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>

        {expandedSections.price && (
          <div className="filter-options">
            <div className="price-slider">
              <div className="slider-track"></div>
              <div className="slider-thumb"></div>
            </div>
            <div className="price-input">
              <span className="price-display">$130.00 USD</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

MarketplaceFilterSidebar.propTypes = {
  onFilterChange: PropTypes.func,
  onClearAll: PropTypes.func,
};

export default MarketplaceFilterSidebar;
