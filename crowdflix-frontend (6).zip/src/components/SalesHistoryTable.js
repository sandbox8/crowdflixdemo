import React, { useState } from "react";
import PropTypes from "prop-types";
import "../styles/components/_sales-history-table.scss";

const SalesHistoryTable = ({
  availableCount = 6,
  sortBy = "Lowest Ask: low to high",
  listings = [
    {
      id: 1,
      price: "$350.00",
      serial: "#37",
      seller: "@EWW",
      avatar: "user-1",
      isSelected: false,
      isHighlighted: false,
    },
    {
      id: 2,
      price: "$400.00",
      serial: "#9",
      seller: "@num1SEAfanNSD",
      avatar: "user-2",
      isSelected: true,
      isHighlighted: true,
    },
    {
      id: 3,
      price: "$550.00",
      serial: "#2",
      seller: "@wemby",
      avatar: "user-3",
      isSelected: false,
      isHighlighted: false,
    },
    {
      id: 4,
      price: "$600.00",
      serial: "#63",
      seller: "@MaktW2n",
      avatar: "user-4",
      isSelected: false,
      isHighlighted: false,
    },
    {
      id: 5,
      price: "$600.00",
      serial: "#24",
      seller: "@SEAfanNSD",
      avatar: "user-5",
      isSelected: false,
      isHighlighted: false,
    },
    {
      id: 6,
      price: "$1,000.00",
      serial: "#71",
      seller: "@Twtbttttt",
      avatar: "user-6",
      isSelected: false,
      isHighlighted: false,
    },
  ],
}) => {
  const [selectedListings, setSelectedListings] = useState(
    listings
      .filter((listing) => listing.isSelected)
      .map((listing) => listing.id),
  );

  const handleSelectionChange = (listingId) => {
    setSelectedListings((prev) =>
      prev.includes(listingId)
        ? prev.filter((id) => id !== listingId)
        : [...prev, listingId],
    );
  };

  const getAvatarColor = (avatar) => {
    const colors = {
      "user-1": "#87BF38",
      "user-2": "#FF2600",
      "user-3": "#FFB800",
      "user-4": "#00AAFF",
      "user-5": "#A02E0E",
      "user-6": "#FFB800",
    };
    return colors[avatar] || "#87BF38";
  };

  return (
    <div className="sales-history-table">
      <div className="section-header">
        <h3 className="section-title">Sales History</h3>
        <div className="expand-button">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <circle
              cx="9"
              cy="9"
              r="8"
              stroke="white"
              strokeWidth="1.15"
              strokeOpacity="0.5"
            />
            <path
              d="M9 5V13"
              stroke="white"
              strokeWidth="1.15"
              strokeOpacity="0.5"
            />
            <path
              d="M12 8L9 5L6 8"
              stroke="white"
              strokeWidth="1.15"
              strokeOpacity="0.5"
            />
          </svg>
        </div>
      </div>

      <div className="table-controls">
        <div className="available-count">{availableCount} Available</div>
        <div className="sort-dropdown">
          <span className="sort-text">{sortBy}</span>
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path
              d="M9.95906 4.47498L6.69906 7.73498C6.31406 8.11998 5.68406 8.11998 5.29906 7.73498L2.03906 4.47498"
              stroke="white"
              strokeWidth="1.15"
              strokeOpacity="0.5"
            />
          </svg>
        </div>
      </div>

      <div className="table-header">
        <div className="header-check">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path
              d="M2.48438 5.88546L5.04403 8.39941L9.52344 4"
              stroke="white"
              strokeWidth="1.15"
              strokeOpacity="0.45"
            />
          </svg>
        </div>
        <div className="header-price">Price</div>
        <div className="header-serial">Serial</div>
        <div className="header-seller">Seller</div>
      </div>

      <div className="listings">
        {listings.map((listing) => (
          <div
            key={listing.id}
            className={`listing-row ${listing.isHighlighted ? "highlighted" : ""}`}
          >
            <div className="listing-check">
              <div
                className={`radio-button ${selectedListings.includes(listing.id) ? "selected" : ""}`}
                onClick={() => handleSelectionChange(listing.id)}
              >
                {selectedListings.includes(listing.id) && (
                  <div className="radio-inner"></div>
                )}
              </div>
            </div>

            <div className="listing-price">{listing.price}</div>
            <div className="listing-serial">{listing.serial}</div>

            <div className="listing-seller">
              <div
                className="user-avatar"
                style={{ borderColor: getAvatarColor(listing.avatar) }}
              >
                <div className="avatar-placeholder"></div>
              </div>
              <span className="seller-name">{listing.seller}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

SalesHistoryTable.propTypes = {
  availableCount: PropTypes.number,
  sortBy: PropTypes.string,
  listings: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number,
      price: PropTypes.string,
      serial: PropTypes.string,
      seller: PropTypes.string,
      avatar: PropTypes.string,
      isSelected: PropTypes.bool,
      isHighlighted: PropTypes.bool,
    }),
  ),
};

export default SalesHistoryTable;
