import React, { useRef } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import MomentCard from "./MomentCard";

const MarketplaceGroupedGrid = ({ className = "" }) => {
  const navigate = useNavigate();

  // Refs for scrolling
  const franchiseRef = useRef(null);
  const emotionalRef = useRef(null);
  const characterRef = useRef(null);
  const trendingRef = useRef(null);

  // Sample data organized by themes
  const marketplaceSections = {
    franchise: {
      id: "franchise",
      emoji: "",
      iconUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F6607286236984051a11f108bbc22662e",
      title: "Iron Man",
      subtitle: "Iconic universes, legendary moments",
      icon: "🛍️",
      gradient: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
      moments: [
        {
          id: "iron-man-reveal",
          title: "I Am Iron Man",
          filmSeries: "Avengers: Endgame",
          emotionTag: "💥 Defiance",
          rarity: "immortal",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F35be60d44b714f869e2fd177463466d3",
          videoUrl:
            "https://cdn.builder.io/o/assets%2FYJIGb4i01jvw0SRdL5Bt%2Fd27731a526464deba0016216f5f9e570%2Fcompressed?apiKey=YJIGb4i01jvw0SRdL5Bt&token=d27731a526464deba0016216f5f9e570&alt=media&optimized=true",
          mediaGallery: [
            {
              type: "image",
              url: "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F5a1c0dbf6e324f6a88e34e2230cae9b7",
              label: "Behind Scenes",
            },
            {
              type: "image",
              url: "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F6ebffc23d7d44c2190d242565dd9fdb9",
              label: "Close-up",
            },
          ],
          contextualInfo: {
            boxOffice: "$2.79B",
            imdbRating: "8.4",
            awards: "Academy Award Winner",
            sceneContext: "Final Battle - Chapter 38",
            director: "Russo Brothers",
            seriesInfo: "MCU Endgame Collection",
            serialNumber: "1/100",
          },
          price: "13,500",
          owned: false,
          featured: true,
          clickable: true,
        },
        {
          id: "franchise-2",
          title: "Excommunicado",
          filmSeries: "IRON MAN",
          emotionTag: "Betrayal",
          rarity: "legendary",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F5c49a326405f4bf0a6a7e6a5ec63c1b8",
          price: "1,850",
          owned: false,
          disabled: true,
        },
        {
          id: "franchise-3",
          title: "Tears in Rain",
          filmSeries: "Blade Runner",
          emotionTag: "Melancholy",
          rarity: "epic",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F91bf9d6b6cd04680adf56fc2069d2434",
          price: "950",
          owned: false,
          disabled: true,
        },
        {
          id: "franchise-4",
          title: "I'll Be Back",
          filmSeries: "Terminator",
          emotionTag: "Determination",
          rarity: "legendary",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fac87d1bb72ee4ac29c4b40fe23f9562b",
          price: "2,100",
          owned: false,
          disabled: true,
        },
      ],
    },
    emotional: {
      id: "emotional",
      emoji: "💔",
      title: "Emotional Vaults",
      subtitle: "Feel every frame, own every emotion",
      icon: "🔁",
      gradient: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
      moments: [
        {
          id: "emotional-1",
          title: "Wilson!",
          filmSeries: "Cast Away",
          emotionTag: "💔 Loss",
          rarity: "epic",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F5a1c0dbf6e324f6a88e34e2230cae9b7",
          mediaGallery: [
            {
              type: "image",
              url: "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F35be60d44b714f869e2fd177463466d3",
              label: "Wide Shot",
            },
            {
              type: "image",
              url: "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F6ebffc23d7d44c2190d242565dd9fdb9",
              label: "Emotional Close-up",
            },
          ],
          contextualInfo: {
            boxOffice: "$429.6M",
            imdbRating: "7.8",
            awards: "Oscar Nominated",
            sceneContext: "Beach Departure - Chapter 12",
            director: "Robert Zemeckis",
            seriesInfo: "Emotional Masterpieces",
            serialNumber: "47/500",
          },
          price: "720",
          owned: false,
          disabled: true,
        },
        {
          id: "emotional-2",
          title: "To Infinity and Beyond",
          filmSeries: "LAdy Birs",
          emotionTag: "Joy",
          rarity: "rare",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fbb61dbdb3aef4351b60d5e75b8509d26",
          price: "450",
          owned: false,
          disabled: true,
        },
        {
          id: "emotional-3",
          title: "Mufasa's Death",
          filmSeries: "The Lion King",
          emotionTag: "Grief",
          rarity: "legendary",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F6ebffc23d7d44c2190d242565dd9fdb9",
          price: "1,650",
          owned: false,
          disabled: true,
        },
        {
          id: "emotional-4",
          title: "Finally Free",
          filmSeries: "The Shawshank Redemption",
          emotionTag: "Liberation",
          rarity: "immortal",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets/TEMP/e318dad147db92f5d6487c15728ee9a42eb4a65b",
          price: "4,200",
          owned: false,
          disabled: true,
        },
      ],
    },
    character: {
      id: "character",
      emoji: "🧙",
      title: "Character Arcs",
      subtitle: "Heroes, villains, and everything between",
      icon: "🎭",
      gradient: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",
      moments: [
        {
          id: "character-1",
          title: "The Dark Knight Rises",
          filmSeries: "Batman Begins",
          emotionTag: "Redemption",
          rarity: "legendary",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fa729d96ede9044caa71bd31ab78d63f7",
          price: "1,950",
          owned: false,
          disabled: true,
        },
        {
          id: "character-2",
          title: "Here's Johnny!",
          filmSeries: "The Shining",
          emotionTag: "Madness",
          rarity: "epic",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F12d9e666c7e049b6a4d62f67ffdc2e27",
          price: "875",
          owned: false,
          disabled: true,
        },
        {
          id: "character-3",
          title: "Final Girl",
          filmSeries: "Halloween",
          emotionTag: "Survival",
          rarity: "rare",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F441b543af84344f08b1433ad2a83c8f4",
          price: "650",
          owned: false,
          disabled: true,
        },
        {
          id: "character-4",
          title: "Why So Serious?",
          filmSeries: "The Dark Knight",
          emotionTag: "Chaos",
          rarity: "immortal",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets/TEMP/e318dad147db92f5d6487c15728ee9a42eb4a65b",
          price: "5,100",
          owned: false,
          disabled: true,
        },
      ],
    },
    trending: {
      id: "trending",
      emoji: "📈",
      title: "Trending Trades:",
      subtitle: "What's hot, what's moving, what matters now",
      icon: "🔥",
      gradient: "linear-gradient(135deg, #fa709a 0%, #fee140 100%)",
      moments: [
        {
          id: "trending-1",
          title: "Portals Scene",
          filmSeries: "Avengers: Endgame",
          emotionTag: "Epic",
          rarity: "immortal",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F1af024ccf9ef4c6db837dc7c19bdbc56",
          price: "6,750",
          owned: false,
          trending: true,
          disabled: true,
        },
        {
          id: "trending-2",
          title: "Dance Scene",
          filmSeries: "Pulp Fiction",
          emotionTag: "Cool",
          rarity: "legendary",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F0edbd217878f45f8b5d952459c17a199",
          price: "2,300",
          owned: false,
          trending: true,
          disabled: true,
        },
        {
          id: "trending-3",
          title: "Spinning Top",
          filmSeries: "Inception",
          emotionTag: "Mystery",
          rarity: "epic",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fac374cdb13ce470f9696083e7ae6690e",
          price: "1,100",
          owned: false,
          trending: true,
          disabled: true,
        },
      ],
    },
  };

  // Scroll functionality
  const scroll = (ref, direction) => {
    if (ref.current) {
      const scrollAmount = 240; // Card width + gap
      const newScrollPosition =
        ref.current.scrollLeft +
        (direction === "left" ? -scrollAmount : scrollAmount);
      ref.current.scrollTo({
        left: newScrollPosition,
        behavior: "smooth",
      });
    }
  };

  // Filter moments based on active filters
  const filterMoments = (moments) => {
    // Apply filter logic here based on filters prop
    // For now, return all moments (can be enhanced with actual filtering)
    return moments;
  };

  // Handle moment actions
  const handleMomentAction = (actionType, momentId) => {
    console.log(`${actionType} action for moment:`, momentId);

    // Navigate to moment detail page for view actions
    if (actionType === "view") {
      navigate(`/moment/${momentId}`);
    }
    // Handle buy actions (could redirect to payment or moment detail)
    else if (actionType === "buy") {
      navigate(`/moment/${momentId}`);
    }
    // Handle trade actions (could open trade modal or redirect)
    else if (actionType === "trade") {
      console.log("Trade functionality not yet implemented");
      // Could open a trade modal or redirect to trading interface
    }
  };

  // Get section ref
  const getSectionRef = (sectionId) => {
    switch (sectionId) {
      case "franchise":
        return franchiseRef;
      case "emotional":
        return emotionalRef;
      case "character":
        return characterRef;
      case "trending":
        return trendingRef;
      default:
        return null;
    }
  };

  return (
    <div className={`marketplace-grouped-grid ${className}`}>
      {Object.values(marketplaceSections).map((section) => {
        const filteredMoments = filterMoments(section.moments);

        if (filteredMoments.length === 0) return null;

        return (
          <div
            key={section.id}
            className="marketplace-section"
            style={{ "--section-gradient": section.gradient }}
          >
            {/* Section Header */}
            <div className="marketplace-section__header">
              <div className="marketplace-section__title-area">
                <div className="marketplace-section__title-group">
                  {section.iconUrl ? (
                    <img
                      src={section.iconUrl}
                      alt={section.title}
                      className="marketplace-section__icon-img"
                      style={{
                        width: "50px",
                        height: "auto",
                        aspectRatio: "1",
                        objectFit: "contain",
                        marginTop: "20px",
                      }}
                    />
                  ) : (
                    <span className="marketplace-section__emoji">
                      {section.emoji}
                    </span>
                  )}
                  <div className="marketplace-section__text">
                    <h3 className="marketplace-section__title">
                      {section.title}
                    </h3>
                    <p className="marketplace-section__subtitle">
                      {section.subtitle}
                    </p>
                  </div>
                </div>

                <div className="marketplace-section__actions">
                  <span className="marketplace-section__icon">
                    {section.icon}
                  </span>
                  <span className="marketplace-section__count">
                    {filteredMoments.length}
                  </span>
                </div>
              </div>

              {/* Scroll Controls */}
              <div className="marketplace-section__controls">
                <button
                  className="marketplace-section__scroll-btn marketplace-section__scroll-btn--left"
                  onClick={() => scroll(getSectionRef(section.id), "left")}
                  aria-label={`Scroll ${section.title} left`}
                >
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <path
                      d="M12.5 15L7.5 10L12.5 5"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>

                <button
                  className="marketplace-section__scroll-btn marketplace-section__scroll-btn--right"
                  onClick={() => scroll(getSectionRef(section.id), "right")}
                  aria-label={`Scroll ${section.title} right`}
                >
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <path
                      d="M7.5 15L12.5 10L7.5 5"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
              </div>
            </div>

            {/* Moment Cards Carousel */}
            <div
              className="marketplace-section__carousel"
              ref={getSectionRef(section.id)}
            >
              {filteredMoments.map((moment) => (
                <MomentCard
                  key={moment.id}
                  title={moment.title}
                  filmSeries={moment.filmSeries}
                  emotionTag={moment.emotionTag}
                  rarity={moment.rarity}
                  thumbnailUrl={moment.thumbnailUrl}
                  videoUrl={moment.videoUrl}
                  mediaGallery={moment.mediaGallery}
                  contextualInfo={moment.contextualInfo}
                  owned={moment.owned}
                  tradeable={moment.tradeable}
                  price={moment.price}
                  onAction={(action) => handleMomentAction(action, moment.id)}
                  size="default"
                  showStats={true}
                  disabled={moment.disabled}
                  featured={moment.featured}
                />
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
};

MarketplaceGroupedGrid.propTypes = {
  filters: PropTypes.object,
  className: PropTypes.string,
};

export default MarketplaceGroupedGrid;
