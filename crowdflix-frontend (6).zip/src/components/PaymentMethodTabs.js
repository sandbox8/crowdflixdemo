import React from "react";
import PropTypes from "prop-types";

const PaymentMethodTabs = ({ activeMethod, onMethodChange }) => {
  const methods = [
    { id: "card", label: "Card" },
    { id: "apple_pay", label: "Apple Pay" },
    { id: "dapper_wallet", label: "Dapper Wallet" },
  ];

  return (
    <div className="payment-method-tabs">
      {methods.map((method) => (
        <button
          key={method.id}
          type="button"
          className={`payment-tab ${activeMethod === method.id ? "active" : ""}`}
          onClick={() => onMethodChange(method.id)}
        >
          {method.label}
        </button>
      ))}
    </div>
  );
};

PaymentMethodTabs.propTypes = {
  activeMethod: PropTypes.string.isRequired,
  onMethodChange: PropTypes.func.isRequired,
};

export default PaymentMethodTabs;
