import React from "react";
import PropTypes from "prop-types";

const SalesSection = () => {
  const salesItems = [
    {
      id: "dune",
      title: "Text",
      subtitle: "Text",
      lowestAsk: "00.00",
      avgSale: "00.00",
      sold: "1,000",
      total: "1,000",
      tier: "Moments",
      tierColor: "#0C6DB6",
      tierTextColor: "#C2E8FF",
      image:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/392c23981a1ba4a806624e3c38b765e54eea65bd",
      layout: "vertical",
    },
    {
      id: "morbius",
      title: "Text",
      subtitle: "Text",
      lowestAsk: "00.00",
      avgSale: "00.00",
      sold: "1,000",
      total: "1,000",
      tier: "Moments",
      tierColor: "#0C6DB6",
      tierTextColor: "#C2E8FF",
      image:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/938dffe969bf7e439de5ecc4f71b00b54e7bd5e4",
      urlIcon:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/7bcc0b8eaaac462fc81c2bf461c9d337706d685b",
      layout: "vertical-detailed",
    },
    {
      id: "johnwick",
      title: "Text",
      subtitle: "Text",
      lowestAsk: "00.00",
      avgSale: "00.00",
      sold: "1,000",
      total: "1,000",
      tier: "Moments",
      tierColor: "#0C6DB6",
      tierTextColor: "#C2E8FF",
      image:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/9714acf69b5f9acbdf0c1e7cfda1833f6e464e54",
      layout: "horizontal",
    },
  ];

  return (
    <div className="sales-section">
      <div className="sales-container">
        {/* Section Title */}
        <div className="section-header">
          <h2 className="section-title">Latest top Sales</h2>
        </div>

        {/* Sales Cards Grid */}
        <div className="sales-grid">
          {salesItems.map((item) => (
            <SalesCard key={item.id} item={item} />
          ))}
        </div>
      </div>
    </div>
  );
};

const SalesCard = ({ item }) => {
  if (item.layout === "horizontal") {
    return <HorizontalSalesCard item={item} />;
  }
  if (item.layout === "vertical-detailed") {
    return <VerticalDetailedSalesCard item={item} />;
  }
  return <VerticalSalesCard item={item} />;
};

const VerticalSalesCard = ({ item }) => {
  return (
    <div className="sales-card-container">
      {/* Custom SVG Background */}
      <svg
        className="card-background"
        width="310"
        height="495"
        viewBox="0 0 310 495"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <foreignObject x="-40" y="-40" width="390" height="575">
          <div className="card-blur-effect"></div>
        </foreignObject>
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M0 48C0 31.1984 0 22.7976 3.2698 16.3803C6.14601 10.7354 10.7354 6.14601 16.3803 3.2698C22.7976 0 31.1984 0 48 0H262C278.802 0 287.202 0 293.62 3.2698C299.265 6.14601 303.854 10.7354 306.73 16.3803C310 22.7976 310 31.1984 310 48V309.251C310 313.02 308.912 316.708 306.866 319.873C302.687 326.338 302.687 334.652 306.866 341.117C308.912 344.282 310 347.97 310 351.738V447C310 463.802 310 472.202 306.73 478.62C303.854 484.265 299.265 488.854 293.62 491.73C287.202 495 278.802 495 262 495H48C31.1984 495 22.7976 495 16.3803 491.73C10.7354 488.854 6.14601 484.265 3.2698 478.62C0 472.202 0 463.802 0 447L0 351.738C0 347.97 1.08829 344.282 3.13408 341.117C7.31285 334.652 7.31285 326.338 3.13408 319.873C1.08829 316.708 0 313.02 0 309.251L0 48Z"
          fill="#1A1A1A"
          fillOpacity="0.7"
        />
      </svg>

      {/* Main Image */}
      <div className="card-image-container">
        <img src={item.image} alt={item.title} className="card-main-image" />
      </div>

      {/* Card Content */}
      <div className="card-content-vertical">
        {/* Pricing Info */}
        <div className="pricing-labels">
          <div className="price-item">
            <span className="price-label">Lowest Ask</span>
          </div>
          <div className="price-value">
            <span className="price-main">${item.lowestAsk.split(".")[0]}</span>
            <span className="price-decimal">
              .{item.lowestAsk.split(".")[1]} USD
            </span>
          </div>
        </div>

        <div className="pricing-labels">
          <div className="price-item">
            <span className="price-label">Avg Sale</span>
          </div>
          <div className="price-value">
            <span className="price-main">${item.avgSale.split(".")[0]}</span>
            <span className="price-decimal">
              .{item.avgSale.split(".")[1]} USD
            </span>
          </div>
        </div>

        {/* Stats */}
        <div className="stats-section">
          <div className="stat-item">
            <span className="stat-label">Sold</span>
          </div>
          <div className="stat-value">
            <span className="stat-number">{item.sold}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Total</span>
          </div>
          <div className="stat-value">
            <span className="stat-number">{item.total}</span>
          </div>
        </div>

        {/* Title */}
        <div className="card-title">
          <span className="title-text">{item.title}</span>
        </div>

        {/* Subtitle */}
        <div className="card-subtitle">
          <span className="subtitle-text">{item.subtitle}</span>
        </div>
      </div>
    </div>
  );
};

const VerticalDetailedSalesCard = ({ item }) => {
  return (
    <div className="sales-card-container">
      {/* Custom SVG Background */}
      <svg
        className="card-background"
        width="310"
        height="495"
        viewBox="0 0 310 495"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <foreignObject x="-40" y="-40" width="390" height="575">
          <div className="card-blur-effect"></div>
        </foreignObject>
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M0 48C0 31.1984 0 22.7976 3.2698 16.3803C6.14601 10.7354 10.7354 6.14601 16.3803 3.2698C22.7976 0 31.1984 0 48 0H262C278.802 0 287.202 0 293.62 3.2698C299.265 6.14601 303.854 10.7354 306.73 16.3803C310 22.7976 310 31.1984 310 48V309.251C310 313.02 308.912 316.708 306.866 319.873C302.687 326.338 302.687 334.652 306.866 341.117C308.912 344.282 310 347.97 310 351.738V447C310 463.802 310 472.202 306.73 478.62C303.854 484.265 299.265 488.854 293.62 491.73C287.202 495 278.802 495 262 495H48C31.1984 495 22.7976 495 16.3803 491.73C10.7354 488.854 6.14601 484.265 3.2698 478.62C0 472.202 0 463.802 0 447L0 351.738C0 347.97 1.08829 344.282 3.13408 341.117C7.31285 334.652 7.31285 326.338 3.13408 319.873C1.08829 316.708 0 313.02 0 309.251L0 48Z"
          fill="#1A1A1A"
          fillOpacity="0.7"
        />
      </svg>

      {/* Image Mask Container */}
      <div className="detailed-image-container">
        <div className="image-mask">
          <img
            src={item.image}
            alt={item.title}
            className="detailed-main-image"
          />
          {item.urlIcon && (
            <img src={item.urlIcon} alt="URL icon" className="url-icon" />
          )}
        </div>
      </div>

      {/* Card Content */}
      <div className="card-content-detailed">
        {/* Title Section */}
        <div className="title-section">
          <div className="pricing-info">
            <div className="price-group">
              <span className="price-label">Lowest Ask</span>
              <div className="price-value">
                <span className="price-main">
                  ${item.lowestAsk.split(".")[0]}
                </span>
                <span className="price-decimal">
                  .{item.lowestAsk.split(".")[1]} USD
                </span>
              </div>
            </div>
          </div>

          <div className="sub-pricing-info">
            <div className="price-group">
              <span className="price-label">Avg Sale</span>
              <div className="price-value">
                <span className="price-main">
                  ${item.avgSale.split(".")[0]}
                </span>
                <span className="price-decimal">
                  .{item.avgSale.split(".")[1]} USD
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="detailed-stats">
          <div className="stat-item">
            <span className="stat-label">Sold</span>
          </div>
          <div className="stat-value">
            <span className="stat-number">{item.sold}</span>
          </div>

          <div className="stat-pill">
            <span className="stat-label">Total</span>
            <span className="stat-number">{item.total}</span>
          </div>
        </div>

        {/* Subtitle */}
        <div className="card-subtitle">
          <span className="subtitle-text">{item.subtitle}</span>
        </div>
      </div>
    </div>
  );
};

const HorizontalSalesCard = ({ item }) => {
  return (
    <div className="sales-card-container horizontal">
      {/* Custom SVG Background */}
      <svg
        className="card-background"
        width="310"
        height="495"
        viewBox="0 0 310 495"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M48 2.5H262C270.442 2.5 276.623 2.50194 281.5 2.90039C286.348 3.29647 289.687 4.0718 292.484 5.49707C297.659 8.13359 301.866 12.3412 304.503 17.5156C305.928 20.3131 306.704 23.6523 307.1 28.5C307.498 33.3771 307.5 39.5582 307.5 48V309.251C307.5 312.538 306.551 315.755 304.767 318.516C300.054 325.806 300.054 335.183 304.767 342.474C306.551 345.234 307.5 348.451 307.5 351.738V447C307.5 455.442 307.498 461.623 307.1 466.5C306.704 471.348 305.928 474.687 304.503 477.484C301.866 482.659 297.659 486.866 292.484 489.503C289.687 490.928 286.348 491.704 281.5 492.1C276.623 492.498 270.442 492.5 262 492.5H48C39.5582 492.5 33.3771 492.498 28.5 492.1C23.6523 491.704 20.3131 490.928 17.5156 489.503C12.3412 486.866 8.13359 482.659 5.49707 477.484C4.0718 474.687 3.29647 471.348 2.90039 466.5C2.50194 461.623 2.5 455.442 2.5 447V351.738C2.50003 348.451 3.44903 345.234 5.2334 342.474C9.94608 335.183 9.94609 325.806 5.2334 318.516C3.44917 315.755 2.5 312.538 2.5 309.251V48C2.5 39.5582 2.50194 33.3771 2.90039 28.5C3.29647 23.6523 4.0718 20.3131 5.49707 17.5156C8.13359 12.3412 12.3412 8.13359 17.5156 5.49707C20.3131 4.0718 23.6523 3.29647 28.5 2.90039C33.3771 2.50194 39.5582 2.5 48 2.5Z"
          stroke="#222222"
          strokeWidth="5"
          fill="rgba(26, 26, 26, 0.7)"
        />
      </svg>

      {/* Horizontal Layout Content */}
      <div className="horizontal-content">
        {/* Image Section */}
        <div className="horizontal-image-section">
          <div className="horizontal-image-container">
            <div className="image-mask">
              <img
                src={item.image}
                alt={item.title}
                className="horizontal-main-image"
              />
            </div>

            {/* Tier Badge */}
            <div className="tier-badge" style={{ background: item.tierColor }}>
              <span style={{ color: item.tierTextColor }}>{item.tier}</span>
            </div>
          </div>
        </div>

        {/* Content Section */}
        <div className="horizontal-text-section">
          {/* Title and Subtitle */}
          <div className="horizontal-title-section">
            <div className="card-title">
              <span className="title-text">{item.title}</span>
            </div>
            <div className="card-subtitle">
              <span className="subtitle-text">{item.subtitle}</span>
            </div>
          </div>

          {/* Pricing */}
          <div className="horizontal-pricing">
            <div className="price-group">
              <span className="price-label">Lowest Ask</span>
              <div className="price-value">
                <span className="price-main">
                  ${item.lowestAsk.split(".")[0]}
                </span>
                <span className="price-decimal">
                  .{item.lowestAsk.split(".")[1]} USD
                </span>
              </div>
            </div>

            <div className="price-group">
              <span className="price-label">Avg Sale</span>
              <div className="price-value">
                <span className="price-main">
                  ${item.avgSale.split(".")[0]}
                </span>
                <span className="price-decimal">
                  .{item.avgSale.split(".")[1]} USD
                </span>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="horizontal-stats">
            <div className="stat-pill">
              <span className="stat-label">Sold</span>
              <span className="stat-number">{item.sold}</span>
            </div>
            <div className="stat-pill">
              <span className="stat-label">Total</span>
              <span className="stat-number">{item.total}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

SalesCard.propTypes = {
  item: PropTypes.shape({
    id: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    subtitle: PropTypes.string.isRequired,
    lowestAsk: PropTypes.string.isRequired,
    avgSale: PropTypes.string.isRequired,
    sold: PropTypes.string.isRequired,
    total: PropTypes.string.isRequired,
    tier: PropTypes.string.isRequired,
    tierColor: PropTypes.string.isRequired,
    tierTextColor: PropTypes.string.isRequired,
    image: PropTypes.string.isRequired,
    urlIcon: PropTypes.string,
    layout: PropTypes.string.isRequired,
  }).isRequired,
};

VerticalSalesCard.propTypes = {
  item: PropTypes.object.isRequired,
};

VerticalDetailedSalesCard.propTypes = {
  item: PropTypes.object.isRequired,
};

HorizontalSalesCard.propTypes = {
  item: PropTypes.object.isRequired,
};

export default SalesSection;
