import React from 'react';

import PropTypes from 'prop-types';

const TierSelector = ({ tiers, selectedTier, onTierChange }) => {
    return (
        <div className="category-selector">
            <div className="category-list">
                {tiers.map((tier) => (
                    <div
                        key={tier.id}
                        className={`category-item ${tier.id === selectedTier.id ? 'active' : ''}`}
                        onClick={() => onTierChange(tier)}
                    >
                        {tier.tierName}
                    </div>
                ))}
            </div>
        </div>
    );
};

TierSelector.propTypes = {
    tiers: PropTypes.arrayOf(PropTypes.object).isRequired,
    selectedTier: PropTypes.object.isRequired,
    onTierChange: PropTypes.func.isRequired,
};

export default TierSelector;