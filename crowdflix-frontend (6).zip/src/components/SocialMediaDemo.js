import React from "react";
import SocialMediaButtons from "./SocialMediaButtons";

const SocialMediaDemo = () => {
  const handleSocialClick = (platform) => {
    console.log(`Clicked on ${platform.label}:`, platform.url);
    // You can add analytics tracking here
    // analytics.track('social_media_click', { platform: platform.name });
  };

  return (
    <div className="social-media-demo">
      <div className="demo-container">
        <div className="demo-section">
          <h2 className="demo-title">Navbar Style</h2>
          <p className="demo-description">
            Compact social buttons for navigation bars
          </p>
          <div className="demo-showcase navbar-bg">
            <SocialMediaButtons
              size="default"
              variant="navbar"
              orientation="horizontal"
              onSocialClick={handleSocialClick}
            />
          </div>
        </div>

        <div className="demo-section">
          <h2 className="demo-title">Footer Style with Labels</h2>
          <p className="demo-description">
            Social buttons with labels for footer sections
          </p>
          <div className="demo-showcase footer-bg">
            <SocialMediaButtons
              size="large"
              variant="footer"
              orientation="horizontal"
              showLabels={true}
              onSocialClick={handleSocialClick}
            />
          </div>
        </div>

        <div className="demo-section">
          <h2 className="demo-title">Sidebar Style</h2>
          <p className="demo-description">
            Vertical layout for sidebar placement
          </p>
          <div className="demo-showcase sidebar-bg">
            <SocialMediaButtons
              size="default"
              variant="sidebar"
              orientation="vertical"
              showLabels={true}
              onSocialClick={handleSocialClick}
            />
          </div>
        </div>

        <div className="demo-section">
          <h2 className="demo-title">Small Compact Version</h2>
          <p className="demo-description">Minimal footprint for tight spaces</p>
          <div className="demo-showcase compact-bg">
            <SocialMediaButtons
              size="small"
              variant="navbar"
              orientation="horizontal"
              onSocialClick={handleSocialClick}
            />
          </div>
        </div>
      </div>

      <style jsx>{`
        .social-media-demo {
          padding: 40px;
          background: linear-gradient(
            135deg,
            #1a1a2e 0%,
            #16213e 50%,
            #0f3460 100%
          );
          min-height: 100vh;
          font-family:
            "Outfit",
            -apple-system,
            Roboto,
            Helvetica,
            sans-serif;
        }

        .demo-container {
          max-width: 1200px;
          margin: 0 auto;
          display: grid;
          gap: 40px;
          grid-template-columns: 1fr;
        }

        .demo-section {
          background: rgba(255, 255, 255, 0.03);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 20px;
          padding: 30px;
          backdrop-filter: blur(10px);
        }

        .demo-title {
          color: #fff;
          font-size: 24px;
          font-weight: 600;
          margin: 0 0 8px 0;
          letter-spacing: -0.02em;
        }

        .demo-description {
          color: rgba(255, 255, 255, 0.7);
          font-size: 14px;
          margin: 0 0 20px 0;
          line-height: 1.5;
        }

        .demo-showcase {
          padding: 30px;
          border-radius: 15px;
          display: flex;
          justify-content: center;
          align-items: center;
          position: relative;
          overflow: hidden;
        }

        .navbar-bg {
          background: rgba(0, 0, 0, 0.4);
          border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-bg {
          background: rgba(20, 24, 28, 0.8);
          border: 1px solid rgba(255, 255, 255, 0.08);
        }

        .sidebar-bg {
          background: rgba(255, 255, 255, 0.02);
          border: 1px solid rgba(255, 255, 255, 0.05);
          width: 200px;
          margin: 0 auto;
        }

        .compact-bg {
          background: rgba(57, 65, 211, 0.1);
          border: 1px solid rgba(57, 65, 211, 0.3);
        }

        @media (max-width: 768px) {
          .social-media-demo {
            padding: 20px;
          }

          .demo-container {
            gap: 20px;
          }

          .demo-section {
            padding: 20px;
          }

          .demo-showcase {
            padding: 20px;
          }

          .sidebar-bg {
            width: 100%;
          }
        }
      `}</style>
    </div>
  );
};

export default SocialMediaDemo;
