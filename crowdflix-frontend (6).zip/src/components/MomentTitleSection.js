import React from "react";
import PropTypes from "prop-types";

const MomentTitleSection = ({
  rarity = "Legendary",
  serialNumber = "#3,498",
  sold = "9,854",
  total = "12,000",
  momentName = "Iron Man",
  subtitle = "MCU Legendary Moment",
  iconUrl = "https://cdn.builder.io/api/v1/image/assets/TEMP/f874c6ddb00d519f7941eda79457c5fd2a177be6",
}) => {
  return (
    <div className="moment-title-section">
      {/* Labels Row */}
      <div className="labels-row">
        <div className="left-badges">
          <div className="rarity-badge">
            <span>{rarity}</span>
          </div>
          <div className="serial-badge">
            <span>{serialNumber}</span>
          </div>
        </div>

        <div className="right-badges">
          <div className="sold-badge">
            <span className="label-text">Sold</span>
            <span className="value-text">{sold}</span>
          </div>
          <div className="total-badge">
            <span className="label-text">Total</span>
            <span className="value-text">{total}</span>
          </div>
        </div>
      </div>

      {/* Title Section */}
      <div className="title-content">
        <div className="title-row">
          <h1 className="moment-title">{momentName}</h1>
          {iconUrl && (
            <img
              src={iconUrl}
              alt={`${momentName} icon`}
              className="moment-icon"
            />
          )}
        </div>
        <div className="subtitle">{subtitle}</div>
      </div>
    </div>
  );
};

MomentTitleSection.propTypes = {
  rarity: PropTypes.string,
  serialNumber: PropTypes.string,
  sold: PropTypes.string,
  total: PropTypes.string,
  momentName: PropTypes.string,
  subtitle: PropTypes.string,
  iconUrl: PropTypes.string,
};

export default MomentTitleSection;
