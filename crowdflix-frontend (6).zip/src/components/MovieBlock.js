import React, { useState } from "react";
import PropTypes from "prop-types";
import "../styles/components/_movie-block.scss";

const MovieBlock = ({
  title = "Avengers: Endgame",
  year = "2019",
  tags = ["Marvel", "Superhero", "Time Travel", "Action", "Sci-Fi"],

  carouselImages = [
    "https://cdn.builder.io/api/v1/image/assets/TEMP/poster1",
    "https://cdn.builder.io/api/v1/image/assets/TEMP/poster2",
    "https://cdn.builder.io/api/v1/image/assets/TEMP/poster3",
  ],
  credits = {
    director: "Ridley Scott",
    writers: "David Franzoni, John Logan",
    producers: "Douglas Wick, David Franzoni, Branko Lustig",
    cinematography: "John Mathieson",
    composers: "Hans Zimmer, Lisa Gerrard",
    releaseDate: "May 1, 2000",
    boxOffice: "$465.5 mln",
  },
}) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % carouselImages.length);
  };

  const getTagColor = (tag) => {
    if (tag.toLowerCase() === "marvel") {
      return "tag-marvel";
    }
    return "tag-default";
  };

  return (
    <div className="movie-block">
      <div className="movie-header">
        <div className="movie-title-section">
          <h2 className="movie-title">
            <span className="title-main">{title.split(":")[0]}:</span>
            {title.includes(":") && (
              <span className="title-subtitle">{title.split(":")[1]}</span>
            )}
          </h2>
          <span className="movie-year">{year}</span>
        </div>

        <div className="movie-tags">
          {tags.map((tag, index) => (
            <span key={index} className={`movie-tag ${getTagColor(tag)}`}>
              {tag}
            </span>
          ))}
        </div>
      </div>

      <div className="movie-carousel">
        <div className="carousel-images">
          {carouselImages.map((image, index) => (
            <div
              key={index}
              className={`carousel-image ${index === currentImageIndex ? "active" : ""}`}
            >
              <img src={image} alt={`${title} scene ${index + 1}`} />
            </div>
          ))}
        </div>

        {carouselImages.length > 1 && (
          <button className="carousel-next" onClick={nextImage}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <circle cx="9" cy="9" r="8" stroke="white" strokeWidth="1.15" />
              <path
                d="M13 9L5 9"
                stroke="white"
                strokeWidth="1.15"
                strokeLinecap="round"
              />
              <path
                d="M10 12L13 9L10 6"
                stroke="white"
                strokeWidth="1.15"
                strokeLinecap="round"
              />
            </svg>
          </button>
        )}
      </div>

      <div className="movie-credits">
        <div className="credit-item">
          <span className="credit-label">Director</span>
          <span className="credit-value">{credits.director}</span>
        </div>

        <div className="credit-item">
          <span className="credit-label">Writers</span>
          <span className="credit-value">{credits.writers}</span>
        </div>

        <div className="credit-item">
          <span className="credit-label">Producers</span>
          <span className="credit-value">{credits.producers}</span>
        </div>

        <div className="credit-item">
          <span className="credit-label">Cinematography</span>
          <span className="credit-value">{credits.cinematography}</span>
        </div>

        <div className="credit-item">
          <span className="credit-label">Composers</span>
          <span className="credit-value">{credits.composers}</span>
        </div>

        <div className="credit-item">
          <span className="credit-label">Release Date</span>
          <span className="credit-value">{credits.releaseDate}</span>
        </div>

        <div className="credit-item">
          <span className="credit-label">Box Office</span>
          <span className="credit-value">{credits.boxOffice}</span>
        </div>
      </div>
    </div>
  );
};

MovieBlock.propTypes = {
  title: PropTypes.string,
  year: PropTypes.string,
  tags: PropTypes.arrayOf(PropTypes.string),
  posterImage: PropTypes.string,
  carouselImages: PropTypes.arrayOf(PropTypes.string),
  credits: PropTypes.shape({
    director: PropTypes.string,
    writers: PropTypes.string,
    producers: PropTypes.string,
    cinematography: PropTypes.string,
    composers: PropTypes.string,
    releaseDate: PropTypes.string,
    boxOffice: PropTypes.string,
  }),
};

export default MovieBlock;
