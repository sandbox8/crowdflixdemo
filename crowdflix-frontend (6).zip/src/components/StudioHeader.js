import React from "react";
import PropTypes from "prop-types";

const StudioHeader = ({ studio, isFollowing, onFollow }) => {
  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: `${studio.name} on CrowdFlix`,
          text: studio.tagline,
          url: window.location.href,
        });
      } else {
        await navigator.clipboard.writeText(window.location.href);
        // Show toast notification
      }
    } catch (err) {
      console.error("Share failed:", err);
    }
  };

  return (
    <div className="studio-header">
      {/* Banner Background */}
      <div className="studio-header__banner">
        <img
          src={studio.banner}
          alt={`${studio.name} banner`}
          className="studio-header__banner-image"
        />
        <div className="studio-header__banner-overlay"></div>
      </div>

      <div className="studio-header__container">
        <div className="studio-header__main">
          {/* Studio Logo */}
          <div className="studio-header__logo-container">
            <img
              src={studio.logo}
              alt={`${studio.name} logo`}
              className="studio-header__logo"
            />
            <div className="studio-header__logo-border"></div>
          </div>

          {/* Studio Info */}
          <div className="studio-header__info">
            <div className="studio-header__name-row">
              <h1 className="studio-header__name">{studio.name}</h1>
              {studio.verified && (
                <div
                  className="studio-header__verified"
                  title="Verified Studio"
                >
                  ✓
                </div>
              )}
            </div>

            <p className="studio-header__tagline">{studio.tagline}</p>
            <p className="studio-header__description">{studio.description}</p>

            {/* Studio Stats */}
            <div className="studio-header__stats">
              <div className="studio-header__stat">
                <span className="studio-header__stat-value">
                  {studio.followers.toLocaleString()}
                </span>
                <span className="studio-header__stat-label">Followers</span>
              </div>
              <div className="studio-header__stat">
                <span className="studio-header__stat-value">
                  {studio.totalMoments}
                </span>
                <span className="studio-header__stat-label">Moments</span>
              </div>
              <div className="studio-header__stat">
                <span className="studio-header__stat-value">
                  {studio.activePacksCount}
                </span>
                <span className="studio-header__stat-label">Active Packs</span>
              </div>
              <div className="studio-header__stat">
                <span className="studio-header__stat-value">
                  Est. {studio.founded}
                </span>
                <span className="studio-header__stat-label">Founded</span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="studio-header__actions">
          <button
            className={`studio-header__follow-btn ${
              isFollowing ? "studio-header__follow-btn--following" : ""
            }`}
            onClick={onFollow}
          >
            <span className="studio-header__follow-icon">
              {isFollowing ? "✓" : "+"}
            </span>
            {isFollowing ? "Following" : "Follow"}
          </button>

          <button
            className="studio-header__share-btn"
            onClick={handleShare}
            title="Share Studio"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path
                d="M18 16.08C17.24 16.08 16.56 16.38 16.04 16.85L8.91 12.7C8.96 12.47 9 12.24 9 12C9 11.76 8.96 11.53 8.91 11.3L15.96 7.19C16.5 7.69 17.21 8 18 8C19.66 8 21 6.66 21 5C21 3.34 19.66 2 18 2C16.34 2 15 3.34 15 5C15 5.24 15.04 5.47 15.09 5.7L8.04 9.81C7.5 9.31 6.79 9 6 9C4.34 9 3 10.34 3 12C3 13.66 4.34 15 6 15C6.79 15 7.5 14.69 8.04 14.19L15.16 18.34C15.11 18.55 15.08 18.77 15.08 19C15.08 20.61 16.39 21.92 18 21.92C19.61 21.92 20.92 20.61 20.92 19C20.92 17.39 19.61 16.08 18 16.08Z"
                fill="currentColor"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

StudioHeader.propTypes = {
  studio: PropTypes.shape({
    name: PropTypes.string.isRequired,
    tagline: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    logo: PropTypes.string.isRequired,
    banner: PropTypes.string.isRequired,
    verified: PropTypes.bool,
    followers: PropTypes.number.isRequired,
    totalMoments: PropTypes.number.isRequired,
    activePacksCount: PropTypes.number.isRequired,
    founded: PropTypes.string.isRequired,
  }).isRequired,
  isFollowing: PropTypes.bool.isRequired,
  onFollow: PropTypes.func.isRequired,
};

export default StudioHeader;
