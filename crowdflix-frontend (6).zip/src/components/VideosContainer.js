import React from 'react';

import PropTypes from 'prop-types';

import VideoPlayer from './VideoPlayer';
import LoadingIndicator from './LoadingIndicator';

const VideosContainer = ({ videos, numVideosToShow }) => {
    if (!Array.isArray(videos)) {
        return LoadingIndicator();
    }

    return (
        <div className="">
            {videos.length === 0 ? (
                <div className="text-center p-5"><p>No videos found 😕</p></div>
            ) : (
                <div className="video-container row">
                    {(numVideosToShow ? videos.slice(0, numVideosToShow) : videos).map((videoUrl) => (
                        <VideoPlayer key={videoUrl} url={videoUrl} />
                    ))}
                </div>
            )}
        </div>
    );
};

VideosContainer.propTypes = {
    videos: PropTypes.arrayOf(PropTypes.string),
    numVideosToShow: PropTypes.number,
};

export default VideosContainer;
