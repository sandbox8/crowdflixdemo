import React from "react";
import PropTypes from "prop-types";

const UniverseHero = ({ logo, bgImage, tagline, name, stats }) => {
  return (
    <section className="universe-hero">
      <div className="universe-hero__background">
        <img
          src={bgImage}
          alt={`${name} background`}
          className="universe-hero__bg-image"
          onError={(e) => {
            e.target.src =
              "https://via.placeholder.com/1200x600/1a1a1a/ffffff?text=Universe+Background";
          }}
        />
        <div className="universe-hero__overlay"></div>
      </div>

      <div className="universe-hero__content">
        <div className="universe-hero__logo-container">
          <img
            src={logo}
            alt={`${name} logo`}
            className="universe-hero__logo"
            onError={(e) => {
              e.target.src =
                "https://via.placeholder.com/200x100/1a1a1a/ffffff?text=Universe+Logo";
            }}
          />
        </div>

        <h1 className="universe-hero__name">{name}</h1>
        <p className="universe-hero__tagline">{tagline}</p>

        {/* Stats Section */}
        <div className="universe-hero__stats">
          <div className="stat-item">
            <span className="stat-number">{stats?.moments || "0"}</span>
            <span className="stat-label">Moments</span>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item">
            <span className="stat-number">{stats?.collectors || "0"}</span>
            <span className="stat-label">Collectors</span>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item">
            <span className="stat-number">{stats?.volume || "$0"}</span>
            <span className="stat-label">Volume</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="universe-hero__actions">
          <button className="universe-hero__btn universe-hero__btn--primary">
            Explore Collection
          </button>
          <button className="universe-hero__btn universe-hero__btn--secondary">
            Follow Universe
          </button>
        </div>
      </div>
    </section>
  );
};

UniverseHero.propTypes = {
  logo: PropTypes.string.isRequired,
  bgImage: PropTypes.string.isRequired,
  tagline: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  stats: PropTypes.shape({
    moments: PropTypes.string,
    collectors: PropTypes.string,
    volume: PropTypes.string,
  }),
};

UniverseHero.defaultProps = {
  stats: {
    moments: "0",
    collectors: "0",
    volume: "$0",
  },
};

export default UniverseHero;
