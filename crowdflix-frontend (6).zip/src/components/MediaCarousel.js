import React, { useState } from "react";
import PropTypes from "prop-types"; // ✅ Import PropTypes

import { Facebook, Instagram, Linkedin, Twitter, Play } from 'react-bootstrap-icons';

import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const MediaCarousel = ({ mediaArray, videoOptions }) => {
    const [selectedMedia, setSelectedMedia] = useState(mediaArray[0]); // Default to first media

    console.log(mediaArray);

    // Function to check if the media is a video
    const isVideo = (media) => {
        return media && /\.(mp4|mov|webm|ogg)/i.test(media);
    };

    // Slick settings for vertical thumbnails
    const settings = {
        vertical: true,
        verticalSwiping: true,
        slidesToShow: Math.min(3, mediaArray.length),
        slidesToScroll: 1,
        infinite: false,
        arrows: false,
        focusOnSelect: true
    };

    return (
        <div className="row">
            {/* Thumbnail Slider */}
            <div className="col-3 d-flex justify-content-center">
                <div className="cast-carousel">
                    <Slider {...settings} className="thumbnail-slider">
                        {mediaArray.map((media, index) => (
                            <div
                                className={`thumbnail-item ${selectedMedia === media ? "active" : ""}`}
                                key={index}
                                onMouseEnter={() => setSelectedMedia(media)}
                            >
                                {isVideo(media) ? (
                                    <div className="video-thumbnail-container">
                                        <video
                                            src={media}
                                            className="thumbnail-video"
                                            muted
                                            playsInline
                                            disablePictureInPicture
                                            controlsList="nodownload nofullscreen noplaybackrate"
                                            onContextMenu={(e) => e.preventDefault()}
                                        />
                                        <div className="video-play-icon">
                                            <Play />
                                        </div>
                                    </div>
                                ) : (
                                    <img
                                        src={media}
                                        alt="Thumbnail"
                                        className="thumbnail-img"
                                    />
                                )}
                            </div>
                        ))}
                    </Slider>
                </div>
            </div>

            {/* Main Display */}
            <div className="col-9">
                <div className="main-display">
                    {selectedMedia ? (
                        isVideo(selectedMedia) ? (
                            <video
                                src={selectedMedia}
                                className="main-media"
                                {...videoOptions}
                                onContextMenu={(e) => e.preventDefault()} // Disable right-click
                                onLoadedMetadata={(e) => e.target.removeAttribute("controls")} // Ensure controls stay hidden
                            />
                        ) : (
                            <img src={selectedMedia} alt="Selected Media" className="main-media" />
                        )
                    ) : (
                        <div className="no-media">No Media Available</div>
                    )}
                </div>
            </div>
        </div>
    );
};

MediaCarousel.propTypes = {
    mediaArray: PropTypes.arrayOf(PropTypes.string).isRequired, // Ensure it's an array of strings (URLs)
    videoOptions: PropTypes.object // Video options are an object (optional)
};

export default MediaCarousel;