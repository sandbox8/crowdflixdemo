import React from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const UniverseSection = () => {
  const universes = [
    {
      id: "marvel",
      name: "Marvel",
      logo: "https://cdn.builder.io/api/v1/image/assets/TEMP/0118dc97e337e410945fe13ce6cb8187bddc6f73",
      background:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/df80af9a61c25940895966bd49d5bffdbc746972",
    },
    {
      id: "dc",
      name: "DC",
      logo: "https://cdn.builder.io/api/v1/image/assets/TEMP/914897f84f0e0fa2e5cd02ff3a33190c645ba843",
      background:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/e5966ac783459e9c1483ec140e09fd661dc5def9",
    },
    {
      id: "v",
      name: "V Universe",
      logo: null,
      background:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/bc312a8162d55b18a12542734dc11cc72bb478e7",
    },
    {
      id: "wizarding",
      name: "Wizarding World",
      logo: null,
      background:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/c0f24ee57051c29e696f551348dc1d6a5bb8317d",
    },
    {
      id: "monsterverse",
      name: "MonsterVerse",
      logo: null,
      background:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/ae7980d92316906169faf933edb327f223433fa1",
    },
    {
      id: "starwars",
      name: "Star Wars",
      logo: null,
      background:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/ae7980d92316906169faf933edb327f223433fa1",
    },
  ];

  const carouselSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: false,
    autoplaySpeed: 3000,
    centerMode: false,
    variableWidth: false,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <div
      style={{
        padding: "80px 40px",
        background: "#000",
      }}
    >
      <div
        style={{
          maxWidth: "1400px",
          margin: "0 auto",
        }}
      >
        {/* Section Header */}
        <div
          style={{
            display: "flex",
            alignItems: "flex-end",
            gap: "40px",
            marginBottom: "60px",
          }}
        >
          <h2
            style={{
              color: "#fff",
              fontSize: "clamp(32px, 6vw, 52px)",
              fontFamily: "Outfit, sans-serif",
              fontWeight: 700,
              lineHeight: "1.1",
              margin: 0,
            }}
          >
            By Universe
          </h2>
          <div
            style={{
              flex: "1 0 0",
              color: "#fff",
              fontSize: "14px",
              fontFamily: "Outfit, sans-serif",
              fontWeight: 400,
              lineHeight: "1.5",
              opacity: 0.8,
              maxWidth: "400px",
            }}
          >
            Dive into cinematic worlds. Explore Marvel, Star Wars, DC, and more
            iconic universes—each packed with legendary stories and
            unforgettable moments.
          </div>
        </div>

        {/* Carousel Container */}
        <div
          className="universe-carousel"
          style={{
            position: "relative",
          }}
        >
          <Slider {...carouselSettings}>
            {universes.map((universe) => (
              <div key={universe.id} style={{ padding: "0 20px" }}>
                <UniverseCard universe={universe} />
              </div>
            ))}
          </Slider>
        </div>
      </div>
    </div>
  );
};

const UniverseCard = ({ universe }) => {
  const [isHovered, setIsHovered] = React.useState(false);

  // Map universe IDs to slugs for routing
  const getUniverseSlug = (id) => {
    const slugMap = {
      marvel: "marvel",
      dc: "dc",
      v: "indieverse",
      wizarding: "wizarding-world",
      monsterverse: "monsterverse",
      starwars: "star-wars",
    };
    return slugMap[id] || id;
  };

  return (
    <Link
      to={`/universe/${getUniverseSlug(universe.id)}`}
      style={{ textDecoration: "none", display: "block" }}
    >
      <div
        style={{
          width: "280px",
          height: "280px",
          position: "relative",
          cursor: "pointer",
          transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
          transform: isHovered
            ? "translateY(-8px) scale(1.02)"
            : "translateY(0) scale(1)",
          margin: "0 auto",
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Geometric Background Card */}
        <div
          style={{
            width: "100%",
            height: "100%",
            background:
              "linear-gradient(145deg, rgba(26, 26, 26, 0.9), rgba(42, 42, 42, 0.7))",
            backdropFilter: "blur(20px)",
            borderRadius: "24px",
            position: "absolute",
            border: "1px solid rgba(255, 255, 255, 0.1)",
            boxShadow: isHovered
              ? "0 20px 40px rgba(42, 162, 253, 0.15), 0 8px 16px rgba(0, 0, 0, 0.3)"
              : "0 8px 32px rgba(0, 0, 0, 0.3)",
            transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
          }}
        />

        {/* Content Container */}
        <div
          style={{
            width: "240px",
            height: "240px",
            position: "absolute",
            left: "20px",
            top: "20px",
            borderRadius: "16px",
            overflow: "hidden",
            background: universe.id === "wizarding" ? "#010101" : "#1a1a1a",
          }}
        >
          {/* Background Image */}
          {universe.background && (
            <img
              src={universe.background}
              alt={universe.name}
              style={{
                width: "100%",
                height: "100%",
                objectFit: "cover",
                position: "absolute",
                top: 0,
                left: 0,
                transition: "transform 0.3s ease",
                transform: isHovered ? "scale(1.1)" : "scale(1)",
              }}
            />
          )}

          {/* Overlay Gradient */}
          <div
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              background:
                "linear-gradient(135deg, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0.7) 100%)",
              transition: "opacity 0.3s ease",
              opacity: isHovered ? 0.8 : 0.6,
            }}
          />

          {/* Logo */}
          {universe.logo && (
            <img
              src={universe.logo}
              alt={`${universe.name} logo`}
              style={{
                position: "absolute",
                left: "50%",
                top: "50%",
                transform: "translate(-50%, -50%)",
                maxWidth: "60%",
                maxHeight: "40%",
                objectFit: "contain",
                zIndex: 2,
                filter: "drop-shadow(0 4px 8px rgba(0,0,0,0.5))",
              }}
            />
          )}

          {/* Universe Name */}
          <div
            style={{
              position: "absolute",
              bottom: "20px",
              left: "20px",
              right: "20px",
              zIndex: 2,
            }}
          >
            <h3
              style={{
                color: "#fff",
                fontFamily: "Outfit, sans-serif",
                fontSize: "18px",
                fontWeight: 600,
                margin: 0,
                textAlign: "center",
                textShadow: "0 2px 4px rgba(0,0,0,0.7)",
                opacity: isHovered ? 1 : 0.9,
              }}
            >
              {universe.name}
            </h3>
          </div>
        </div>

        {/* Hover Border Effect */}
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            borderRadius: "24px",
            border: "2px solid transparent",
            background: isHovered
              ? "linear-gradient(145deg, rgba(42, 162, 253, 0.3), rgba(255, 74, 60, 0.3))"
              : "transparent",
            mask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
            maskComposite: "subtract",
            transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
            pointerEvents: "none",
          }}
        />
      </div>
    </Link>
  );
};

UniverseCard.propTypes = {
  universe: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    logo: PropTypes.string,
    background: PropTypes.string,
  }).isRequired,
};

export default UniverseSection;
