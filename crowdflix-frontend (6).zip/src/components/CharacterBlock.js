import React from "react";
import PropTypes from "prop-types";
import "../styles/components/_character-block.scss";

const CharacterBlock = ({
  name = "Iron Man",
  description = "Iron Man, also known as Tony Stark, is a beloved character from the Marvel Universe, known for his genius intellect, cutting-edge technology, and charismatic personality.",
  alias = "Tony Stark",
  nationality = "U.S",
  height = "6'1",
  actor = "Robert Downey Jr.",
  born = "1973",
  avatarImage = "https://cdn.builder.io/api/v1/image/assets/TEMP/225835f61b9b0d4cbace96462d65f716ee2a4575",
}) => {
  return (
    <div className="character-block">
      <div className="character-content">
        <div className="character-info">
          <div className="character-title-section">
            <h2 className="character-name">{name}</h2>
          </div>

          <p className="character-description">{description}</p>

          <div className="character-details">
            <div className="character-detail-item">
              <span className="detail-label">Alias(es)</span>
              <span className="detail-value">{alias}</span>
            </div>

            <div className="character-detail-item">
              <span className="detail-label">Nationality</span>
              <span className="detail-value">{nationality}</span>
            </div>

            <div className="character-detail-item">
              <span className="detail-label">Height</span>
              <span className="detail-value">{height}</span>
            </div>

            <div className="character-detail-item">
              <span className="detail-label">Portrayed By</span>
              <span className="detail-value">{actor}</span>
            </div>

            <div className="character-detail-item">
              <span className="detail-label">Born</span>
              <span className="detail-value">{born}</span>
            </div>
          </div>
        </div>

        <div className="character-image-section">
          <img src={avatarImage} alt={name} className="character-avatar" />
        </div>
      </div>
    </div>
  );
};

CharacterBlock.propTypes = {
  name: PropTypes.string,
  description: PropTypes.string,
  alias: PropTypes.string,
  nationality: PropTypes.string,
  height: PropTypes.string,
  actor: PropTypes.string,
  born: PropTypes.string,
  avatarImage: PropTypes.string,
};

export default CharacterBlock;
