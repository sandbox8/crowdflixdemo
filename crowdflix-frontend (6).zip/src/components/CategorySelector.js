import React from 'react';

import PropTypes from 'prop-types';

const CategorySelector = ({ categories, selectedCategory, onCategoryChange }) => {
    return (
        <div className="category-selector">
            <div className="category-list">
                {categories.map((category) => (
                    <div
                        key={category.id}
                        className={`category-item ${category.category === selectedCategory.category ? 'active' : ''}`}
                        onClick={() => onCategoryChange(category)}
                    >
                        {category.category}
                    </div>
                ))}
            </div>
        </div>
    );
};

CategorySelector.propTypes = {
    categories: PropTypes.arrayOf(PropTypes.object).isRequired,
    selectedCategory: PropTypes.object.isRequired,
    onCategoryChange: PropTypes.func.isRequired,
};

export default CategorySelector;