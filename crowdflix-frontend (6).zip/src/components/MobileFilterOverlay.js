import React, { useState } from "react";
import PropTypes from "prop-types";
import { ChevronLeft, ChevronDown, ChevronUp } from "react-bootstrap-icons";

const MobileFilterOverlay = ({ isOpen, onClose, onApplyFilters }) => {
  const [expandedSections, setExpandedSections] = useState({
    status: true,
    tier: true,
    universe: true,
    characters: true,
    price: true,
  });

  const [selectedStatus, setSelectedStatus] = useState("Listed");
  const [selectedTier, setSelectedTier] = useState("Fandom");
  const [selectedUniverses, setSelectedUniverses] = useState([
    "Marvel",
    "MonsterVerse",
  ]);
  const [selectedCharacters, setSelectedCharacters] = useState([
    "Doctor Strange",
  ]);
  const [priceValue, setPriceValue] = useState(130);

  const toggleSection = (section) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const clearAllFilters = () => {
    setSelectedStatus("Listed");
    setSelectedTier("");
    setSelectedUniverses([]);
    setSelectedCharacters([]);
    setPriceValue(0);
  };

  const clearTierFilter = () => {
    setSelectedTier("");
  };

  const clearUniverseFilter = () => {
    setSelectedUniverses([]);
  };

  const clearCharacterFilter = () => {
    setSelectedCharacters([]);
  };

  const handleApplyFilters = () => {
    const filters = {
      status: selectedStatus,
      tier: selectedTier,
      universes: selectedUniverses,
      characters: selectedCharacters,
      price: priceValue,
    };
    onApplyFilters(filters);
    onClose();
  };

  const toggleUniverse = (universe) => {
    setSelectedUniverses((prev) =>
      prev.includes(universe)
        ? prev.filter((u) => u !== universe)
        : [...prev, universe],
    );
  };

  const toggleCharacter = (character) => {
    setSelectedCharacters((prev) =>
      prev.includes(character)
        ? prev.filter((c) => c !== character)
        : [...prev, character],
    );
  };

  if (!isOpen) return null;

  return (
    <div className="mobile-filter-overlay">
      <div className="filter-overlay-backdrop" onClick={onClose} />
      <div className="filter-overlay-content">
        {/* Header */}
        <div className="filter-header">
          <button className="back-button" onClick={onClose}>
            <ChevronLeft className="back-icon" />
            <span className="header-title">Add filters</span>
          </button>
          <button className="clear-all-button" onClick={clearAllFilters}>
            Clear All
          </button>
        </div>

        {/* Filter Sections */}
        <div className="filter-sections">
          {/* Status Filter */}
          <div className="filter-section">
            <div
              className="section-header"
              onClick={() => toggleSection("status")}
            >
              <span className="section-title">Status</span>
              {expandedSections.status ? (
                <ChevronUp className="chevron-icon" />
              ) : (
                <ChevronDown className="chevron-icon" />
              )}
            </div>
            {expandedSections.status && (
              <div className="section-content">
                <div className="status-buttons">
                  <button
                    className={`status-button ${selectedStatus === "Listed" ? "active" : ""}`}
                    onClick={() => setSelectedStatus("Listed")}
                  >
                    Listed
                  </button>
                  <button
                    className={`status-button ${selectedStatus === "Unlisted" ? "active unlisted" : ""}`}
                    onClick={() => setSelectedStatus("Unlisted")}
                  >
                    Unlisted
                  </button>
                  <button className="status-button ampersand">&amp;</button>
                </div>
              </div>
            )}
          </div>

          {/* Tier Filter */}
          <div className="filter-section">
            <div
              className="section-header"
              onClick={() => toggleSection("tier")}
            >
              <span className="section-title">Tier</span>
              <div className="section-header-right">
                <button
                  className="clear-section-button"
                  onClick={clearTierFilter}
                >
                  Clear
                </button>
                {expandedSections.tier ? (
                  <ChevronUp className="chevron-icon" />
                ) : (
                  <ChevronDown className="chevron-icon" />
                )}
              </div>
            </div>
            {expandedSections.tier && (
              <div className="section-content">
                <div className="tier-options">
                  {["Common", "Fandom", "Rare", "Legendary", "Ultimate"].map(
                    (tier) => (
                      <label key={tier} className="tier-option">
                        <div
                          className={`radio-circle ${selectedTier === tier ? "checked" : ""}`}
                        >
                          {selectedTier === tier && (
                            <svg
                              className="check-icon"
                              width="10"
                              height="10"
                              viewBox="0 0 10 10"
                              fill="none"
                            >
                              <path
                                d="M1 5.52174L4.5 9L9 1"
                                stroke="#5D5D5D"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              />
                            </svg>
                          )}
                        </div>
                        <span
                          className={`tier-label ${selectedTier === tier ? "active" : ""}`}
                          onClick={() => setSelectedTier(tier)}
                        >
                          {tier}
                        </span>
                      </label>
                    ),
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Universe Filter */}
          <div className="filter-section">
            <div
              className="section-header"
              onClick={() => toggleSection("universe")}
            >
              <span className="section-title">Universe</span>
              <div className="section-header-right">
                <button
                  className="clear-section-button"
                  onClick={clearUniverseFilter}
                >
                  Clear
                </button>
                {expandedSections.universe ? (
                  <ChevronUp className="chevron-icon" />
                ) : (
                  <ChevronDown className="chevron-icon" />
                )}
              </div>
            </div>
            {expandedSections.universe && (
              <div className="section-content">
                <div className="search-input-container">
                  <input
                    type="text"
                    placeholder="Search here"
                    className="search-input"
                  />
                  <ChevronDown className="search-dropdown-icon" />
                </div>
                <div className="universe-options">
                  <div className="universe-option">
                    <div className="universe-info">
                      <img
                        src="https://cdn.builder.io/api/v1/image/assets/TEMP/431fb2fbec35e9d057c18620b00456d46bcf5bd6"
                        alt="Marvel"
                        className="universe-icon"
                      />
                      <span className="universe-label">Marvel</span>
                    </div>
                    <svg
                      className={`check-icon ${selectedUniverses.includes("Marvel") ? "checked" : ""}`}
                      width="10"
                      height="10"
                      viewBox="0 0 10 10"
                      fill="none"
                      onClick={() => toggleUniverse("Marvel")}
                    >
                      <path
                        d="M1 5.52174L4.5 9L9 1"
                        stroke="white"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </div>
                  <div className="universe-option">
                    <div className="universe-info">
                      <img
                        src="https://cdn.builder.io/api/v1/image/assets/TEMP/39dec08162d0049257a83d8d49da949aadc543c2"
                        alt="MonsterVerse"
                        className="universe-icon"
                      />
                      <span className="universe-label">MonsterVerse</span>
                    </div>
                    <svg
                      className={`check-icon ${selectedUniverses.includes("MonsterVerse") ? "checked" : ""}`}
                      width="10"
                      height="10"
                      viewBox="0 0 10 10"
                      fill="none"
                      onClick={() => toggleUniverse("MonsterVerse")}
                    >
                      <path
                        d="M1 5.52174L4.5 9L9 1"
                        stroke="white"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Characters Filter */}
          <div className="filter-section">
            <div
              className="section-header"
              onClick={() => toggleSection("characters")}
            >
              <span className="section-title">Characters</span>
              <div className="section-header-right">
                <button
                  className="clear-section-button"
                  onClick={clearCharacterFilter}
                >
                  Clear
                </button>
                {expandedSections.characters ? (
                  <ChevronUp className="chevron-icon" />
                ) : (
                  <ChevronDown className="chevron-icon" />
                )}
              </div>
            </div>
            {expandedSections.characters && (
              <div className="section-content">
                <div className="search-input-container">
                  <input
                    type="text"
                    placeholder="Search here"
                    className="search-input"
                  />
                  <ChevronDown className="search-dropdown-icon" />
                </div>
                <div className="character-options">
                  <div className="character-option">
                    <div className="character-info">
                      <img
                        src="https://cdn.builder.io/api/v1/image/assets/TEMP/8af1bfd88c2cd19662890a0729d111bef4e2b651"
                        alt="Doctor Strange"
                        className="character-icon"
                      />
                      <span className="character-label">Doctor Strange</span>
                    </div>
                    <svg
                      className={`check-icon ${selectedCharacters.includes("Doctor Strange") ? "checked" : ""}`}
                      width="10"
                      height="10"
                      viewBox="0 0 10 10"
                      fill="none"
                      onClick={() => toggleCharacter("Doctor Strange")}
                    >
                      <path
                        d="M1 5.52174L4.5 9L9 1"
                        stroke="white"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Price Filter */}
          <div className="filter-section">
            <div
              className="section-header"
              onClick={() => toggleSection("price")}
            >
              <span className="section-title">Price ( Lowest Ask )</span>
              {expandedSections.price ? (
                <ChevronUp className="chevron-icon" />
              ) : (
                <ChevronDown className="chevron-icon" />
              )}
            </div>
            {expandedSections.price && (
              <div className="section-content">
                <div className="price-slider-container">
                  <div className="slider-track">
                    <div
                      className="slider-thumb"
                      style={{ left: `${(priceValue / 500) * 100}%` }}
                    />
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="500"
                    value={priceValue}
                    onChange={(e) => setPriceValue(parseInt(e.target.value))}
                    className="price-slider"
                  />
                </div>
                <div className="price-display">
                  <span className="price-value">${priceValue}</span>
                  <span className="price-currency">.00 USD</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Apply Filters Button */}
        <button className="apply-filters-button" onClick={handleApplyFilters}>
          Apply Filters
        </button>
      </div>
    </div>
  );
};

MobileFilterOverlay.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  onApplyFilters: PropTypes.func.isRequired,
};

export default MobileFilterOverlay;
