import React from "react";
import MovieCard from "./MovieCard";

const MovieCardDemo = () => {
  const movieData = [
    {
      id: 1,
      title: "Avengers: Endgame",
      year: 2019,
      posterUrl:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/avengers-endgame-poster.jpg",
      genres: ["Action", "Adventure", "Sci-Fi"],
      rating: 8.4,
      duration: 181,
      director: "Russo Brothers",
      universe: "Marvel",
      studio: "Marvel Studios",
      rarity: "legendary",
      letterboxdData: {
        watchedCount: "2.1M",
        likeCount: "890K",
        listCount: "145K",
      },
      isMarketplaceListing: true,
    },
    {
      id: 2,
      title: "The Dark Knight",
      year: 2008,
      posterUrl:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/dark-knight-poster.jpg",
      genres: ["Action", "Crime", "Drama"],
      rating: 9.0,
      duration: 152,
      director: "Christopher Nolan",
      universe: "DC",
      studio: "Warner Bros",
      rarity: "legendary",
      letterboxdData: {
        watchedCount: "2.8M",
        likeCount: "1.2M",
        listCount: "220K",
      },
      isMarketplaceListing: true,
    },
    {
      id: 3,
      title: "Spider-Man: Into the Spider-Verse",
      year: 2018,
      posterUrl:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/spiderverse-poster.jpg",
      genres: ["Animation", "Action", "Adventure"],
      rating: 8.4,
      duration: 117,
      director: "Bob Persichetti",
      universe: "Marvel",
      studio: "Sony Pictures",
      rarity: "epic",
      letterboxdData: {
        watchedCount: "1.5M",
        likeCount: "780K",
        listCount: "95K",
      },
      isMarketplaceListing: true,
    },
    {
      id: 4,
      title: "Parasite",
      year: 2019,
      posterUrl:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/parasite-poster.jpg",
      genres: ["Thriller", "Drama", "Comedy"],
      rating: 8.6,
      duration: 132,
      director: "Bong Joon-ho",
      universe: "",
      studio: "CJ Entertainment",
      rarity: "epic",
      letterboxdData: {
        watchedCount: "1.8M",
        likeCount: "920K",
        listCount: "180K",
      },
      isMarketplaceListing: true,
    },
    {
      id: 5,
      title: "Dune",
      year: 2021,
      posterUrl:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/dune-poster.jpg",
      genres: ["Sci-Fi", "Adventure", "Drama"],
      rating: 8.0,
      duration: 155,
      director: "Denis Villeneuve",
      universe: "",
      studio: "Warner Bros",
      rarity: "rare",
      letterboxdData: {
        watchedCount: "1.2M",
        likeCount: "650K",
        listCount: "75K",
      },
      isMarketplaceListing: true,
    },
    {
      id: 6,
      title: "Top Gun: Maverick",
      year: 2022,
      posterUrl:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/top-gun-poster.jpg",
      genres: ["Action", "Drama"],
      rating: 8.3,
      duration: 130,
      director: "Joseph Kosinski",
      universe: "",
      studio: "Paramount",
      rarity: "rare",
      letterboxdData: {
        watchedCount: "980K",
        likeCount: "420K",
        listCount: "55K",
      },
      isMarketplaceListing: true,
    },
  ];

  const handleMovieClick = (movie) => {
    console.log("Clicked movie:", movie.title);
    // Navigate to movie page or open details modal
  };

  return (
    <div className="movie-card-demo">
      <div className="demo-container">
        <div className="demo-header">
          <h1 className="demo-title">CrowdFlix Movie Cards</h1>
          <p className="demo-subtitle">
            Premium collectible movie cards with NBA Top Shot inspired rarity
            system
          </p>
        </div>

        <div className="demo-section">
          <h2 className="section-title">🏆 Legendary Cards</h2>
          <p className="section-description">
            Ultra-rare films with holographic effects, animated borders, and
            floating particles
          </p>
          <div className="cards-grid">
            {movieData
              .filter((movie) => movie.rarity === "legendary")
              .map((movie) => (
                <MovieCard
                  key={movie.id}
                  {...movie}
                  onClick={handleMovieClick}
                  showHoverEffects={true}
                />
              ))}
          </div>
        </div>

        <div className="demo-section">
          <h2 className="section-title">⚡ Epic Cards</h2>
          <p className="section-description">
            High-value films with flowing border animations and premium glow
            effects
          </p>
          <div className="cards-grid">
            {movieData
              .filter((movie) => movie.rarity === "epic")
              .map((movie) => (
                <MovieCard
                  key={movie.id}
                  {...movie}
                  onClick={handleMovieClick}
                  showHoverEffects={true}
                />
              ))}
          </div>
        </div>

        <div className="demo-section">
          <h2 className="section-title">💎 Rare Cards</h2>
          <p className="section-description">
            Quality films with subtle glow effects and enhanced interactivity
          </p>
          <div className="cards-grid">
            {movieData
              .filter((movie) => movie.rarity === "rare")
              .map((movie) => (
                <MovieCard
                  key={movie.id}
                  {...movie}
                  onClick={handleMovieClick}
                  showHoverEffects={true}
                />
              ))}
          </div>
        </div>

        <div className="demo-features">
          <div className="feature-grid">
            <div className="feature-card">
              <div className="feature-icon">✨</div>
              <h3 className="feature-title">Rarity System</h3>
              <p className="feature-description">
                Legendary, Epic, Rare, and Common tiers with unique visual
                effects
              </p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">🎬</div>
              <h3 className="feature-title">Cinematic Effects</h3>
              <p className="feature-description">
                Holographic overlays, floating particles, and animated borders
              </p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">📊</div>
              <h3 className="feature-title">Letterboxd Integration</h3>
              <p className="feature-description">
                Real viewing stats, ratings, and community engagement data
              </p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">💫</div>
              <h3 className="feature-title">Interactive Design</h3>
              <p className="feature-description">
                Smooth hover animations with 3D transforms and lighting effects
              </p>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .movie-card-demo {
          min-height: 100vh;
          background: linear-gradient(
            135deg,
            #0f0f23 0%,
            #1a1a2e 50%,
            #16213e 100%
          );
          padding: 40px 20px;
          font-family:
            "Outfit",
            -apple-system,
            Roboto,
            Helvetica,
            sans-serif;
        }

        .demo-container {
          max-width: 1400px;
          margin: 0 auto;
        }

        .demo-header {
          text-align: center;
          margin-bottom: 60px;
        }

        .demo-title {
          color: #fff;
          font-size: 48px;
          font-weight: 700;
          margin: 0 0 16px 0;
          letter-spacing: -0.02em;
          background: linear-gradient(135deg, #fff, #ffd700);
          background-clip: text;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }

        .demo-subtitle {
          color: rgba(255, 255, 255, 0.8);
          font-size: 18px;
          font-weight: 400;
          margin: 0;
          line-height: 1.5;
        }

        .demo-section {
          margin-bottom: 60px;
        }

        .section-title {
          color: #fff;
          font-size: 32px;
          font-weight: 600;
          margin: 0 0 12px 0;
          letter-spacing: -0.01em;
        }

        .section-description {
          color: rgba(255, 255, 255, 0.7);
          font-size: 16px;
          margin: 0 0 30px 0;
          line-height: 1.5;
        }

        .cards-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 30px;
          justify-items: center;
        }

        .demo-features {
          margin-top: 80px;
          padding: 40px;
          background: rgba(255, 255, 255, 0.03);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 30px;
          backdrop-filter: blur(15px);
        }

        .feature-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 30px;
        }

        .feature-card {
          text-align: center;
          padding: 30px 20px;
          background: rgba(255, 255, 255, 0.02);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 20px;
          backdrop-filter: blur(10px);
        }

        .feature-icon {
          font-size: 48px;
          margin-bottom: 20px;
        }

        .feature-title {
          color: #fff;
          font-size: 20px;
          font-weight: 600;
          margin: 0 0 12px 0;
        }

        .feature-description {
          color: rgba(255, 255, 255, 0.7);
          font-size: 14px;
          line-height: 1.5;
          margin: 0;
        }

        @media (max-width: 768px) {
          .movie-card-demo {
            padding: 20px 15px;
          }

          .demo-title {
            font-size: 36px;
          }

          .demo-subtitle {
            font-size: 16px;
          }

          .section-title {
            font-size: 28px;
          }

          .cards-grid {
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
          }

          .feature-grid {
            grid-template-columns: 1fr;
            gap: 20px;
          }

          .demo-features {
            padding: 30px 20px;
            margin-top: 60px;
          }
        }
      `}</style>
    </div>
  );
};

export default MovieCardDemo;
