import React from "react";
import PropTypes from "prop-types";

const PurchaseSummaryCard = ({
  item,
  selectedOffer,
  subtotal,
  shipping,
  taxes,
  total,
}) => {
  return (
    <div className="purchase-summary-card">
      <div className="item-preview">
        <div className="item-image">
          <img src={item.imageUrl} alt={item.name} />
        </div>

        <div className="item-details">
          <div className="item-badges">
            <div className="rarity-badge legendary">Legendary</div>
            <div className="quantity-badge">
              <span className="qty-label">Qty</span>
              <span className="qty-value">{item.quantity}</span>
            </div>
          </div>

          <div className="item-info">
            <h2 className="item-name">{item.name}</h2>
            <p className="item-description">{item.description}</p>
          </div>
        </div>
      </div>

      <div className="pricing-breakdown">
        <div className="pricing-row">
          <span className="pricing-label">..add</span>
          <div className="pricing-value">
            <span className="price-main">
              ${selectedOffer?.price.toFixed(0) || "0"}
            </span>
            <span className="price-cents">
              .{((selectedOffer?.price || 0) % 1).toFixed(2).slice(2)}
            </span>
          </div>
        </div>

        <div className="pricing-row">
          <span className="pricing-label">Subtotal</span>
          <div className="pricing-value">
            <span className="price-main">${subtotal.toFixed(0)}</span>
            <span className="price-cents">
              .{(subtotal % 1).toFixed(2).slice(2)}
            </span>
          </div>
        </div>

        <div className="pricing-row">
          <span className="pricing-label">Shipping</span>
          <div className="pricing-value">
            <span className="price-main">${shipping.toFixed(0)}</span>
            <span className="price-cents">
              .{(shipping % 1).toFixed(2).slice(2)}
            </span>
          </div>
        </div>

        <div className="pricing-divider" />

        <div className="pricing-total">
          <div className="total-info">
            <div className="total-label">Total</div>
            <div className="tax-note">
              Including ${taxes.toFixed(2)} in taxes
            </div>
          </div>
          <div className="total-value">
            <span className="total-main">${total.toFixed(0)}</span>
            <span className="total-cents">
              .{(total % 1).toFixed(2).slice(2)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

PurchaseSummaryCard.propTypes = {
  item: PropTypes.shape({
    name: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    imageUrl: PropTypes.string.isRequired,
    quantity: PropTypes.number.isRequired,
  }).isRequired,
  selectedOffer: PropTypes.object,
  subtotal: PropTypes.number.isRequired,
  shipping: PropTypes.number.isRequired,
  taxes: PropTypes.number.isRequired,
  total: PropTypes.number.isRequired,
};

export default PurchaseSummaryCard;
