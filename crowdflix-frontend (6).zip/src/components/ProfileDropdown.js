import React from 'react';
import PropTypes from 'prop-types';

import { Dropdown } from 'react-bootstrap';
import { PersonFill } from 'react-bootstrap-icons';

import { useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';

import { logout } from '../features/user/userSlice';
import { auth } from '../firebase';

const ProfileDropdown = ({ user }) => {
    const dispatch = useDispatch();

    const logoutOfApp = () => {
        dispatch(logout());
        auth.signOut();
    };

    return (
        <Dropdown>
            <Dropdown.Toggle as="div" className="nav-profile-icon d-flex align-items-center" style={{ cursor: 'pointer' }}>
                {user?.profilePicture ? (
                    <img
                        src={user.profilePicture}
                        className="rounded-circle img-fluid"
                    />
                ) : (
                    <PersonFill color='#c4c4c4' size={30} />
                )}
            </Dropdown.Toggle>

            <Dropdown.Menu align="end" className="dropdown-menu-dark">
                <Dropdown.Item as={Link} to={`/profile/${user.id}`}>
                    Account
                </Dropdown.Item>
                <Dropdown.Item as={Link} to={`/sign-in`} onClick={logoutOfApp}>
                    Sign Out
                </Dropdown.Item>
            </Dropdown.Menu>
        </Dropdown>
    );
};

// **Add PropTypes validation**
ProfileDropdown.propTypes = {
    user: PropTypes.shape({
        id: PropTypes.string.isRequired,
        profilePicture: PropTypes.string
    }).isRequired
};

export default ProfileDropdown;