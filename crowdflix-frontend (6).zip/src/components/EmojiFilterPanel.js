import React, { useState } from "react";
import PropTypes from "prop-types";

const EmojiFilterPanel = ({ onFiltersChange, className = "" }) => {
  const [activeFilters, setActiveFilters] = useState({
    genre: [],
    emotion: [],
    characterType: [],
    era: [],
    theme: [],
    priceRange: [0, 10000],
  });

  const [isExpanded, setIsExpanded] = useState(false);

  // Filter categories with emoji icons
  const filterCategories = {
    genre: {
      emoji: "🎬",
      label: "Genre",
      options: [
        { id: "action", label: "Action", color: "#FF6B35" },
        { id: "romance", label: "Romance", color: "#FF1744" },
        { id: "horror", label: "Horror", color: "#9C27B0" },
        { id: "anime", label: "Anime", color: "#FF9800" },
        { id: "comedy", label: "Comedy", color: "#4CAF50" },
        { id: "drama", label: "Drama", color: "#2196F3" },
        { id: "scifi", label: "Sci-Fi", color: "#00BCD4" },
        { id: "thriller", label: "Thriller", color: "#795548" },
      ],
    },
    emotion: {
      emoji: "❤️",
      label: "Emotion",
      options: [
        { id: "rage", label: "Rage", color: "#F44336" },
        { id: "joy", label: "Joy", color: "#FFEB3B" },
        { id: "regret", label: "Regret", color: "#607D8B" },
        { id: "triumph", label: "Triumph", color: "#4CAF50" },
        { id: "love", label: "Love", color: "#E91E63" },
        { id: "fear", label: "Fear", color: "#9C27B0" },
        { id: "hope", label: "Hope", color: "#2196F3" },
        { id: "despair", label: "Despair", color: "#424242" },
      ],
    },
    characterType: {
      emoji: "🧙",
      label: "Character Type",
      options: [
        { id: "hero", label: "Hero", color: "#4CAF50" },
        { id: "antihero", label: "Anti-Hero", color: "#FF5722" },
        { id: "sidekick", label: "Sidekick", color: "#2196F3" },
        { id: "villain", label: "Villain", color: "#9C27B0" },
        { id: "mentor", label: "Mentor", color: "#FF9800" },
        { id: "trickster", label: "Trickster", color: "#00BCD4" },
      ],
    },
    era: {
      emoji: "🗓️",
      label: "Era",
      options: [
        { id: "80s", label: "80s", color: "#E91E63" },
        { id: "90s", label: "90s", color: "#9C27B0" },
        { id: "2000s", label: "2000s", color: "#2196F3" },
        { id: "2010s", label: "2010s", color: "#4CAF50" },
        { id: "new", label: "New Releases", color: "#FF6B35" },
      ],
    },
    theme: {
      emoji: "🎭",
      label: "Theme",
      options: [
        { id: "revenge", label: "Revenge", color: "#F44336" },
        { id: "coming-of-age", label: "Coming-of-Age", color: "#4CAF50" },
        { id: "betrayal", label: "Betrayal", color: "#795548" },
        { id: "redemption", label: "Redemption", color: "#2196F3" },
        { id: "sacrifice", label: "Sacrifice", color: "#9C27B0" },
        { id: "discovery", label: "Discovery", color: "#00BCD4" },
      ],
    },
  };

  // Price range options
  const priceRanges = [
    { id: "under100", label: "Under $100", min: 0, max: 100 },
    { id: "100-500", label: "$100-500", min: 100, max: 500 },
    { id: "500-1000", label: "$500-1K", min: 500, max: 1000 },
    { id: "1000-5000", label: "$1K-5K", min: 1000, max: 5000 },
    { id: "over5000", label: "$5K+", min: 5000, max: 50000 },
  ];

  // Handle filter toggle
  const toggleFilter = (category, filterId) => {
    const newFilters = { ...activeFilters };
    const categoryFilters = newFilters[category];

    if (categoryFilters.includes(filterId)) {
      newFilters[category] = categoryFilters.filter((id) => id !== filterId);
    } else {
      newFilters[category] = [...categoryFilters, filterId];
    }

    setActiveFilters(newFilters);
    onFiltersChange?.(newFilters);
  };

  // Handle price range change
  const handlePriceRangeChange = (rangeId) => {
    const range = priceRanges.find((r) => r.id === rangeId);
    if (range) {
      const newFilters = {
        ...activeFilters,
        priceRange: [range.min, range.max],
      };
      setActiveFilters(newFilters);
      onFiltersChange?.(newFilters);
    }
  };

  // Clear all filters
  const clearAllFilters = () => {
    const clearedFilters = {
      genre: [],
      emotion: [],
      characterType: [],
      era: [],
      theme: [],
      priceRange: [0, 10000],
    };
    setActiveFilters(clearedFilters);
    onFiltersChange?.(clearedFilters);
  };

  // Get total active filter count
  const getActiveFilterCount = () => {
    return Object.values(activeFilters).reduce((count, filters) => {
      if (Array.isArray(filters)) {
        return count + filters.length;
      }
      return count;
    }, 0);
  };

  // Check if filter is active
  const isFilterActive = (category, filterId) => {
    return activeFilters[category]?.includes(filterId) || false;
  };

  return (
    <div className={`emoji-filter-panel ${className}`}>
      {/* Filter Header */}
      <div className="filter-panel__header">
        <button
          className="filter-panel__toggle"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          <span className="filter-panel__toggle-icon">🎛️</span>
          <span className="filter-panel__toggle-text">Add Filters</span>
          {getActiveFilterCount() > 0 && (
            <span className="filter-panel__count">
              {getActiveFilterCount()}
            </span>
          )}
          <span
            className={`filter-panel__arrow ${isExpanded ? "filter-panel__arrow--expanded" : ""}`}
          >
            ▼
          </span>
        </button>

        {getActiveFilterCount() > 0 && (
          <button className="filter-panel__clear" onClick={clearAllFilters}>
            Clear All
          </button>
        )}
      </div>

      {/* Filter Content */}
      <div
        className={`filter-panel__content ${isExpanded ? "filter-panel__content--expanded" : ""}`}
      >
        {/* Filter Categories */}
        {Object.entries(filterCategories).map(([categoryKey, category]) => (
          <div key={categoryKey} className="filter-category">
            <div className="filter-category__header">
              <span className="filter-category__emoji">{category.emoji}</span>
              <span className="filter-category__label">{category.label}</span>
            </div>

            <div className="filter-category__options">
              {category.options.map((option) => (
                <button
                  key={option.id}
                  className={`filter-pill ${isFilterActive(categoryKey, option.id) ? "filter-pill--active" : ""}`}
                  style={{
                    "--pill-color": option.color,
                    "--pill-color-alpha": `${option.color}20`,
                  }}
                  onClick={() => toggleFilter(categoryKey, option.id)}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
        ))}

        {/* Price Range */}
        <div className="filter-category">
          <div className="filter-category__header">
            <span className="filter-category__emoji">💵</span>
            <span className="filter-category__label">Price Range</span>
          </div>

          <div className="filter-category__options">
            {priceRanges.map((range) => (
              <button
                key={range.id}
                className={`filter-pill ${
                  activeFilters.priceRange[0] === range.min &&
                  activeFilters.priceRange[1] === range.max
                    ? "filter-pill--active"
                    : ""
                }`}
                style={{
                  "--pill-color": "#4CAF50",
                  "--pill-color-alpha": "#4CAF5020",
                }}
                onClick={() => handlePriceRangeChange(range.id)}
              >
                {range.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

EmojiFilterPanel.propTypes = {
  onFiltersChange: PropTypes.func,
  className: PropTypes.string,
};

export default EmojiFilterPanel;
