import React from 'react';
import PropTypes from 'prop-types';

const SearchIcon = ({ width, height, stroke }) => {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width={width} height={height} viewBox="0 0 24 24" fill="none">
            <path d="M16.747 6.187C19.663 9.103 19.663 13.831 16.747 16.747C13.831 19.663 9.103 19.663 6.187 16.747C3.271 13.831 3.271 9.103 6.187 6.187C9.103 3.271 13.831 3.271 16.747 6.187" stroke="#FFC03F" strokeWidth="1.15" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M20 20L16.75 16.75" stroke={stroke} strokeWidth="1.15" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    );
};

SearchIcon.propTypes = {
    width: PropTypes.number,
    height: PropTypes.number,
    stroke: PropTypes.string
};

SearchIcon.defaultProps = {
    width: 24,
    height: 24,
    stroke: "#FFC03F"
};

export default SearchIcon;