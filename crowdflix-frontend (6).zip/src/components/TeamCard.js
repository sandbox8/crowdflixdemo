import React from 'react';

import PropTypes from 'prop-types';

function TeamCard({ name, role, profilePic, profileLink }) {
    const openProfile = () => {
        console.log(profileLink);
        window.open(profileLink, '_blank', 'noopener,noreferrer');
    };

    return (
        <div className="col-6 col-md-4 col-lg-3 mb-4">
            <div className="team-card card h-100 shadow dark-bg white-text border-dark"
                onClick={openProfile}
            >
                <div style={{ position: 'relative', paddingBottom: '100%', overflow: 'hidden' }}>
                    <img
                        src={profilePic}
                        className="card-img-top"
                        alt='linkedin profile pic'
                        style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', objectFit: 'cover' }}
                    />
                </div>

                <div className="card-body text-center">
                    <h5 className="card-title">{name}</h5>

                    <p className="card-text grey-text">
                        {role}
                    </p>
                </div>
            </div>
        </div>
    );
}

TeamCard.propTypes = {
    name: PropTypes.string.isRequired,
    role: PropTypes.string.isRequired,
    profilePic: PropTypes.string,
    profileLink: PropTypes.string,
};

export default TeamCard;