import React, { useState, useRef } from "react";
import PropTypes from "prop-types";

const MomentCard = ({
  title,
  filmSeries,
  emotionTag,
  rarity = "common",
  thumbnailUrl,
  videoUrl,
  owned = false,
  price,
  onAction,
  size = "default",
  showStats = true,
  disabled = false,
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const videoRef = useRef(null);

  // Rarity configurations
  const rarityConfig = {
    immortal: {
      color: "#FFD700",
      glow: "0 0 20px rgba(255, 215, 0, 0.5)",
      label: "IMMORTAL",
    },
    legendary: {
      color: "#FF6B35",
      glow: "0 0 20px rgba(255, 107, 53, 0.5)",
      label: "LEGENDARY",
    },
    epic: {
      color: "#9D4EDD",
      glow: "0 0 20px rgba(157, 78, 221, 0.5)",
      label: "EPIC",
    },
    rare: {
      color: "#3F37C9",
      glow: "0 0 20px rgba(63, 55, 201, 0.5)",
      label: "RARE",
    },
    common: {
      color: "#6C757D",
      glow: "0 0 10px rgba(108, 117, 125, 0.3)",
      label: "COMMON",
    },
  };

  // Size configurations
  const sizeConfig = {
    small: {
      width: "180px",
      height: "240px",
      titleSize: "14px",
      filmSize: "10px",
    },
    default: {
      width: "220px",
      height: "290px",
      titleSize: "16px",
      filmSize: "12px",
    },
    large: {
      width: "280px",
      height: "370px",
      titleSize: "18px",
      filmSize: "14px",
    },
  };

  const currentRarity = rarityConfig[rarity] || rarityConfig.common;
  const currentSize = sizeConfig[size] || sizeConfig.default;

  // Handle card click (navigate to detail page)
  const handleCardClick = () => {
    if (!disabled) {
      onAction?.("view");
    }
  };

  // Handle button click (prevent card click propagation)
  const handleButtonClick = (e) => {
    e.stopPropagation();
    if (!disabled && owned) {
      onAction?.("view");
    } else if (!disabled) {
      onAction?.("buy");
    }
  };

  return (
    <article
      className={`moment-card moment-card--${size} moment-card--${rarity} ${disabled ? "moment-card--disabled" : ""}`}
      style={{
        width: currentSize.width,
        height: currentSize.height,
        boxShadow: disabled
          ? "0 2px 8px rgba(0, 0, 0, 0.2)"
          : isHovered
            ? currentRarity.glow
            : "0 4px 15px rgba(0, 0, 0, 0.3)",
        cursor: disabled ? "not-allowed" : "pointer",
      }}
      onMouseEnter={() => !disabled && setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleCardClick}
      title={
        disabled
          ? "Coming Soon! This moment will be available in the next drop."
          : "Click to view moment details"
      }
    >
      {/* Media Background */}
      <div className="moment-card__background">
        {/* Hover Video or Thumbnail */}
        {videoUrl && isHovered ? (
          <video
            ref={videoRef}
            src={videoUrl}
            className="moment-card__video"
            muted
            loop
            playsInline
            autoPlay
            preload="metadata"
          />
        ) : (
          <img
            src={thumbnailUrl}
            alt={title}
            className="moment-card__thumbnail"
            loading="lazy"
          />
        )}

        {/* Gradient Overlay */}
        <div className="moment-card__overlay" />
      </div>

      {/* Tier Badge */}
      <div
        className="moment-card__tier-badge"
        style={{
          backgroundColor: currentRarity.color,
          boxShadow: `0 0 10px ${currentRarity.color}40`,
        }}
      >
        {currentRarity.label}
      </div>

      {/* Emotion Tag */}
      {emotionTag && (
        <div className="moment-card__emotion-tag">{emotionTag}</div>
      )}

      {/* Content */}
      <div className="moment-card__content">
        <div className="moment-card__info">
          <h3
            className="moment-card__title"
            style={{ fontSize: currentSize.titleSize }}
          >
            {title}
          </h3>

          <p
            className="moment-card__film"
            style={{ fontSize: currentSize.filmSize }}
          >
            {filmSeries}
          </p>

          {/* Pricing Info */}
          {showStats && price && (
            <div className="moment-card__stats">
              <span className="moment-card__price">${price}</span>
            </div>
          )}
        </div>

        {/* Action Button - Only if not owned */}
        {!owned && (
          <button
            className={`moment-card__action ${disabled ? "moment-card__action--disabled" : ""}`}
            onClick={handleButtonClick}
            disabled={disabled}
          >
            {disabled ? "Coming Soon" : "Buy Now"}
          </button>
        )}
      </div>

      {/* Owned Indicator */}
      {owned && (
        <div className="moment-card__owned-indicator">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path
              d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"
              fill="currentColor"
            />
          </svg>
        </div>
      )}
    </article>
  );
};

MomentCard.propTypes = {
  title: PropTypes.string.isRequired,
  filmSeries: PropTypes.string.isRequired,
  emotionTag: PropTypes.string,
  rarity: PropTypes.oneOf(["immortal", "legendary", "epic", "rare", "common"]),
  thumbnailUrl: PropTypes.string.isRequired,
  videoUrl: PropTypes.string,
  owned: PropTypes.bool,
  price: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  onAction: PropTypes.func,
  size: PropTypes.oneOf(["small", "default", "large"]),
  showStats: PropTypes.bool,
  disabled: PropTypes.bool,
};

export default MomentCard;
