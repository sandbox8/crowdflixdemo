import React, { useState } from "react";
import PropTypes from "prop-types";

const StorylinesTab = ({ profile }) => {
  const [selectedStoryline, setSelectedStoryline] = useState(null);

  // Sample storylines/playlists data
  const storylines = [
    {
      id: "coming-of-age",
      title: "My Coming-of-Age Arc",
      description: "Moments that shaped who I am",
      coverImage:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F5a1c0dbf6e324f6a88e34e2230cae9b7",
      momentCount: 12,
      totalDuration: "24 min",
      isPublic: true,
      createdDate: "2024-01-20",
      moments: [
        {
          id: "coa-1",
          title: "Wilson!",
          filmSeries: "Cast Away",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F5a1c0dbf6e324f6a88e34e2230cae9b7",
        },
        {
          id: "coa-2",
          title: "To Infinity and Beyond",
          filmSeries: "Toy Story",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fbb61dbdb3aef4351b60d5e75b8509d26",
        },
      ],
    },
    {
      id: "villains-right",
      title: "Villains Who Got It Right",
      description: "Complex antagonists with valid points",
      coverImage:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F12d9e666c7e049b6a4d62f67ffdc2e27",
      momentCount: 8,
      totalDuration: "18 min",
      isPublic: true,
      createdDate: "2024-01-15",
      moments: [
        {
          id: "vwr-1",
          title: "Here's Johnny!",
          filmSeries: "The Shining",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F12d9e666c7e049b6a4d62f67ffdc2e27",
        },
      ],
    },
    {
      id: "heartbreak-cinema",
      title: "Heartbreak Cinema",
      description: "Moments that made me cry",
      coverImage:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F6ebffc23d7d44c2190d242565dd9fdb9",
      momentCount: 15,
      totalDuration: "32 min",
      isPublic: false,
      createdDate: "2024-01-10",
      moments: [
        {
          id: "hc-1",
          title: "Mufasa's Death",
          filmSeries: "The Lion King",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F6ebffc23d7d44c2190d242565dd9fdb9",
        },
        {
          id: "hc-2",
          title: "The Snap",
          filmSeries: "Avengers: Infinity War",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fa3cb973601e7471a9b4d0c02a2bafd37",
        },
      ],
    },
    {
      id: "perfect-cinematography",
      title: "Perfect Cinematography",
      description: "Visual poetry in motion",
      coverImage:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F0edbd217878f45f8b5d952459c17a199",
      momentCount: 6,
      totalDuration: "14 min",
      isPublic: true,
      createdDate: "2024-01-05",
      moments: [
        {
          id: "pc-1",
          title: "Dance Scene",
          filmSeries: "Pulp Fiction",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F0edbd217878f45f8b5d952459c17a199",
        },
      ],
    },
  ];

  const handleStorylineClick = (storyline) => {
    setSelectedStoryline(
      selectedStoryline?.id === storyline.id ? null : storyline,
    );
  };

  const handleCreateStoryline = () => {
    console.log("Create new storyline");
  };

  const handleShareStoryline = (storylineId) => {
    console.log("Share storyline:", storylineId);
  };

  return (
    <div className="storylines-tab">
      {/* Header */}
      <div className="storylines-tab__header">
        <div className="storylines-tab__title-section">
          <h3 className="storylines-tab__title">Custom Storylines</h3>
          <p className="storylines-tab__subtitle">
            Curated moment collections that tell your story
          </p>
        </div>
        <button
          className="storylines-tab__create-btn"
          onClick={handleCreateStoryline}
        >
          <span className="storylines-tab__create-icon">+</span>
          Create Storyline
        </button>
      </div>

      {/* Storylines Grid */}
      <div className="storylines-tab__grid">
        {storylines.map((storyline) => (
          <div key={storyline.id} className="storyline-card">
            {/* Cover Image */}
            <div
              className="storyline-card__cover"
              onClick={() => handleStorylineClick(storyline)}
            >
              <img
                src={storyline.coverImage}
                alt={storyline.title}
                className="storyline-card__cover-image"
              />

              {/* Overlay */}
              <div className="storyline-card__overlay">
                <div className="storyline-card__play-btn">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M8 5V19L19 12L8 5Z" fill="currentColor" />
                  </svg>
                </div>
              </div>

              {/* Privacy Badge */}
              <div
                className={`storyline-card__privacy ${!storyline.isPublic ? "storyline-card__privacy--private" : ""}`}
              >
                {storyline.isPublic ? "🌍" : "🔒"}
              </div>

              {/* Stats Badge */}
              <div className="storyline-card__stats">
                <span className="storyline-card__moment-count">
                  {storyline.momentCount}
                </span>
                <span className="storyline-card__duration">
                  {storyline.totalDuration}
                </span>
              </div>
            </div>

            {/* Card Content */}
            <div className="storyline-card__content">
              <h4 className="storyline-card__title">{storyline.title}</h4>
              <p className="storyline-card__description">
                {storyline.description}
              </p>

              <div className="storyline-card__meta">
                <span className="storyline-card__date">
                  Created {new Date(storyline.createdDate).toLocaleDateString()}
                </span>
                <button
                  className="storyline-card__share-btn"
                  onClick={() => handleShareStoryline(storyline.id)}
                  title="Share Storyline"
                >
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path
                      d="M6 10L10 6M10 6H7M10 6V9"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
              </div>
            </div>

            {/* Expanded Moments View */}
            {selectedStoryline?.id === storyline.id && (
              <div className="storyline-card__expanded">
                <div className="storyline-card__moments">
                  {storyline.moments.map((moment, index) => (
                    <div key={moment.id} className="storyline-moment">
                      <div className="storyline-moment__number">
                        {index + 1}
                      </div>
                      <img
                        src={moment.thumbnailUrl}
                        alt={moment.title}
                        className="storyline-moment__thumbnail"
                      />
                      <div className="storyline-moment__info">
                        <h5 className="storyline-moment__title">
                          {moment.title}
                        </h5>
                        <p className="storyline-moment__series">
                          {moment.filmSeries}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="storyline-card__actions">
                  <button className="storyline-card__action-btn storyline-card__action-btn--primary">
                    Watch Storyline
                  </button>
                  <button className="storyline-card__action-btn">Edit</button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Empty State for Create */}
      <div className="storylines-tab__empty-state">
        <div className="storylines-tab__empty-icon">📚</div>
        <h4 className="storylines-tab__empty-title">
          Create Your First Storyline
        </h4>
        <p className="storylines-tab__empty-description">
          Combine moments into custom playlists that tell your unique story
        </p>
        <button
          className="storylines-tab__empty-btn"
          onClick={handleCreateStoryline}
        >
          Get Started
        </button>
      </div>
    </div>
  );
};

StorylinesTab.propTypes = {
  profile: PropTypes.object.isRequired,
};

export default StorylinesTab;
