import React, { useState } from "react";
import PropTypes from "prop-types";
import MomentCard from "../MomentCard";

const VaultTab = ({ profile }) => {
  const [sortBy, setSortBy] = useState("recent");
  const [filterBy, setFilterBy] = useState("all");

  // Sample expanded vault data
  const vaultMoments = [
    ...profile.topMoments,
    // Additional moments for demonstration
    {
      id: "vault-7",
      title: "Portals Scene",
      filmSeries: "Avengers: Endgame",
      emotionTag: "⚡ Epic",
      rarity: "immortal",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F1af024ccf9ef4c6db837dc7c19bdbc56",
      price: "6,750",
      owned: true,
      dateAdded: "2024-01-15",
    },
    {
      id: "vault-8",
      title: "Final Girl",
      filmSeries: "Halloween",
      emotionTag: "😱 Survival",
      rarity: "epic",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F441b543af84344f08b1433ad2a83c8f4",
      price: "650",
      owned: true,
      dateAdded: "2024-01-10",
    },
    {
      id: "vault-9",
      title: "Spinning Top",
      filmSeries: "Inception",
      emotionTag: "🤔 Mystery",
      rarity: "legendary",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fac374cdb13ce470f9696083e7ae6690e",
      price: "1,100",
      owned: true,
      dateAdded: "2024-01-05",
    },
  ];

  const sortOptions = [
    { value: "recent", label: "Recently Added" },
    { value: "rarity", label: "Rarity" },
    { value: "value", label: "Value" },
  ];

  const filterOptions = [
    { value: "all", label: "All Moments" },
    { value: "immortal", label: "Immortal" },
    { value: "legendary", label: "Legendary" },
    { value: "epic", label: "Epic" },
    { value: "rare", label: "Rare" },
  ];

  // Simplified emotion filters - only top 5
  const emotionFilters = [
    { emoji: "💔", label: "Loss", count: 34 },
    { emoji: "💥", label: "Defiance", count: 28 },
    { emoji: "😱", label: "Terror", count: 19 },
    { emoji: "✨", label: "Cool", count: 45 },
    { emoji: "⚡", label: "Epic", count: 23 },
  ];

  const filteredMoments = vaultMoments.filter((moment) => {
    if (filterBy === "all") return true;
    return moment.rarity === filterBy;
  });

  const handleMomentAction = (action, momentId) => {
    console.log(`${action} action for moment:`, momentId);
  };

  return (
    <div className="vault-tab">
      {/* Vault Stats Header */}
      <div className="vault-tab__header">
        <div className="vault-tab__stats">
          <div className="vault-tab__stat">
            <span className="vault-tab__stat-value">
              {profile.stats.vaultedMoments}
            </span>
            <span className="vault-tab__stat-label">Total Moments</span>
          </div>
          <div className="vault-tab__stat">
            <span className="vault-tab__stat-value">
              {profile.stats.totalVaultValue}
            </span>
            <span className="vault-tab__stat-label">Total Value</span>
          </div>
          <div className="vault-tab__stat">
            <span className="vault-tab__stat-value">
              {profile.stats.mostCollectedEmotion}
            </span>
            <span className="vault-tab__stat-label">Top Emotion</span>
          </div>
        </div>
      </div>

      {/* Simplified Controls */}
      <div className="vault-tab__controls">
        <div className="vault-tab__filters">
          {/* Simplified Emotion Filters */}
          <div className="vault-tab__emotion-filters">
            {emotionFilters.slice(0, 4).map((emotion) => (
              <button
                key={emotion.label}
                className="vault-tab__emotion-filter"
                title={`${emotion.label} (${emotion.count})`}
              >
                <span className="vault-tab__emotion-emoji">
                  {emotion.emoji}
                </span>
                <span className="vault-tab__emotion-count">
                  {emotion.count}
                </span>
              </button>
            ))}
          </div>

          {/* Rarity Filter */}
          <select
            className="vault-tab__filter-select"
            value={filterBy}
            onChange={(e) => setFilterBy(e.target.value)}
          >
            {filterOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>

          {/* Sort Options */}
          <select
            className="vault-tab__sort-select"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
          >
            {sortOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Moments Grid */}
      <div className="vault-tab__grid">
        {filteredMoments.map((moment) => (
          <MomentCard
            key={moment.id}
            title={moment.title}
            filmSeries={moment.filmSeries}
            emotionTag={moment.emotionTag}
            rarity={moment.rarity}
            thumbnailUrl={moment.thumbnailUrl}
            videoUrl={moment.videoUrl}
            owned={moment.owned}
            price={moment.price}
            onAction={(action) => handleMomentAction(action, moment.id)}
            size="default"
            showStats={true}
          />
        ))}
      </div>

      {/* Load More */}
      <div className="vault-tab__load-more">
        <button className="vault-tab__load-more-btn">Load More Moments</button>
      </div>
    </div>
  );
};

VaultTab.propTypes = {
  profile: PropTypes.object.isRequired,
};

export default VaultTab;
