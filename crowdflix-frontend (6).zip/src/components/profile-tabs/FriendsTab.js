import React, { useState } from "react";
import PropTypes from "prop-types";

const FriendsTab = ({ profile }) => {
  const [activeView, setActiveView] = useState("friends");

  // Sample friends data
  const friends = [
    {
      id: "friend-1",
      username: "cinephile_sarah",
      displayName: "Sarah Chen",
      avatar:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F3d54cf3f605f4b52916b3942c55b4c49?format=webp&width=800",
      isVerified: true,
      mutualMoments: 12,
      followedDate: "2024-01-10",
      lastActive: "2 hours ago",
      topEmotion: "💔 Loss",
      sharedMoments: [
        {
          id: "shared-1",
          title: "The Snap",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fa3cb973601e7471a9b4d0c02a2bafd37",
        },
        {
          id: "shared-2",
          title: "Wilson!",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F5a1c0dbf6e324f6a88e34e2230cae9b7",
        },
      ],
    },
    {
      id: "friend-2",
      username: "horror_maven",
      displayName: "Alex Rodriguez",
      avatar:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fedf15ff331104f0ea4b7924e01d5ecf7?format=webp&width=800",
      isVerified: false,
      mutualMoments: 8,
      followedDate: "2024-01-05",
      lastActive: "1 day ago",
      topEmotion: "😱 Terror",
      sharedMoments: [
        {
          id: "shared-3",
          title: "Here's Johnny!",
          thumbnailUrl:
            "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F12d9e666c7e049b6a4d62f67ffdc2e27",
        },
      ],
    },
    {
      id: "friend-3",
      username: "anime_collector",
      displayName: "Yuki Tanaka",
      avatar:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F3d54cf3f605f4b52916b3942c55b4c49?format=webp&width=800",
      isVerified: true,
      mutualMoments: 15,
      followedDate: "2023-12-20",
      lastActive: "30 minutes ago",
      topEmotion: "✨ Wonder",
      sharedMoments: [],
    },
  ];

  const [expandedFriend, setExpandedFriend] = useState(null);

  const viewOptions = [
    { value: "friends", label: "Friends", count: friends.length },
    { value: "followers", label: "Followers", count: profile.followerCount },
    { value: "following", label: "Following", count: profile.followingCount },
  ];

  const handleViewProfile = (friendId) => {
    console.log("View profile:", friendId);
  };

  const handleViewSharedMoments = (friendId) => {
    setExpandedFriend(expandedFriend === friendId ? null : friendId);
  };

  const handleSendMessage = (friendId) => {
    console.log("Send message to:", friendId);
  };

  return (
    <div className="friends-tab">
      {/* Header */}
      <div className="friends-tab__header">
        <div className="friends-tab__view-selector">
          {viewOptions.map((option) => (
            <button
              key={option.value}
              className={`friends-tab__view-btn ${
                activeView === option.value
                  ? "friends-tab__view-btn--active"
                  : ""
              }`}
              onClick={() => setActiveView(option.value)}
            >
              <span className="friends-tab__view-label">{option.label}</span>
              <span className="friends-tab__view-count">
                {option.count > 999
                  ? `${(option.count / 1000).toFixed(1)}k`
                  : option.count}
              </span>
            </button>
          ))}
        </div>

        <div className="friends-tab__stats">
          <div className="friends-tab__stat">
            <span className="friends-tab__stat-value">
              {friends.reduce((acc, friend) => acc + friend.mutualMoments, 0)}
            </span>
            <span className="friends-tab__stat-label">Shared Moments</span>
          </div>
        </div>
      </div>

      {/* Friends List */}
      <div className="friends-tab__list">
        {friends.map((friend) => (
          <div key={friend.id} className="friend-card">
            {/* Main Friend Info */}
            <div className="friend-card__main">
              {/* Avatar */}
              <div
                className="friend-card__avatar-container"
                onClick={() => handleViewProfile(friend.id)}
              >
                <img
                  src={friend.avatar}
                  alt={`${friend.displayName} avatar`}
                  className="friend-card__avatar"
                />
                {friend.isVerified && (
                  <div className="friend-card__verified">✓</div>
                )}
              </div>

              {/* Friend Info */}
              <div className="friend-card__info">
                <div className="friend-card__names">
                  <h4 className="friend-card__display-name">
                    {friend.displayName}
                  </h4>
                  <p className="friend-card__username">@{friend.username}</p>
                </div>

                <div className="friend-card__meta">
                  <span className="friend-card__mutual-moments">
                    {friend.mutualMoments} shared moments
                  </span>
                  <span className="friend-card__top-emotion">
                    {friend.topEmotion}
                  </span>
                </div>

                <div className="friend-card__activity">
                  <span className="friend-card__last-active">
                    Active {friend.lastActive}
                  </span>
                  <span className="friend-card__followed-date">
                    Friends since{" "}
                    {new Date(friend.followedDate).toLocaleDateString()}
                  </span>
                </div>
              </div>

              {/* Actions */}
              <div className="friend-card__actions">
                <button
                  className="friend-card__action-btn friend-card__action-btn--primary"
                  onClick={() => handleViewProfile(friend.id)}
                >
                  View Profile
                </button>
                <button
                  className="friend-card__action-btn friend-card__action-btn--secondary"
                  onClick={() => handleSendMessage(friend.id)}
                >
                  Message
                </button>
                {friend.sharedMoments.length > 0 && (
                  <button
                    className="friend-card__action-btn friend-card__action-btn--tertiary"
                    onClick={() => handleViewSharedMoments(friend.id)}
                  >
                    Shared ({friend.sharedMoments.length})
                  </button>
                )}
              </div>
            </div>

            {/* Expanded Shared Moments */}
            {expandedFriend === friend.id &&
              friend.sharedMoments.length > 0 && (
                <div className="friend-card__shared-moments">
                  <h5 className="friend-card__shared-title">
                    You both collected these moments:
                  </h5>
                  <div className="friend-card__shared-grid">
                    {friend.sharedMoments.map((moment) => (
                      <div
                        key={moment.id}
                        className="friend-card__shared-moment"
                      >
                        <img
                          src={moment.thumbnailUrl}
                          alt={moment.title}
                          className="friend-card__shared-thumbnail"
                        />
                        <span className="friend-card__shared-moment-title">
                          {moment.title}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
          </div>
        ))}
      </div>

      {/* Empty State */}
      {friends.length === 0 && (
        <div className="friends-tab__empty">
          <div className="friends-tab__empty-icon">👥</div>
          <h4 className="friends-tab__empty-title">No Friends Yet</h4>
          <p className="friends-tab__empty-description">
            Connect with other collectors to share moments and discover new
            favorites
          </p>
          <button className="friends-tab__empty-btn">Find Friends</button>
        </div>
      )}
    </div>
  );
};

FriendsTab.propTypes = {
  profile: PropTypes.object.isRequired,
};

export default FriendsTab;
