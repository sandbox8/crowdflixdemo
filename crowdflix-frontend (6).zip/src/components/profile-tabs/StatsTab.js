import React from "react";
import PropTypes from "prop-types";

const StatsTab = ({ profile }) => {
  // Sample stats data
  const engagementStats = [
    {
      label: "Vaulted Moments",
      value: profile.stats.vaultedMoments,
      icon: "🏛️",
      change: "+12 this month",
    },
    {
      label: "Trades Completed",
      value: profile.stats.tradesCompleted,
      icon: "🔄",
      change: "+3 this month",
    },
    {
      label: "Remixes Created",
      value: profile.stats.remixesCreated,
      icon: "🎧",
      change: "+2 this month",
    },
    { label: "Storylines", value: 8, icon: "📚", change: "+1 this month" },
  ];

  const collectionStats = [
    {
      label: "Total Collection Value",
      value: profile.stats.totalVaultValue,
      icon: "💎",
      trend: "up",
    },
    {
      label: "Rarest Moment",
      value: "I Am Iron Man (Immortal)",
      icon: "⭐",
      trend: "stable",
    },
    {
      label: "Most Collected Emotion",
      value: profile.stats.mostCollectedEmotion,
      icon: "❤️",
      trend: "up",
    },
    { label: "Favorite Genre", value: "Drama", icon: "🎭", trend: "stable" },
  ];

  const activityStats = [
    { period: "Today", moments: 2, trades: 0, remixes: 1 },
    { period: "This Week", moments: 8, trades: 1, remixes: 2 },
    { period: "This Month", moments: 24, trades: 3, remixes: 5 },
    {
      period: "All Time",
      moments: profile.stats.vaultedMoments,
      trades: profile.stats.tradesCompleted,
      remixes: profile.stats.remixesCreated,
    },
  ];

  const emotionBreakdown = [
    { emotion: "💔 Loss", count: 34, percentage: 28 },
    { emotion: "💥 Defiance", count: 28, percentage: 23 },
    { emotion: "✨ Cool", count: 22, percentage: 18 },
    { emotion: "😱 Terror", count: 19, percentage: 16 },
    { emotion: "⚡ Epic", count: 18, percentage: 15 },
  ];

  const achievements = [
    {
      id: "vault-architect",
      name: "Vault Architect",
      description: "Collected 200+ moments",
      icon: "🧱",
      rarity: "legendary",
      unlockedDate: "2024-01-15",
    },
    {
      id: "remix-legend",
      name: "Remix Legend",
      description: "Created 10+ remixes",
      icon: "🎧",
      rarity: "epic",
      unlockedDate: "2024-01-10",
    },
    {
      id: "first-drop",
      name: "First Drop OG",
      description: "Joined during beta",
      icon: "🟡",
      rarity: "rare",
      unlockedDate: "2023-03-15",
    },
  ];

  const getTrendIcon = (trend) => {
    switch (trend) {
      case "up":
        return "📈";
      case "down":
        return "📉";
      default:
        return "➡️";
    }
  };

  const getRarityColor = (rarity) => {
    switch (rarity) {
      case "legendary":
        return "#A356FB";
      case "epic":
        return "#9D4EDD";
      case "rare":
        return "#FBC956";
      default:
        return "#42A2FD";
    }
  };

  return (
    <div className="stats-tab">
      {/* Overview Stats */}
      <div className="stats-tab__section">
        <h3 className="stats-tab__section-title">Engagement Overview</h3>
        <div className="stats-tab__stats-grid">
          {engagementStats.map((stat) => (
            <div key={stat.label} className="stat-card">
              <div className="stat-card__header">
                <span className="stat-card__icon">{stat.icon}</span>
                <span className="stat-card__change">{stat.change}</span>
              </div>
              <div className="stat-card__content">
                <span className="stat-card__value">{stat.value}</span>
                <span className="stat-card__label">{stat.label}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Collection Stats */}
      <div className="stats-tab__section">
        <h3 className="stats-tab__section-title">Collection Highlights</h3>
        <div className="stats-tab__collection-stats">
          {collectionStats.map((stat) => (
            <div key={stat.label} className="collection-stat">
              <div className="collection-stat__icon">{stat.icon}</div>
              <div className="collection-stat__content">
                <span className="collection-stat__label">{stat.label}</span>
                <span className="collection-stat__value">{stat.value}</span>
              </div>
              <div className="collection-stat__trend">
                {getTrendIcon(stat.trend)}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Activity Timeline */}
      <div className="stats-tab__section">
        <h3 className="stats-tab__section-title">Activity Timeline</h3>
        <div className="stats-tab__activity-table">
          <div className="activity-table__header">
            <span className="activity-table__col">Period</span>
            <span className="activity-table__col">Moments</span>
            <span className="activity-table__col">Trades</span>
            <span className="activity-table__col">Remixes</span>
          </div>
          {activityStats.map((activity) => (
            <div key={activity.period} className="activity-table__row">
              <span className="activity-table__col activity-table__period">
                {activity.period}
              </span>
              <span className="activity-table__col">{activity.moments}</span>
              <span className="activity-table__col">{activity.trades}</span>
              <span className="activity-table__col">{activity.remixes}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Emotion Breakdown */}
      <div className="stats-tab__section">
        <h3 className="stats-tab__section-title">Emotion Breakdown</h3>
        <div className="stats-tab__emotion-chart">
          {emotionBreakdown.map((emotion) => (
            <div key={emotion.emotion} className="emotion-stat">
              <div className="emotion-stat__header">
                <span className="emotion-stat__emoji">
                  {emotion.emotion.split(" ")[0]}
                </span>
                <span className="emotion-stat__label">
                  {emotion.emotion.split(" ")[1]}
                </span>
                <span className="emotion-stat__count">{emotion.count}</span>
              </div>
              <div className="emotion-stat__bar">
                <div
                  className="emotion-stat__fill"
                  style={{ width: `${emotion.percentage}%` }}
                />
              </div>
              <span className="emotion-stat__percentage">
                {emotion.percentage}%
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Achievements */}
      <div className="stats-tab__section">
        <h3 className="stats-tab__section-title">Recent Achievements</h3>
        <div className="stats-tab__achievements">
          {achievements.map((achievement) => (
            <div key={achievement.id} className="achievement-card">
              <div
                className="achievement-card__icon"
                style={{ color: getRarityColor(achievement.rarity) }}
              >
                {achievement.icon}
              </div>
              <div className="achievement-card__content">
                <h4 className="achievement-card__name">{achievement.name}</h4>
                <p className="achievement-card__description">
                  {achievement.description}
                </p>
                <span className="achievement-card__date">
                  Unlocked{" "}
                  {new Date(achievement.unlockedDate).toLocaleDateString()}
                </span>
              </div>
              <div
                className={`achievement-card__rarity achievement-card__rarity--${achievement.rarity}`}
                style={{ borderColor: getRarityColor(achievement.rarity) }}
              >
                {achievement.rarity}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Member Since */}
      <div className="stats-tab__section">
        <div className="stats-tab__member-since">
          <div className="stats-tab__member-since-icon">🎬</div>
          <div className="stats-tab__member-since-content">
            <h4 className="stats-tab__member-since-title">CrowdFlix Member</h4>
            <p className="stats-tab__member-since-date">
              Since {profile.stats.joinDate}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

StatsTab.propTypes = {
  profile: PropTypes.object.isRequired,
};

export default StatsTab;
