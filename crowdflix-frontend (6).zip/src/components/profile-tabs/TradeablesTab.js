import React, { useState } from "react";
import PropTypes from "prop-types";
import MomentCard from "../MomentCard";

const TradeablesTab = ({ profile }) => {
  const [sortBy, setSortBy] = useState("interest");

  // Sample tradeable moments
  const tradeableMoments = [
    {
      id: "trade-1",
      title: "Dance Scene",
      filmSeries: "Pulp Fiction",
      emotionTag: "✨ Cool",
      rarity: "rare",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F0edbd217878f45f8b5d952459c17a199",
      price: "2,300",
      owned: true,
      tradeable: true,
      interestedUsers: 15,
      listingDate: "2024-01-20",
    },
    {
      id: "trade-2",
      title: "Final Girl",
      filmSeries: "Halloween",
      emotionTag: "😱 Survival",
      rarity: "epic",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F441b543af84344f08b1433ad2a83c8f4",
      price: "650",
      owned: true,
      tradeable: true,
      interestedUsers: 8,
      listingDate: "2024-01-18",
    },
    {
      id: "trade-3",
      title: "Spinning Top",
      filmSeries: "Inception",
      emotionTag: "🤔 Mystery",
      rarity: "legendary",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fac374cdb13ce470f9696083e7ae6690e",
      price: "1,100",
      owned: true,
      tradeable: true,
      interestedUsers: 23,
      listingDate: "2024-01-15",
    },
  ];

  const sortOptions = [
    { value: "interest", label: "Most Interest" },
    { value: "recent", label: "Recently Listed" },
    { value: "price", label: "Price" },
    { value: "rarity", label: "Rarity" },
  ];

  const handleMakeOffer = (momentId) => {
    console.log("Make offer for moment:", momentId);
  };

  const handleRemoveListing = (momentId) => {
    console.log("Remove listing for moment:", momentId);
  };

  return (
    <div className="tradeables-tab">
      {/* Header */}
      <div className="tradeables-tab__header">
        <div className="tradeables-tab__stats">
          <div className="tradeables-tab__stat">
            <span className="tradeables-tab__stat-value">
              {tradeableMoments.length}
            </span>
            <span className="tradeables-tab__stat-label">Available</span>
          </div>
          <div className="tradeables-tab__stat">
            <span className="tradeables-tab__stat-value">
              {tradeableMoments.reduce(
                (acc, moment) => acc + moment.interestedUsers,
                0,
              )}
            </span>
            <span className="tradeables-tab__stat-label">Total Interest</span>
          </div>
          <div className="tradeables-tab__stat">
            <span className="tradeables-tab__stat-value">
              {profile.stats.tradesCompleted}
            </span>
            <span className="tradeables-tab__stat-label">Completed Trades</span>
          </div>
        </div>

        <select
          className="tradeables-tab__sort"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
        >
          {sortOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>

      {/* Tradeables Grid */}
      <div className="tradeables-tab__grid">
        {tradeableMoments.map((moment) => (
          <div key={moment.id} className="tradeable-moment">
            <MomentCard
              title={moment.title}
              filmSeries={moment.filmSeries}
              emotionTag={moment.emotionTag}
              rarity={moment.rarity}
              thumbnailUrl={moment.thumbnailUrl}
              owned={moment.owned}
              tradeable={moment.tradeable}
              price={moment.price}
              onAction={(action) =>
                action === "trade" ? handleMakeOffer(moment.id) : null
              }
              size="default"
              showStats={true}
            />

            {/* Interest Heat Indicator */}
            <div className="tradeable-moment__interest-heat">
              <div className="tradeable-moment__heat-icon">🔥</div>
              <span className="tradeable-moment__heat-count">
                {moment.interestedUsers} interested
              </span>
            </div>

            {/* Listing Actions */}
            <div className="tradeable-moment__actions">
              <button
                className="tradeable-moment__action-btn tradeable-moment__action-btn--primary"
                onClick={() => handleMakeOffer(moment.id)}
              >
                View Offers
              </button>
              <button
                className="tradeable-moment__action-btn tradeable-moment__action-btn--secondary"
                onClick={() => handleRemoveListing(moment.id)}
              >
                Remove Listing
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {tradeableMoments.length === 0 && (
        <div className="tradeables-tab__empty">
          <div className="tradeables-tab__empty-icon">🔄</div>
          <h4 className="tradeables-tab__empty-title">No Tradeable Moments</h4>
          <p className="tradeables-tab__empty-description">
            List moments from your vault to start trading with other collectors
          </p>
          <button className="tradeables-tab__empty-btn">
            Browse Your Vault
          </button>
        </div>
      )}
    </div>
  );
};

TradeablesTab.propTypes = {
  profile: PropTypes.object.isRequired,
};

export default TradeablesTab;
