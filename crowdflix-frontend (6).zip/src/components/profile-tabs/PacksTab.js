import React, { useState } from "react";
import PropTypes from "prop-types";

const PacksTab = ({ profile }) => {
  const [filterStatus, setFilterStatus] = useState("all");

  // Sample packs data
  const packs = [
    {
      id: "marvel-legends",
      title: "Marvel Legends Pack",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fcccaf5c58da14ed2b47b067a04844b25",
      status: "opened",
      openedDate: "2024-01-20",
      totalMoments: 12,
      collectedMoments: 12,
      completionPercent: 100,
      rarity: "legendary",
      seriesInfo: "Marvel Cinematic Universe",
    },
    {
      id: "horror-classics",
      title: "Horror Classics",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Ffbebd21e73894f4b9a279ffcbd94e53c",
      status: "opened",
      openedDate: "2024-01-15",
      totalMoments: 10,
      collectedMoments: 8,
      completionPercent: 80,
      rarity: "epic",
      seriesInfo: "Classic Horror Films",
    },
    {
      id: "starter-pack",
      title: "Starter Pack",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fe76b04022f0d48f5b95702af628645a6",
      status: "unopened",
      purchaseDate: "2024-01-25",
      totalMoments: 8,
      collectedMoments: 0,
      completionPercent: 0,
      rarity: "rare",
      seriesInfo: "Beginner Collection",
    },
    {
      id: "anime-vault",
      title: "Anime Vault",
      thumbnailUrl:
        "https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2Fcccaf5c58da14ed2b47b067a04844b25",
      status: "missing",
      totalMoments: 15,
      collectedMoments: 0,
      completionPercent: 0,
      rarity: "legendary",
      seriesInfo: "Anime Classics",
      releaseDate: "2024-02-01",
    },
  ];

  const filterOptions = [
    { value: "all", label: "All Packs" },
    { value: "opened", label: "Opened" },
    { value: "unopened", label: "Unopened" },
    { value: "missing", label: "Missing" },
  ];

  const filteredPacks = packs.filter((pack) => {
    if (filterStatus === "all") return true;
    return pack.status === filterStatus;
  });

  const handleOpenPack = (packId) => {
    console.log("Open pack:", packId);
  };

  const handleRewardReveal = (packId) => {
    console.log("Rewatch reveal for pack:", packId);
  };

  const handlePurchasePack = (packId) => {
    console.log("Purchase pack:", packId);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "opened":
        return "#4CAF50";
      case "unopened":
        return "#FF9800";
      case "missing":
        return "#9E9E9E";
      default:
        return "#2196F3";
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "opened":
        return "✅";
      case "unopened":
        return "📦";
      case "missing":
        return "❓";
      default:
        return "📋";
    }
  };

  const getRarityGradient = (rarity) => {
    switch (rarity) {
      case "legendary":
        return "linear-gradient(135deg, #A356FB 0%, #9D4EDD 100%)";
      case "epic":
        return "linear-gradient(135deg, #9D4EDD 0%, #7B2CBF 100%)";
      case "rare":
        return "linear-gradient(135deg, #FBC956 0%, #F4A460 100%)";
      default:
        return "linear-gradient(135deg, #42A2FD 0%, #1E90FF 100%)";
    }
  };

  return (
    <div className="packs-tab">
      {/* Header */}
      <div className="packs-tab__header">
        <div className="packs-tab__stats">
          <div className="packs-tab__stat">
            <span className="packs-tab__stat-value">
              {packs.filter((p) => p.status === "opened").length}
            </span>
            <span className="packs-tab__stat-label">Opened</span>
          </div>
          <div className="packs-tab__stat">
            <span className="packs-tab__stat-value">
              {packs.filter((p) => p.status === "unopened").length}
            </span>
            <span className="packs-tab__stat-label">Unopened</span>
          </div>
          <div className="packs-tab__stat">
            <span className="packs-tab__stat-value">
              {Math.round(
                packs
                  .filter((p) => p.status === "opened")
                  .reduce((acc, pack) => acc + pack.completionPercent, 0) /
                  packs.filter((p) => p.status === "opened").length || 0,
              )}
              %
            </span>
            <span className="packs-tab__stat-label">Avg. Completion</span>
          </div>
        </div>

        {/* Filter */}
        <select
          className="packs-tab__filter"
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
        >
          {filterOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>

      {/* Packs Grid */}
      <div className="packs-tab__grid">
        {filteredPacks.map((pack) => (
          <div
            key={pack.id}
            className={`pack-card-profile pack-card-profile--${pack.status}`}
          >
            {/* Pack Image */}
            <div className="pack-card-profile__image-container">
              <img
                src={pack.thumbnailUrl}
                alt={pack.title}
                className="pack-card-profile__image"
              />

              {/* Status Overlay */}
              <div
                className="pack-card-profile__status-overlay"
                style={{ backgroundColor: getStatusColor(pack.status) }}
              >
                <span className="pack-card-profile__status-icon">
                  {getStatusIcon(pack.status)}
                </span>
                <span className="pack-card-profile__status-text">
                  {pack.status.charAt(0).toUpperCase() + pack.status.slice(1)}
                </span>
              </div>

              {/* Rarity Border */}
              <div
                className="pack-card-profile__rarity-border"
                style={{ background: getRarityGradient(pack.rarity) }}
              />
            </div>

            {/* Pack Info */}
            <div className="pack-card-profile__content">
              <h4 className="pack-card-profile__title">{pack.title}</h4>
              <p className="pack-card-profile__series">{pack.seriesInfo}</p>

              {/* Progress Bar (for opened packs) */}
              {pack.status === "opened" && (
                <div className="pack-card-profile__progress">
                  <div className="pack-card-profile__progress-bar">
                    <div
                      className="pack-card-profile__progress-fill"
                      style={{ width: `${pack.completionPercent}%` }}
                    />
                  </div>
                  <span className="pack-card-profile__progress-text">
                    {pack.collectedMoments}/{pack.totalMoments} (
                    {pack.completionPercent}%)
                  </span>
                </div>
              )}

              {/* Moment Count (for unopened/missing) */}
              {(pack.status === "unopened" || pack.status === "missing") && (
                <div className="pack-card-profile__moment-count">
                  <span className="pack-card-profile__count-number">
                    {pack.totalMoments}
                  </span>
                  <span className="pack-card-profile__count-label">
                    Moments
                  </span>
                </div>
              )}

              {/* Date Info */}
              <div className="pack-card-profile__date">
                {pack.status === "opened" && (
                  <span>
                    Opened {new Date(pack.openedDate).toLocaleDateString()}
                  </span>
                )}
                {pack.status === "unopened" && (
                  <span>
                    Purchased {new Date(pack.purchaseDate).toLocaleDateString()}
                  </span>
                )}
                {pack.status === "missing" && (
                  <span>
                    Releases {new Date(pack.releaseDate).toLocaleDateString()}
                  </span>
                )}
              </div>

              {/* Action Button */}
              <div className="pack-card-profile__actions">
                {pack.status === "opened" && (
                  <button
                    className="pack-card-profile__action-btn pack-card-profile__action-btn--secondary"
                    onClick={() => handleRewardReveal(pack.id)}
                  >
                    <span className="pack-card-profile__action-icon">🎬</span>
                    Rewatch Reveal
                  </button>
                )}
                {pack.status === "unopened" && (
                  <button
                    className="pack-card-profile__action-btn pack-card-profile__action-btn--primary"
                    onClick={() => handleOpenPack(pack.id)}
                  >
                    <span className="pack-card-profile__action-icon">📦</span>
                    Open Pack
                  </button>
                )}
                {pack.status === "missing" && (
                  <button
                    className="pack-card-profile__action-btn pack-card-profile__action-btn--primary"
                    onClick={() => handlePurchasePack(pack.id)}
                  >
                    <span className="pack-card-profile__action-icon">🛒</span>
                    Get Pack
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredPacks.length === 0 && (
        <div className="packs-tab__empty">
          <div className="packs-tab__empty-icon">📦</div>
          <h4 className="packs-tab__empty-title">No {filterStatus} packs</h4>
          <p className="packs-tab__empty-description">
            {filterStatus === "all"
              ? "Start your collection by purchasing your first pack"
              : `No ${filterStatus} packs in your collection`}
          </p>
        </div>
      )}
    </div>
  );
};

PacksTab.propTypes = {
  profile: PropTypes.object.isRequired,
};

export default PacksTab;
