import React, { useState } from "react";
import PropTypes from "prop-types";

const ProfileHeader = ({ profile, isFollowing, onFollow }) => {
  const [showAllBadges, setShowAllBadges] = useState(false);
  const visibleBadges = showAllBadges
    ? profile.badges
    : profile.badges.slice(0, 3);

  const handleConnectLetterboxd = () => {
    // Handle Letterboxd connection
    console.log("Connect to Letterboxd");
  };

  const getRarityColor = (rarity) => {
    switch (rarity) {
      case "immortal":
        return "#FFD700";
      case "legendary":
        return "#A356FB";
      case "epic":
        return "#9D4EDD";
      case "rare":
        return "#FBC956";
      default:
        return "#42A2FD";
    }
  };

  return (
    <div className="profile-header">
      <div className="profile-header__container">
        {/* Main Profile Info */}
        <div className="profile-header__main">
          {/* Avatar */}
          <div className="profile-header__avatar-container">
            <img
              src={profile.avatar}
              alt={`${profile.displayName} avatar`}
              className="profile-header__avatar"
            />
            <div className="profile-header__avatar-border"></div>
          </div>

          {/* Identity Section */}
          <div className="profile-header__identity">
            {/* Handle + Display Name */}
            <div className="profile-header__names">
              <div className="profile-header__handle-row">
                <h1 className="profile-header__handle">@{profile.username}</h1>
                {profile.isVerified && (
                  <span className="profile-header__verified">✓</span>
                )}
              </div>
              <h2 className="profile-header__display-name">
                {profile.displayName}
              </h2>
            </div>

            {/* Badge Row */}
            <div className="profile-header__badges-section">
              <div
                className="profile-header__badges"
                onMouseEnter={() => setShowAllBadges(true)}
                onMouseLeave={() => setShowAllBadges(false)}
              >
                {visibleBadges.map((badge) => (
                  <div
                    key={badge.id}
                    className={`profile-header__badge profile-header__badge--${badge.rarity}`}
                    style={{ borderColor: getRarityColor(badge.rarity) }}
                    title={badge.name}
                  >
                    <span className="profile-header__badge-icon">
                      {badge.icon}
                    </span>
                    <span className="profile-header__badge-name">
                      {badge.name}
                    </span>
                  </div>
                ))}
                {!showAllBadges && profile.badges.length > 3 && (
                  <div className="profile-header__badge-more">
                    +{profile.badges.length - 3}
                  </div>
                )}
              </div>
            </div>

            {/* Tagline */}
            <p className="profile-header__tagline">
              &ldquo;{profile.tagline}&rdquo;
            </p>

            {/* Stats Row */}
            <div className="profile-header__stats">
              <div className="profile-header__stat">
                <span className="profile-header__stat-value">
                  {profile.followerCount.toLocaleString()}
                </span>
                <span className="profile-header__stat-label">Followers</span>
              </div>
              <div className="profile-header__stat">
                <span className="profile-header__stat-value">
                  {profile.followingCount.toLocaleString()}
                </span>
                <span className="profile-header__stat-label">Following</span>
              </div>
              <div className="profile-header__stat">
                <span className="profile-header__stat-value">
                  {profile.stats.vaultedMoments}
                </span>
                <span className="profile-header__stat-label">Moments</span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="profile-header__actions">
          {/* Connect Letterboxd Button */}
          {!profile.letterboxdConnected && (
            <button
              className="profile-header__letterboxd-btn"
              onClick={handleConnectLetterboxd}
            >
              <img
                src="https://cdn.builder.io/api/v1/image/assets%2F92b18821349144eaae5d92cdfc438e52%2F5c1ddf2ab1064069844eb0db29d70330?format=webp&width=800"
                alt="Letterboxd"
                className="profile-header__letterboxd-icon"
              />
              Connect Letterboxd
            </button>
          )}

          {/* Follow Button */}
          <button
            className={`profile-header__follow-btn ${isFollowing ? "profile-header__follow-btn--following" : ""}`}
            onClick={onFollow}
          >
            {isFollowing ? (
              <>
                <span>✓</span>
                Following
              </>
            ) : (
              <>
                <span>+</span>
                Follow
              </>
            )}
          </button>

          {/* Share Profile Button */}
          <button className="profile-header__share-btn" title="Share Profile">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <path
                d="M13 6.5L16 3.5L13 0.5M3 11.5L0 14.5L3 17.5M16 3.5H7C5.89543 3.5 5 4.39543 5 5.5V8.5M0 14.5H9C10.1046 14.5 11 13.6046 11 12.5V9.5"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

ProfileHeader.propTypes = {
  profile: PropTypes.object.isRequired,
  isFollowing: PropTypes.bool.isRequired,
  onFollow: PropTypes.func.isRequired,
};

export default ProfileHeader;
