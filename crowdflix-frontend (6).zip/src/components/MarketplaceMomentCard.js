import React, { useState } from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";

const MarketplaceMomentCard = ({
  momentName = "Moment Title",
  lowestAsk = "00.00",
  avgSale = "00.00",
  rarity = "Rarity Level",
  videoPreviewUrl = "",
  thumbnailUrl = "",
  momentId = "",
}) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="marketplace-moment-card"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Media container with hover video */}
      <Link
        to={momentId ? `/moment/${momentId}` : "#"}
        className="media-container"
      >
        {!isHovered || !videoPreviewUrl ? (
          <img
            src={thumbnailUrl}
            alt={momentName}
            className="moment-thumbnail"
          />
        ) : (
          <video
            src={videoPreviewUrl}
            autoPlay
            loop
            muted
            className="moment-video"
          />
        )}
      </Link>

      {/* Tier badge */}
      <div className="rarity-badge">{rarity}</div>

      {/* Content */}
      <div className="moment-content">
        {/* Title */}
        <h3 className="moment-title">{momentName}</h3>

        {/* Pricing info */}
        <div className="pricing-section">
          <div className="price-item">
            <span className="price-label">Lowest Ask</span>
            <span className="price-value">${lowestAsk}</span>
          </div>
          <div className="price-item">
            <span className="price-label">Avg Sale</span>
            <span className="price-value">${avgSale}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

MarketplaceMomentCard.propTypes = {
  momentName: PropTypes.string,
  lowestAsk: PropTypes.string,
  avgSale: PropTypes.string,
  rarity: PropTypes.string,
  videoPreviewUrl: PropTypes.string,
  thumbnailUrl: PropTypes.string,
  momentId: PropTypes.string,
};

export default MarketplaceMomentCard;
