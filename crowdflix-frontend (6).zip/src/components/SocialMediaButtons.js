import React, { useState } from "react";
import PropTypes from "prop-types";
import "../styles/components/_social-media-buttons.scss";

const SocialMediaButtons = ({
  size = "default",
  orientation = "horizontal",
  showLabels = false,
  variant = "navbar",
  className = "",
  onSocialClick,
}) => {
  const [hoveredPlatform, setHoveredPlatform] = useState(null);

  const socialPlatforms = [
    {
      name: "instagram",
      label: "Instagram",
      icon: "📸",
      url: "https://instagram.com/crowdflix",
      color: "rgba(225, 48, 108, 0.8)",
      hoverColor: "rgba(225, 48, 108, 1)",
      cinematicEffect: "film-grain",
    },
    {
      name: "twitter",
      label: "Twitter",
      icon: "🐦",
      url: "https://twitter.com/crowdflix",
      color: "rgba(29, 161, 242, 0.8)",
      hoverColor: "rgba(29, 161, 242, 1)",
      cinematicEffect: "lens-flare",
    },
    {
      name: "youtube",
      label: "YouTube",
      icon: "🎬",
      url: "https://youtube.com/crowdflix",
      color: "rgba(255, 0, 0, 0.8)",
      hoverColor: "rgba(255, 0, 0, 1)",
      cinematicEffect: "spotlight",
    },
    {
      name: "tiktok",
      label: "TikTok",
      icon: "🎵",
      url: "https://tiktok.com/@crowdflix",
      color: "rgba(255, 0, 80, 0.8)",
      hoverColor: "rgba(255, 0, 80, 1)",
      cinematicEffect: "neon-glow",
    },
    {
      name: "discord",
      label: "Discord",
      icon: "🎮",
      url: "https://discord.gg/crowdflix",
      color: "rgba(114, 137, 218, 0.8)",
      hoverColor: "rgba(114, 137, 218, 1)",
      cinematicEffect: "digital-glitch",
    },
  ];

  const handleSocialClick = (platform) => {
    if (onSocialClick) {
      onSocialClick(platform);
    } else {
      window.open(platform.url, "_blank", "noopener,noreferrer");
    }
  };

  const sizeClasses = {
    small: "social-buttons--small",
    default: "social-buttons--default",
    large: "social-buttons--large",
  };

  const variantClasses = {
    navbar: "social-buttons--navbar",
    footer: "social-buttons--footer",
    sidebar: "social-buttons--sidebar",
  };

  return (
    <div
      className={`social-media-buttons ${sizeClasses[size]} ${variantClasses[variant]} social-buttons--${orientation} ${className}`}
    >
      {showLabels && variant !== "navbar" && (
        <div className="social-buttons__header">
          <h3 className="social-buttons__title">Follow CrowdFlix</h3>
          <div className="social-buttons__subtitle">
            Join our cinematic community
          </div>
        </div>
      )}

      <div className="social-buttons__container">
        {socialPlatforms.map((platform) => (
          <button
            key={platform.name}
            className={`social-button social-button--${platform.name} ${hoveredPlatform === platform.name ? "social-button--hovered" : ""}`}
            onClick={() => handleSocialClick(platform)}
            onMouseEnter={() => setHoveredPlatform(platform.name)}
            onMouseLeave={() => setHoveredPlatform(null)}
            aria-label={`Follow CrowdFlix on ${platform.label}`}
            style={{
              "--platform-color": platform.color,
              "--platform-hover-color": platform.hoverColor,
            }}
          >
            <div className="social-button__content">
              <span className="social-button__icon">{platform.icon}</span>
              {showLabels && (
                <span className="social-button__label">{platform.label}</span>
              )}
            </div>

            {/* Cinematic effect overlays */}
            <div
              className={`social-button__effect social-button__effect--${platform.cinematicEffect}`}
            >
              {platform.cinematicEffect === "film-grain" && (
                <div className="effect-film-grain"></div>
              )}
              {platform.cinematicEffect === "lens-flare" && (
                <div className="effect-lens-flare"></div>
              )}
              {platform.cinematicEffect === "spotlight" && (
                <div className="effect-spotlight"></div>
              )}
              {platform.cinematicEffect === "neon-glow" && (
                <div className="effect-neon-glow"></div>
              )}
              {platform.cinematicEffect === "digital-glitch" && (
                <div className="effect-digital-glitch"></div>
              )}
            </div>
          </button>
        ))}
      </div>

      {/* Ambient cinematic background */}
      <div className="social-buttons__ambient">
        <div className="ambient-particles"></div>
        <div className="ambient-glow"></div>
      </div>
    </div>
  );
};

SocialMediaButtons.propTypes = {
  size: PropTypes.oneOf(["small", "default", "large"]),
  orientation: PropTypes.oneOf(["horizontal", "vertical"]),
  showLabels: PropTypes.bool,
  variant: PropTypes.oneOf(["navbar", "footer", "sidebar"]),
  className: PropTypes.string,
  onSocialClick: PropTypes.func,
};

export default SocialMediaButtons;
