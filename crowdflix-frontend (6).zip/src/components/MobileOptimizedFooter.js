import React, { useState } from "react";
import { Link } from "react-router-dom";
import CrowdflixLogo from "./CrowdflixLogo";

const MobileOptimizedFooter = () => {
  const [email, setEmail] = useState("");

  const handleEmailSubmit = (e) => {
    e.preventDefault();
    // TODO: Implement email subscription
    console.log("Email submitted:", email);
    setEmail("");
  };

  return (
    <footer className="mobile-optimized-footer">
      <div className="footer-container">
        {/* Logo */}
        <div className="footer-logo">
          <Link to="/">
            <CrowdflixLogo height={40} width={40} fill="white" />
          </Link>
        </div>

        {/* Navigation Buttons */}
        <div className="footer-nav-buttons">
          <Link to="/" className="footer-nav-btn explore-btn">
            Explore
          </Link>
          <Link to="/marketplace" className="footer-nav-btn trade-btn">
            Trade
          </Link>
        </div>

        {/* Email Signup Form */}
        <form className="footer-form" onSubmit={handleEmailSubmit}>
          <div className="email-input-container">
            <input
              type="email"
              className="email-input"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="join-btn">
            Join our community
          </button>
        </form>

        {/* Links */}
        <div className="footer-links">
          <Link to="/terms" className="footer-link">
            Terms
          </Link>
          <Link to="/privacy-policy" className="footer-link">
            Privacy
          </Link>
          <Link to="/cookie-policy" className="footer-link">
            Cookies
          </Link>
          <Link to="/about" className="footer-link">
            About
          </Link>
          <a
            href="#"
            className="footer-link"
            onClick={(e) => {
              e.preventDefault();
              // TODO: Implement FAQ functionality
            }}
          >
            FAQ
          </a>
          <a
            href="#"
            className="footer-link"
            onClick={(e) => {
              e.preventDefault();
              // TODO: Implement Letterboxd sharing
            }}
          >
            Share with Letterboxd
          </a>
        </div>

        {/* Social Media Icons */}
        <div className="footer-social">
          <a
            href="#"
            className="social-link"
            aria-label="Instagram"
            onClick={(e) => {
              e.preventDefault();
              // TODO: Add Instagram link
            }}
          >
            <svg width="35" height="35" viewBox="0 0 35 35" fill="none">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M10.9317 4.375H24.0698C27.6894 4.375 30.625 7.30917 30.625 10.9317V24.0698C30.625 27.6894 27.6908 30.625 24.0683 30.625H10.9317C7.31062 30.625 4.375 27.6908 4.375 24.0683V10.9317C4.375 7.31062 7.30917 4.375 10.9317 4.375V4.375Z"
                stroke="#85CBFF"
                strokeWidth="1.15"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M24.7167 9.78971C24.4455 9.79117 24.2253 10.0114 24.2253 10.2826C24.2253 10.5539 24.4469 10.7741 24.7182 10.7741C24.9894 10.7741 25.2096 10.5539 25.2096 10.2826C25.2111 10.0099 24.9894 9.78971 24.7167 9.78971"
                stroke="#85CBFF"
                strokeWidth="1.15"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M21.2123 13.7877C23.2626 15.8379 23.2626 19.1621 21.2123 21.2123C19.1621 23.2626 15.8379 23.2626 13.7877 21.2123C11.7374 19.1621 11.7374 15.8379 13.7877 13.7877C15.8379 11.7374 19.1621 11.7374 21.2123 13.7877"
                stroke="#85CBFF"
                strokeWidth="1.15"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </a>

          <a
            href="#"
            className="social-link"
            aria-label="Facebook"
            onClick={(e) => {
              e.preventDefault();
              // TODO: Add Facebook link
            }}
          >
            <svg width="35" height="35" viewBox="0 0 35 35" fill="none">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M10.9375 4.375H24.0683C27.6894 4.375 30.625 7.31062 30.625 10.9317V24.0698C30.625 27.6894 27.6894 30.625 24.0683 30.625H10.9317C7.31062 30.625 4.375 27.6894 4.375 24.0683V10.9375C4.375 7.31354 7.31354 4.375 10.9375 4.375V4.375Z"
                stroke="#85CBFF"
                strokeWidth="1.15"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M16.1875 18.8124H24.0625"
                stroke="#85CBFF"
                strokeWidth="1.15"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M24.0625 12.2498H22.6844C20.5465 12.2498 18.8125 13.9837 18.8125 16.1216V17.4998V30.6248"
                stroke="#85CBFF"
                strokeWidth="1.15"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </a>

          <a
            href="#"
            className="social-link"
            aria-label="Twitter"
            onClick={(e) => {
              e.preventDefault();
              // TODO: Add Twitter link
            }}
          >
            <svg width="35" height="35" viewBox="0 0 35 35" fill="none">
              <path
                d="M12.0957 4.9502L29.5254 30.0498H23.2656L5.48633 4.9502H12.0957Z"
                stroke="#85CBFF"
                strokeWidth="1.15"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M6.19922 29.8958L15.3138 19.6875"
                stroke="#85CBFF"
                strokeWidth="1.15"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M28.0716 5.10449L18.957 15.3128"
                stroke="#85CBFF"
                strokeWidth="1.15"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </a>
        </div>

        {/* Copyright */}
        <div className="footer-copyright">© 2024 CrowdFlix</div>
      </div>
    </footer>
  );
};

export default MobileOptimizedFooter;
