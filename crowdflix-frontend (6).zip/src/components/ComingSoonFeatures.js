import React, { useState } from "react";
import PropTypes from "prop-types";

const ComingSoonFeatures = ({ className = "" }) => {
  const [hoveredCard, setHoveredCard] = useState(null);
  const [showComingSoon, setShowComingSoon] = useState(false);
  const [comingSoonFeature, setComingSoonFeature] = useState("");

  const features = [
    {
      id: "challenges",
      title: "Challenges",
      description:
        "Challenges offer opportunities to unlock exclusive movie moments, packs, or rewards based on your collection of iconic scenes, character journeys, or behind-the-scenes moments.",
      liveCount: 15,
      buttonText: "Earn Rewards",
      bgGradient: "linear-gradient(180deg, #E9AE4B -96.68%, #784815 95.2%)",
      image:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/ab246851eef6c667cab36fef01b86a632d4091a3?width=1316",
      overlayImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/3bb82580a2373499534c46de2cfbbccdcde7fd4c?width=530",
      nbaTopShotStyle: "challenges",
    },
    {
      id: "trade-leaderboards",
      title: "Trade-Ins and Leaderboards",
      description:
        "Climb the ranks and compete with collectors worldwide. Trade moments strategically and see how you stack up against the community's top performers.",
      liveCount: 3,
      buttonText: "Climb & Compete",
      bgGradient: "linear-gradient(180deg, #7D299B -74.72%, #1B54C3 102.77%)",
      image:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/2a041e04858230482ad3ebd5006c61c2321aef2d?width=650",
      overlayImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/ad33659c33381eac40061641b81f19d65a13ad9f?width=597",
      nbaTopShotStyle: "leaderboards",
    },
    {
      id: "box-office-battles",
      title: "Box Office Battles",
      description:
        "A new and engaging way to experience upcoming movie releases, predict box office performance, play with your movie moments, and get rewarded as you follow the excitement in real-time.",
      liveCount: 2,
      buttonText: "Play Now",
      bgGradient: "linear-gradient(180deg, #ED712F -29.52%, #A0170A 95.2%)",
      image:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/cb55b2866010eddcd23c0deb63943d192847f17f?width=704",
      overlayImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/824a1dbd487bc0c9c159a974dc1a0e379b6390e6?width=980",
      nbaTopShotStyle: "fastbreak",
    },
  ];

  const handleComingSoonClick = (featureTitle) => {
    setComingSoonFeature(featureTitle);
    setShowComingSoon(true);
  };

  const closeComingSoon = () => {
    setShowComingSoon(false);
    setComingSoonFeature("");
  };

  return (
    <div className={`coming-soon-features ${className}`}>
      <div className="coming-soon-features__container">
        <div className="coming-soon-features__header">
          <h2 className="coming-soon-features__title">
            Coming Soon: The Future of CrowdFlix
          </h2>
          <p className="coming-soon-features__subtitle">
            Exciting new features are on the horizon. Get ready to challenge,
            compete, and experience movies like never before.
          </p>
        </div>

        <div className="coming-soon-features__grid">
          {features.map((feature) => (
            <div
              key={feature.id}
              className={`feature-card feature-card--${feature.nbaTopShotStyle} ${hoveredCard === feature.id ? "feature-card--hovered" : ""}`}
              onMouseEnter={() => setHoveredCard(feature.id)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              {/* NBA Top Shot Border Glow Effects */}
              <div className="feature-card__glow-border"></div>
              <div className="feature-card__premium-border"></div>

              {/* Main Image */}
              <div className="feature-card__image-container">
                <img
                  src={feature.image}
                  alt={feature.title}
                  className="feature-card__main-image"
                />

                {/* Overlay Effect Image */}
                <img
                  src={feature.overlayImage}
                  alt=""
                  className="feature-card__overlay-image"
                />

                {/* NBA Top Shot Holographic Overlay */}
                <div className="feature-card__holographic-overlay"></div>
              </div>

              {/* Card Background */}
              <div
                className="feature-card__content"
                style={{ background: feature.bgGradient }}
              >
                {/* Live Badge with NBA Top Shot styling */}
                <div className="feature-card__live-badge">
                  <div className="feature-card__live-glow"></div>
                  <span className="feature-card__live-count">
                    {feature.liveCount}
                  </span>
                  <span className="feature-card__live-text">LIVE</span>
                </div>

                {/* Text Content */}
                <div className="feature-card__text">
                  <h3 className="feature-card__title">{feature.title}</h3>
                  <p className="feature-card__description">
                    {feature.description}
                  </p>
                </div>

                {/* NBA Top Shot Action Button */}
                <div className="feature-card__action-link">
                  <button
                    className="feature-card__button"
                    onClick={() => handleComingSoonClick(feature.title)}
                  >
                    <span className="feature-card__button-text">
                      {feature.buttonText}
                    </span>
                    <div className="feature-card__button-glow"></div>
                  </button>
                </div>
              </div>

              {/* Enhanced Border Effect */}
              <div className="feature-card__border"></div>

              {/* NBA Top Shot Particles for premium cards */}
              {(feature.nbaTopShotStyle === "leaderboards" ||
                feature.nbaTopShotStyle === "fastbreak") && (
                <div className="feature-card__particles">
                  {Array.from({ length: 8 }, (_, i) => (
                    <div
                      key={i}
                      className={`feature-card__particle feature-card__particle--${i + 1}`}
                    ></div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Coming Soon Modal */}
      {showComingSoon && (
        <div className="coming-soon-modal" onClick={closeComingSoon}>
          <div
            className="coming-soon-modal__content"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="coming-soon-modal__header">
              <h3 className="coming-soon-modal__title">Coming Soon!</h3>
              <button
                className="coming-soon-modal__close"
                onClick={closeComingSoon}
                aria-label="Close modal"
              >
                ×
              </button>
            </div>
            <div className="coming-soon-modal__body">
              <div className="coming-soon-modal__icon">🎬</div>
              <p className="coming-soon-modal__message">
                <strong>{comingSoonFeature}</strong> is currently in development
                and will be available soon!
              </p>
              <p className="coming-soon-modal__submessage">
                Stay tuned for exciting updates and be the first to experience
                this new feature.
              </p>
            </div>
            <div className="coming-soon-modal__footer">
              <button
                className="coming-soon-modal__button"
                onClick={closeComingSoon}
              >
                Got it!
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

ComingSoonFeatures.propTypes = {
  className: PropTypes.string,
};

export default ComingSoonFeatures;
