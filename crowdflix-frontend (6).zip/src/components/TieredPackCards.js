import React from "react";
import PropTypes from "prop-types";

const TieredPackCards = ({ className = "" }) => {
  const packCards = [
    {
      id: "cyberpunk",
      title: "Cyberpunk",
      rarity: "rare",
      currentBid: "178.91",
      endTime: "01 : 12 : 14",
      mainImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/2151256dbf0c3b099d8e46c3806112a93fe6497e?width=694",
      frameImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/6543e3c1163c02703d04d37c8cd6aeffabd88258?width=588",
      particles:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/d52dd7d1c44571692dfb373766f6daacf856079d?width=656",
      rarityGradient: "linear-gradient(159deg, #FBC956 -9.7%, #773B0A 85.96%)",
      rarityColor: "#F0DB8D",
    },
    {
      id: "mummy",
      title: "Mummy",
      subtitle: "Curse of the Pharaoh",
      rarity: "legendary",
      currentBid: "178.91",
      endTime: "01 : 12 : 14",
      mainImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/be1be9f4ae34f0ca165c4c11d1f7678d4eaa6951?width=1484",
      frameImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/ee6a097b6ebd2d238022a9ffd340c8bf7f8f62c2?width=588",
      elements:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/af1364a95bc664ffb99ca690093566f1b3841c7c?width=450",
      characterImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/93880aaf62538c9f48fd4f27e07389bbd4c2d2fa?width=584",
      rarityGradient:
        "linear-gradient(168deg, #A356FB -40.61%, #D0000C 91.04%)",
      rarityColor: "#FAC4FF",
    },
    {
      id: "forged-stone",
      title: "Forged in Stone",
      subtitle: "The Last Dwarven Stronghold",
      rarity: "rare",
      currentBid: "178.91",
      endTime: "01 : 12 : 14",
      mainImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/49affc488e31365f6f2c45cf24bd6bed6440374e?width=752",
      frameImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/6543e3c1163c02703d04d37c8cd6aeffabd88258?width=588",
      particles:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/fc0eae58b93b6c07935b761492042115ff9b7361?width=530",
      characterImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/440acb91350e0f2bb821ab85669049aa64ab8d55?width=474",
      rarityGradient: "linear-gradient(159deg, #FBC956 -9.7%, #773B0A 85.96%)",
      rarityColor: "#F0DB8D",
    },
    {
      id: "lost-city",
      title: "The Lost City of Pharaohs",
      rarity: "ultimate",
      currentBid: "178.91",
      endTime: "01 : 12 : 14",
      mainImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/6ab98dcd7685f2e1e4bb96c2e2fedbd51dac5f72?width=1404",
      frameImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/b7c5a2819aa80052ff5564ad878d3da26afdee42?width=588",
      particles:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/b0ba8873cb066ef7d85727a76b0a7b3e053d3d47?width=530",
      characterImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/40f7fbd71e52444006f54fc18bb6a90afbd85bc4?width=421",
      rarityGradient: "linear-gradient(159deg, #FFB60E -9.7%, #D12600 85.96%)",
      rarityColor: "#FFDEB3",
    },
    {
      id: "synthetic-skies",
      title: "Synthetic Skies",
      rarity: "ultimate",
      currentBid: "178.91",
      endTime: "01 : 12 : 14",
      mainImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/4173785324c6853d7423218e28e4932e1fc28a2e?width=1310",
      frameImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/b7c5a2819aa80052ff5564ad878d3da26afdee42?width=588",
      characterImage:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/3c52531ebfe3a9ad2ef8b09e85d2dc8e77eadc4c?width=714",
      rarityGradient: "linear-gradient(159deg, #FFB60E -9.7%, #D12600 85.96%)",
      rarityColor: "#FFDEB3",
    },
  ];

  const getRarityDisplayName = (rarity) => {
    switch (rarity) {
      case "rare":
        return "Rare";
      case "legendary":
        return "Legendary";
      case "ultimate":
        return "Ultimate";
      default:
        return rarity;
    }
  };

  return (
    <div className={`tiered-pack-cards ${className}`}>
      <div className="tiered-pack-cards__container">
        <div className="tiered-pack-cards__header">
          <h2 className="tiered-pack-cards__title">Tiered Pack Collection</h2>
          <p className="tiered-pack-cards__subtitle">
            Discover rare, legendary, and ultimate packs with exclusive movie
            moments and characters
          </p>
        </div>

        <div className="tiered-pack-cards__carousel">
          {packCards.map((pack) => (
            <div
              key={pack.id}
              className={`pack-card pack-card--${pack.rarity}`}
            >
              {/* Background Card */}
              <div className="pack-card__background"></div>

              {/* Main Frame */}
              <div className="pack-card__frame">
                <img
                  src={pack.frameImage}
                  alt=""
                  className="pack-card__frame-img"
                />
              </div>

              {/* Character/Main Image */}
              <div className="pack-card__main-content">
                {pack.characterImage && (
                  <img
                    src={pack.characterImage}
                    alt={pack.title}
                    className="pack-card__character"
                  />
                )}

                {pack.mainImage && (
                  <img
                    src={pack.mainImage}
                    alt={pack.title}
                    className="pack-card__main-image"
                  />
                )}
              </div>

              {/* Particles/Effects */}
              {pack.particles && (
                <img
                  src={pack.particles}
                  alt=""
                  className="pack-card__particles"
                />
              )}

              {/* Elements for specific cards */}
              {pack.elements && (
                <img
                  src={pack.elements}
                  alt=""
                  className="pack-card__elements"
                />
              )}

              {/* Rarity Label */}
              <div
                className="pack-card__rarity-label"
                style={{ background: pack.rarityGradient }}
              >
                <span style={{ color: pack.rarityColor }}>
                  {getRarityDisplayName(pack.rarity)}
                </span>
              </div>

              {/* Title Section */}
              <div className="pack-card__title-section">
                <h3 className="pack-card__title">{pack.title}</h3>
                {pack.subtitle && (
                  <p className="pack-card__subtitle">{pack.subtitle}</p>
                )}
              </div>

              {/* Bottom Info */}
              <div className="pack-card__bottom-info">
                <div className="pack-card__bid-info">
                  <span className="pack-card__bid-label">Current Bid</span>
                  <span className="pack-card__bid-amount">
                    ${pack.currentBid.split(".")[0]}
                    <span className="pack-card__bid-cents">
                      .{pack.currentBid.split(".")[1]}
                    </span>
                  </span>
                </div>
                <div className="pack-card__time-info">
                  <span className="pack-card__time-label">End in</span>
                  <span className="pack-card__time-amount">{pack.endTime}</span>
                </div>
              </div>

              {/* Border Effect */}
              <div className="pack-card__border"></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

TieredPackCards.propTypes = {
  className: PropTypes.string,
};

export default TieredPackCards;
