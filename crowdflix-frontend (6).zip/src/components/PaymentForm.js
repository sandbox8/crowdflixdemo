import React, { useState } from "react";
import PropTypes from "prop-types";

const PaymentForm = ({ onSubmit, total, isLoading }) => {
  const [formData, setFormData] = useState({
    cardNumber: "",
    expiryDate: "",
    cvv: "",
    saveCard: false,
  });

  const [errors, setErrors] = useState({});

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));

    // Clear error when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({
        ...prev,
        [field]: "",
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.cardNumber.trim()) {
      newErrors.cardNumber = "Card number is required";
    } else if (formData.cardNumber.replace(/\s/g, "").length < 16) {
      newErrors.cardNumber = "Invalid card number";
    }

    if (!formData.expiryDate.trim()) {
      newErrors.expiryDate = "Expiry date is required";
    } else if (!/^\d{2}\/\d{2}$/.test(formData.expiryDate)) {
      newErrors.expiryDate = "Invalid expiry date format";
    }

    if (!formData.cvv.trim()) {
      newErrors.cvv = "CVV is required";
    } else if (formData.cvv.length < 3) {
      newErrors.cvv = "Invalid CVV";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (validateForm()) {
      onSubmit(formData);
    }
  };

  const formatCardNumber = (value) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || "";
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length) {
      return parts.join(" ");
    } else {
      return v;
    }
  };

  const formatExpiryDate = (value) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    if (v.length >= 2) {
      return v.substring(0, 2) + "/" + v.substring(2, 4);
    }
    return v;
  };

  return (
    <form className="payment-form" onSubmit={handleSubmit}>
      <div className="form-field">
        <label className="field-label" htmlFor="cardNumber">
          Card number
        </label>
        <input
          id="cardNumber"
          type="text"
          placeholder="Enter card number"
          value={formData.cardNumber}
          onChange={(e) =>
            handleInputChange("cardNumber", formatCardNumber(e.target.value))
          }
          maxLength="19"
          className={errors.cardNumber ? "error" : ""}
        />
        {errors.cardNumber && (
          <span className="error-message">{errors.cardNumber}</span>
        )}
      </div>

      <div className="form-row">
        <div className="form-field">
          <label className="field-label" htmlFor="expiryDate">
            Expiration Date
          </label>
          <input
            id="expiryDate"
            type="text"
            placeholder="MM/YY"
            value={formData.expiryDate}
            onChange={(e) =>
              handleInputChange("expiryDate", formatExpiryDate(e.target.value))
            }
            maxLength="5"
            className={errors.expiryDate ? "error" : ""}
          />
          {errors.expiryDate && (
            <span className="error-message">{errors.expiryDate}</span>
          )}
        </div>

        <div className="form-field">
          <label className="field-label" htmlFor="cvv">
            CVV
          </label>
          <input
            id="cvv"
            type="text"
            placeholder="Enter CVV"
            value={formData.cvv}
            onChange={(e) =>
              handleInputChange("cvv", e.target.value.replace(/[^0-9]/g, ""))
            }
            maxLength="4"
            className={errors.cvv ? "error" : ""}
          />
          {errors.cvv && <span className="error-message">{errors.cvv}</span>}
        </div>
      </div>

      <div className="save-card-checkbox">
        <input
          id="saveCard"
          type="checkbox"
          checked={formData.saveCard}
          onChange={(e) => handleInputChange("saveCard", e.target.checked)}
        />
        <label htmlFor="saveCard">Save card details</label>
      </div>

      <button type="submit" className="pay-button" disabled={isLoading}>
        {isLoading ? (
          <div className="loading-spinner" />
        ) : (
          `Pay $${total.toFixed(2)}`
        )}
      </button>
    </form>
  );
};

PaymentForm.propTypes = {
  onSubmit: PropTypes.func.isRequired,
  total: PropTypes.number.isRequired,
  isLoading: PropTypes.bool,
};

PaymentForm.defaultProps = {
  isLoading: false,
};

export default PaymentForm;
