import React from "react";
import PropTypes from "prop-types";

const MomentPriceSection = ({
  lowestAsk = "$13.00",
  currency = "USD",
  avgSale = "$14.00 USD",
  forSale = "50",
  onShare = () => console.log("Share clicked"),
  onPurchase = () => console.log("Purchase clicked"),
  isLoading = false,
}) => {
  const ShareIcon = () => (
    <svg
      width="73"
      height="24"
      viewBox="0 0 73 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <text
        fill="white"
        xmlSpace="preserve"
        style={{ whiteSpace: "pre" }}
        fontFamily="Outfit"
        fontSize="14"
        fontWeight="500"
        letterSpacing="-0.01em"
      >
        <tspan x="0" y="17.18">
          SHARE
        </tspan>
      </text>
      <g opacity="0.6">
        <path
          d="M56 7V6C56 4.34315 57.3431 3 59 3H67C68.6569 3 70 4.34315 70 6V14C70 15.6569 68.6569 17 67 17H66"
          stroke="white"
          strokeWidth="1.15"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M52 10.1111V17.8889C52 19.6071 53.3929 21 55.1111 21H62.8889C64.6071 21 66 19.6071 66 17.8889V10.1111C66 8.39289 64.6071 7 62.8889 7H55.1111C53.3929 7 52 8.39289 52 10.1111Z"
          stroke="white"
          strokeWidth="1.15"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M57 16L61 12"
          stroke="white"
          strokeWidth="1.15"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M57 12H61V16"
          stroke="white"
          strokeWidth="1.15"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>
    </svg>
  );

  const formatPrice = (price) => {
    if (price.includes(".")) {
      const [dollars, cents] = price.split(".");
      return { dollars, cents: `.${cents}` };
    }
    return { dollars: price, cents: "" };
  };

  const { dollars, cents } = formatPrice(lowestAsk);

  return (
    <div className="moment-price-section">
      {/* Price Header */}
      <div className="price-header">
        <h2 className="lowest-ask-title">Lowest Ask</h2>
        <button className="share-button" onClick={onShare}>
          <ShareIcon />
        </button>
      </div>

      {/* Price Display */}
      <div className="price-display">
        <div className="price-amount">
          <span className="dollars">{dollars}</span>
          <span className="cents">{cents}</span>
        </div>
        <div className="currency">{currency}</div>
      </div>

      {/* Sub Info */}
      <div className="sub-info">
        <div className="avg-sale">
          <span className="info-label">Avg Sale</span>
          <span className="info-value">{avgSale}</span>
        </div>
        <div className="for-sale">
          <span className="info-label">for sale</span>
          <span className="info-value">{forSale}</span>
        </div>
      </div>

      {/* Purchase Button */}
      <button
        className={`purchase-button ${isLoading ? "loading" : ""}`}
        onClick={onPurchase}
        disabled={isLoading}
      >
        {isLoading ? (
          <>
            <div className="loading-spinner"></div>
            <span>Processing...</span>
          </>
        ) : (
          <span>Select and Buy</span>
        )}
      </button>
    </div>
  );
};

MomentPriceSection.propTypes = {
  lowestAsk: PropTypes.string,
  currency: PropTypes.string,
  avgSale: PropTypes.string,
  forSale: PropTypes.string,
  onShare: PropTypes.func,
  onPurchase: PropTypes.func,
  isLoading: PropTypes.bool,
};

export default MomentPriceSection;
