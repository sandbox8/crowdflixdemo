import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

function HeroSection() {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  const heroStyles = {
    container: {
      display: "flex",
      width: "100%",
      minHeight: isMobile ? "80vh" : "100vh",
      padding: isMobile ? "80px 20px 40px" : "120px 40px 60px",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
      position: "relative",
      background:
        "linear-gradient(180deg, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0.8) 100%)",
      overflow: "hidden",
    },
    content: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      textAlign: "center",
      maxWidth: isMobile ? "100%" : "800px",
      zIndex: 2,
    },
    title: {
      fontSize: isMobile ? "clamp(28px, 8vw, 42px)" : "52px",
      fontWeight: 600,
      lineHeight: isMobile ? "1.2" : "60px",
      color: "#fff",
      fontFamily: "Outfit, sans-serif",
      margin: isMobile ? "0 0 20px 0" : "0 0 24px 0",
      textShadow: "0 4px 8px rgba(0, 0, 0, 0.3)",
    },
    subtitle: {
      fontSize: isMobile ? "16px" : "20px",
      fontWeight: 400,
      lineHeight: isMobile ? "1.5" : "28px",
      color: "rgba(255, 255, 255, 0.9)",
      fontFamily: "Outfit, sans-serif",
      margin: isMobile ? "0 0 30px 0" : "0 0 40px 0",
      maxWidth: isMobile ? "100%" : "600px",
    },
    buttonContainer: {
      display: "flex",
      flexDirection: isMobile ? "column" : "row",
      gap: isMobile ? "15px" : "20px",
      width: isMobile ? "100%" : "auto",
      maxWidth: isMobile ? "320px" : "none",
    },
    primaryButton: {
      display: "flex",
      padding: isMobile ? "16px 24px" : "16px 32px",
      justifyContent: "center",
      alignItems: "center",
      borderRadius: "25px",
      background: "linear-gradient(90deg, #FF4A3C 0%, #2AA2FD 100%)",
      textDecoration: "none",
      color: "#fff",
      fontFamily: "Outfit, sans-serif",
      fontSize: isMobile ? "16px" : "18px",
      fontWeight: 500,
      transition: "all 0.3s ease",
      border: "none",
      cursor: "pointer",
      width: isMobile ? "100%" : "auto",
      minHeight: "48px",
      boxShadow: "0 4px 20px rgba(42, 162, 253, 0.3)",
      transform: "translateY(0)",
      ":hover": {
        transform: "translateY(-2px)",
        boxShadow: "0 8px 30px rgba(42, 162, 253, 0.4)",
      },
    },
    secondaryButton: {
      display: "flex",
      padding: isMobile ? "16px 24px" : "16px 32px",
      justifyContent: "center",
      alignItems: "center",
      borderRadius: "25px",
      border: "2px solid rgba(255, 255, 255, 0.3)",
      background: "rgba(255, 255, 255, 0.1)",
      backdropFilter: "blur(10px)",
      textDecoration: "none",
      color: "#fff",
      fontFamily: "Outfit, sans-serif",
      fontSize: isMobile ? "16px" : "18px",
      fontWeight: 400,
      transition: "all 0.3s ease",
      cursor: "pointer",
      width: isMobile ? "100%" : "auto",
      minHeight: "48px",
      ":hover": {
        background: "rgba(255, 255, 255, 0.2)",
        border: "2px solid rgba(255, 255, 255, 0.5)",
      },
    },
    backgroundVideo: {
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      objectFit: "cover",
      zIndex: 1,
      opacity: isMobile ? 0.4 : 0.6,
    },
    backgroundOverlay: {
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      background:
        "linear-gradient(180deg, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0.8) 100%)",
      zIndex: 1,
    },
  };

  const handlePrimaryClick = () => {
    // Add analytics tracking for mobile
    if (isMobile && window.gtag) {
      window.gtag("event", "mobile_hero_primary_click", {
        event_category: "mobile_engagement",
        event_label: "hero_section",
      });
    }
  };

  const handleSecondaryClick = () => {
    // Add analytics tracking for mobile
    if (isMobile && window.gtag) {
      window.gtag("event", "mobile_hero_secondary_click", {
        event_category: "mobile_engagement",
        event_label: "hero_section",
      });
    }
  };

  return (
    <div style={heroStyles.container} className="hero-section mobile-safe-area">
      {/* Background Video - Optimized for mobile */}
      <video
        style={heroStyles.backgroundVideo}
        autoPlay
        muted
        loop
        playsInline
        preload={isMobile ? "metadata" : "auto"}
        poster="https://cdn.builder.io/api/v1/image/assets/TEMP/hero-poster"
      >
        <source
          src="https://cdn.builder.io/api/v1/video/assets/TEMP/hero-video-mobile.mp4"
          type="video/mp4"
          media="(max-width: 768px)"
        />
        <source
          src="https://cdn.builder.io/api/v1/video/assets/TEMP/hero-video.mp4"
          type="video/mp4"
        />
      </video>

      {/* Background Overlay */}
      <div style={heroStyles.backgroundOverlay}></div>

      {/* Hero Content */}
      <div
        style={heroStyles.content}
        className="hero-content mobile-text-optimization"
      >
        <h1 style={heroStyles.title} className="hero-title">
          Own the Moments That Move You
        </h1>

        <p style={heroStyles.subtitle} className="hero-subtitle">
          Collect, showcase, and trade iconic scenes from movies, anime, and pop
          culture. CrowdFlix is your fandom passport—where every favorite moment
          becomes a digital collectible.
        </p>

        <div style={heroStyles.buttonContainer} className="hero-buttons">
          <Link
            to="/marketplace"
            style={heroStyles.primaryButton}
            className="btn primary-btn mobile-performance-optimization"
            onClick={handlePrimaryClick}
            onMouseEnter={(e) => {
              if (!isMobile) {
                e.target.style.transform = "translateY(-2px)";
                e.target.style.boxShadow = "0 8px 30px rgba(42, 162, 253, 0.4)";
              }
            }}
            onMouseLeave={(e) => {
              if (!isMobile) {
                e.target.style.transform = "translateY(0)";
                e.target.style.boxShadow = "0 4px 20px rgba(42, 162, 253, 0.3)";
              }
            }}
            onTouchStart={(e) => {
              e.target.style.transform = "scale(0.98)";
            }}
            onTouchEnd={(e) => {
              e.target.style.transform = "scale(1)";
            }}
          >
            Explore Marketplace
          </Link>

          <Link
            to="/marketplace"
            style={heroStyles.secondaryButton}
            className="btn secondary-btn mobile-performance-optimization"
            onClick={handleSecondaryClick}
            onMouseEnter={(e) => {
              if (!isMobile) {
                e.target.style.background = "rgba(255, 255, 255, 0.2)";
                e.target.style.border = "2px solid rgba(255, 255, 255, 0.5)";
              }
            }}
            onMouseLeave={(e) => {
              if (!isMobile) {
                e.target.style.background = "rgba(255, 255, 255, 0.1)";
                e.target.style.border = "2px solid rgba(255, 255, 255, 0.3)";
              }
            }}
            onTouchStart={(e) => {
              e.target.style.transform = "scale(0.98)";
              e.target.style.background = "rgba(255, 255, 255, 0.2)";
            }}
            onTouchEnd={(e) => {
              e.target.style.transform = "scale(1)";
              e.target.style.background = "rgba(255, 255, 255, 0.1)";
            }}
          >
            Start Your Collection
          </Link>

          <Link
            to="/about"
            style={heroStyles.tertiaryButton || heroStyles.secondaryButton}
            className="btn tertiary-btn mobile-performance-optimization"
            onClick={handleSecondaryClick}
            onMouseEnter={(e) => {
              if (!isMobile) {
                e.target.style.background = "rgba(255, 255, 255, 0.15)";
                e.target.style.border = "2px solid rgba(255, 255, 255, 0.4)";
              }
            }}
            onMouseLeave={(e) => {
              if (!isMobile) {
                e.target.style.background = "transparent";
                e.target.style.border = "2px solid rgba(255, 255, 255, 0.2)";
              }
            }}
            onTouchStart={(e) => {
              e.target.style.transform = "scale(0.98)";
              e.target.style.background = "rgba(255, 255, 255, 0.15)";
            }}
            onTouchEnd={(e) => {
              e.target.style.transform = "scale(1)";
              e.target.style.background = "transparent";
            }}
          >
            Watch How It Works
          </Link>
        </div>
      </div>
    </div>
  );
}

export default HeroSection;
