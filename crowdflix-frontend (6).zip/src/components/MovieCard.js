import React, { useState } from "react";
import PropTypes from "prop-types";
import "../styles/components/_movie-card.scss";

const MovieCard = ({
  id,
  title,
  year,
  posterUrl,
  genres = [],
  rating,
  duration,
  director,
  letterboxdData = {},
  universe = "",
  studio = "",
  rarity = "common", // New rarity prop
  size = "default",
  onClick,
  className = "",
  showStats = true,
  showHoverEffects = true,
  isMarketplaceListing = false, // New prop for marketplace styling
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const handleClick = () => {
    if (onClick) {
      onClick({
        id,
        title,
        year,
        posterUrl,
        genres,
        rating,
        duration,
        director,
        letterboxdData,
        universe,
        studio,
      });
    }
  };

  const handleImageLoad = () => {
    setIsLoaded(true);
  };

  const handleImageError = () => {
    setImageError(true);
    setIsLoaded(true);
  };

  const formatDuration = (minutes) => {
    if (!minutes) return "";
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  // Rarity configurations inspired by NBA Top Shot
  const rarityConfig = {
    legendary: {
      color: "#FFD700",
      gradient: "linear-gradient(45deg, #FFD700, #FFA500, #FF6347, #FFD700)",
      glow: "0 0 30px rgba(255, 215, 0, 0.8), 0 0 60px rgba(255, 215, 0, 0.4)",
      borderGlow:
        "0 0 20px rgba(255, 215, 0, 0.6), inset 0 0 20px rgba(255, 215, 0, 0.2)",
      label: "LEGENDARY",
      holographic: true,
    },
    epic: {
      color: "#9D4EDD",
      gradient: "linear-gradient(45deg, #9D4EDD, #C77DFF, #7209B7, #9D4EDD)",
      glow: "0 0 25px rgba(157, 78, 221, 0.7), 0 0 50px rgba(157, 78, 221, 0.3)",
      borderGlow:
        "0 0 15px rgba(157, 78, 221, 0.5), inset 0 0 15px rgba(157, 78, 221, 0.2)",
      label: "EPIC",
      holographic: true,
    },
    rare: {
      color: "#3F37C9",
      gradient: "linear-gradient(45deg, #3F37C9, #7209B7, #560BAD, #3F37C9)",
      glow: "0 0 20px rgba(63, 55, 201, 0.6), 0 0 40px rgba(63, 55, 201, 0.3)",
      borderGlow:
        "0 0 12px rgba(63, 55, 201, 0.4), inset 0 0 12px rgba(63, 55, 201, 0.1)",
      label: "RARE",
      holographic: false,
    },
    common: {
      color: "#6C757D",
      gradient: "linear-gradient(45deg, #6C757D, #ADB5BD, #495057, #6C757D)",
      glow: "0 0 10px rgba(108, 117, 125, 0.3)",
      borderGlow: "0 0 8px rgba(108, 117, 125, 0.2)",
      label: "COMMON",
      holographic: false,
    },
  };

  const currentRarity = rarityConfig[rarity] || rarityConfig.common;

  const getUniverseColor = (universe) => {
    const universeColors = {
      marvel: "#e23636",
      dc: "#0078ff",
      pixar: "#1fb5e8",
      disney: "#113ccf",
      universal: "#000000",
      sony: "#000000",
      warner: "#1fb5e8",
    };
    return universeColors[universe?.toLowerCase()] || "#666";
  };

  const sizeClasses = {
    small: "movie-card--small",
    default: "movie-card--default",
    large: "movie-card--large",
  };

  return (
    <div
      className={`movie-card ${sizeClasses[size]} ${className} ${
        showHoverEffects ? "movie-card--hoverable" : ""
      } movie-card--${rarity} ${isMarketplaceListing ? "movie-card--marketplace" : ""} ${
        isHovered ? "movie-card--hovered" : ""
      }`}
      onClick={handleClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={(e) => {
        if (onClick && (e.key === "Enter" || e.key === " ")) {
          e.preventDefault();
          handleClick();
        }
      }}
      style={{
        "--rarity-color": currentRarity.color,
        "--rarity-gradient": currentRarity.gradient,
        "--rarity-glow": currentRarity.glow,
        "--rarity-border-glow": currentRarity.borderGlow,
      }}
    >
      {/* Movie Poster */}
      <div className="movie-card__poster">
        {/* Rarity border and effects */}
        <div className="movie-card__rarity-border" />
        {currentRarity.holographic && (
          <div className="movie-card__holographic-overlay" />
        )}

        {/* Floating particles for legendary cards */}
        {rarity === "legendary" && (
          <div className="movie-card__particles">
            {[...Array(12)].map((_, i) => (
              <div
                key={i}
                className="movie-card__particle"
                style={{
                  "--delay": `${i * 0.2}s`,
                  "--x": `${Math.random() * 100}%`,
                  "--y": `${Math.random() * 100}%`,
                }}
              />
            ))}
          </div>
        )}

        {!isLoaded && (
          <div className="movie-card__placeholder">
            <div className="movie-card__spinner" />
          </div>
        )}

        {imageError ? (
          <div className="movie-card__error">
            <div className="movie-card__error-icon">🎬</div>
            <span>Poster Unavailable</span>
          </div>
        ) : (
          <img
            src={posterUrl}
            alt={`${title} poster`}
            className={`movie-card__image ${isLoaded ? "loaded" : ""}`}
            onLoad={handleImageLoad}
            onError={handleImageError}
            loading="lazy"
          />
        )}

        {/* Rarity badge */}
        <div
          className={`movie-card__rarity-badge movie-card__rarity-badge--${rarity}`}
        >
          <span className="movie-card__rarity-label">
            {currentRarity.label}
          </span>
          {rarity === "legendary" && (
            <span className="movie-card__rarity-icon">👑</span>
          )}
        </div>

        {/* Overlay with movie info */}
        <div className="movie-card__overlay">
          <div className="movie-card__overlay-content">
            {rating && (
              <div className="movie-card__rating">
                <span className="movie-card__rating-icon">⭐</span>
                <span className="movie-card__rating-value">{rating}</span>
              </div>
            )}

            {duration && (
              <div className="movie-card__duration">
                {formatDuration(duration)}
              </div>
            )}
          </div>
        </div>

        {/* Universe badge */}
        {universe && (
          <div
            className="movie-card__universe-badge"
            style={{ backgroundColor: getUniverseColor(universe) }}
          >
            {universe.toUpperCase()}
          </div>
        )}
      </div>

      {/* Movie Details */}
      <div className="movie-card__details">
        <h3 className="movie-card__title">{title}</h3>

        <div className="movie-card__meta">
          {year && <span className="movie-card__year">{year}</span>}
          {director && (
            <span className="movie-card__director">Dir. {director}</span>
          )}
        </div>

        {genres.length > 0 && (
          <div className="movie-card__genres">
            {genres.slice(0, 2).map((genre, index) => (
              <span key={index} className="movie-card__genre">
                {genre}
              </span>
            ))}
            {genres.length > 2 && (
              <span className="movie-card__genre-more">
                +{genres.length - 2}
              </span>
            )}
          </div>
        )}

        {showStats && letterboxdData && (
          <div className="movie-card__stats">
            {letterboxdData.watchedCount && (
              <div className="movie-card__stat">
                <span className="movie-card__stat-icon">👁</span>
                <span className="movie-card__stat-value">
                  {letterboxdData.watchedCount}
                </span>
              </div>
            )}

            {letterboxdData.likeCount && (
              <div className="movie-card__stat">
                <span className="movie-card__stat-icon">❤️</span>
                <span className="movie-card__stat-value">
                  {letterboxdData.likeCount}
                </span>
              </div>
            )}

            {letterboxdData.listCount && (
              <div className="movie-card__stat">
                <span className="movie-card__stat-icon">📋</span>
                <span className="movie-card__stat-value">
                  {letterboxdData.listCount}
                </span>
              </div>
            )}
          </div>
        )}

        {/* Marketplace listing button */}
        {isMarketplaceListing && (
          <div className="movie-card__listing-actions">
            <button
              className={`movie-card__view-listing movie-card__view-listing--${rarity}`}
            >
              <span className="movie-card__listing-text">View Listing</span>
              <span className="movie-card__listing-icon">🎬</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

MovieCard.propTypes = {
  id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  title: PropTypes.string.isRequired,
  year: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  posterUrl: PropTypes.string.isRequired,
  genres: PropTypes.arrayOf(PropTypes.string),
  rating: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  duration: PropTypes.number,
  director: PropTypes.string,
  letterboxdData: PropTypes.shape({
    watchedCount: PropTypes.string,
    likeCount: PropTypes.string,
    listCount: PropTypes.string,
    averageRating: PropTypes.number,
  }),
  universe: PropTypes.string,
  studio: PropTypes.string,
  rarity: PropTypes.oneOf(["common", "rare", "epic", "legendary"]),
  size: PropTypes.oneOf(["small", "default", "large"]),
  onClick: PropTypes.func,
  className: PropTypes.string,
  showStats: PropTypes.bool,
  showHoverEffects: PropTypes.bool,
  isMarketplaceListing: PropTypes.bool,
};

export default MovieCard;
