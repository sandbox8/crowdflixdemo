import React from "react";
import PropTypes from "prop-types";

const ActiveFilters = ({
  filters,
  onRemoveFilter,
  onClearAll,
  className = "",
}) => {
  // Filter labels mapping
  const filterLabels = {
    genre: {
      action: "Action",
      romance: "Romance",
      horror: "Horror",
      anime: "Anime",
      comedy: "Comedy",
      drama: "Drama",
      scifi: "Sci-Fi",
      thriller: "Thriller",
    },
    emotion: {
      rage: "Rage",
      joy: "Joy",
      regret: "Regret",
      triumph: "Triumph",
      love: "Love",
      fear: "Fear",
      hope: "Hope",
      despair: "Despair",
    },
    characterType: {
      hero: "Hero",
      antihero: "Anti-Hero",
      sidekick: "Sidekick",
      villain: "Villain",
      mentor: "Mentor",
      trickster: "Trickster",
    },
    era: {
      "80s": "80s",
      "90s": "90s",
      "2000s": "2000s",
      "2010s": "2010s",
      new: "New Releases",
    },
    theme: {
      revenge: "Revenge",
      "coming-of-age": "Coming-of-Age",
      betrayal: "Betrayal",
      redemption: "Redemption",
      sacrifice: "Sacrifice",
      discovery: "Discovery",
    },
  };

  // Category emojis
  const categoryEmojis = {
    genre: "🎬",
    emotion: "❤️",
    characterType: "🧙",
    era: "🗓️",
    theme: "🎭",
  };

  // Get all active filter tags
  const getActiveFilterTags = () => {
    const tags = [];

    Object.entries(filters).forEach(([category, filterValues]) => {
      if (category === "priceRange") {
        // Handle price range separately
        const [min, max] = filterValues;
        if (min > 0 || max < 10000) {
          tags.push({
            category,
            value: "priceRange",
            label:
              min === 0
                ? `Under $${max}`
                : max >= 10000
                  ? `$${min}+`
                  : `$${min}-${max}`,
            emoji: "💵",
          });
        }
      } else if (Array.isArray(filterValues) && filterValues.length > 0) {
        // Handle multi-select filters
        filterValues.forEach((value) => {
          const label = filterLabels[category]?.[value] || value;
          tags.push({
            category,
            value,
            label,
            emoji: categoryEmojis[category] || "🏷️",
          });
        });
      }
    });

    return tags;
  };

  const activeTags = getActiveFilterTags();

  if (activeTags.length === 0) {
    return null;
  }

  return (
    <div className={`active-filters ${className}`}>
      <div className="active-filters__container">
        {/* Header */}
        <div className="active-filters__header">
          <span className="active-filters__title">
            Active Filters ({activeTags.length})
          </span>
          <button className="active-filters__clear-all" onClick={onClearAll}>
            Clear All ✖️
          </button>
        </div>

        {/* Filter Tags */}
        <div className="active-filters__tags">
          {activeTags.map((tag, index) => (
            <div
              key={`${tag.category}-${tag.value}-${index}`}
              className="active-filter-tag"
            >
              <span className="active-filter-tag__emoji">{tag.emoji}</span>
              <span className="active-filter-tag__label">{tag.label}</span>
              <button
                className="active-filter-tag__remove"
                onClick={() => onRemoveFilter(tag.category, tag.value)}
                aria-label={`Remove ${tag.label} filter`}
              >
                ✖️
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

ActiveFilters.propTypes = {
  filters: PropTypes.object.isRequired,
  onRemoveFilter: PropTypes.func.isRequired,
  onClearAll: PropTypes.func.isRequired,
  className: PropTypes.string,
};

export default ActiveFilters;
