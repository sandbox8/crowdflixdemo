import React, { useState } from "react";
import PropTypes from "prop-types";

const VaultSnapshot = ({ moments }) => {
  const [hoveredMoment, setHoveredMoment] = useState(null);

  const getRarityClass = (rarity) => {
    return `vault-moment-card--${rarity}`;
  };

  return (
    <section className="vault-snapshot">
      <div className="vault-snapshot__container">
        <header className="vault-snapshot__header">
          <h2 className="vault-snapshot__title">Vault Highlights</h2>
          <p className="vault-snapshot__subtitle">
            My cinematic identity in moments
          </p>
        </header>

        <div className="vault-snapshot__grid">
          {moments.map((moment) => (
            <article
              key={moment.id}
              className={`vault-moment-card ${getRarityClass(moment.rarity)}`}
              onMouseEnter={() => setHoveredMoment(moment.id)}
              onMouseLeave={() => setHoveredMoment(null)}
            >
              {/* Media Container */}
              <div className="vault-moment-card__media">
                {moment.videoUrl && hoveredMoment === moment.id ? (
                  <video
                    className="vault-moment-card__video"
                    autoPlay
                    muted
                    loop
                    playsInline
                  >
                    <source src={moment.videoUrl} type="video/mp4" />
                    <img
                      src={moment.thumbnailUrl}
                      alt={moment.title}
                      className="vault-moment-card__fallback"
                    />
                  </video>
                ) : (
                  <img
                    src={moment.thumbnailUrl}
                    alt={moment.title}
                    className="vault-moment-card__image"
                  />
                )}
              </div>

              {/* Tier Badge */}
              <div className="vault-moment-card__tier-badge">
                {moment.rarity.toUpperCase()}
              </div>

              {/* Content */}
              <div className="vault-moment-card__content">
                {/* Emotion Tag */}
                <div className="vault-moment-card__emotion-tag">
                  {moment.emotionTag}
                </div>

                {/* Title & Movie */}
                <div className="vault-moment-card__info">
                  <h3 className="vault-moment-card__title">{moment.title}</h3>
                  <p className="vault-moment-card__movie">
                    {moment.filmSeries}
                  </p>
                </div>

                {/* Quote (if meaningful) */}
                {moment.caption && moment.caption.length > 0 && (
                  <blockquote className="vault-moment-card__quote">
                    &ldquo;{moment.caption}&rdquo;
                  </blockquote>
                )}
              </div>
            </article>
          ))}
        </div>

        {/* CTA */}
        <div className="vault-snapshot__cta">
          <button className="vault-snapshot__view-all-btn">
            <span>View Full Vault</span>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path
                d="M6 12L10 8L6 4"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
        </div>
      </div>
    </section>
  );
};

VaultSnapshot.propTypes = {
  moments: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      title: PropTypes.string.isRequired,
      filmSeries: PropTypes.string.isRequired,
      emotionTag: PropTypes.string.isRequired,
      rarity: PropTypes.string.isRequired,
      thumbnailUrl: PropTypes.string.isRequired,
      videoUrl: PropTypes.string,
      caption: PropTypes.string,
      owned: PropTypes.bool.isRequired,
    }),
  ).isRequired,
};

export default VaultSnapshot;
