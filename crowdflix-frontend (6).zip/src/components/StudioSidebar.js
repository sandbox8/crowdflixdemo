import React from "react";
import PropTypes from "prop-types";

const StudioSidebar = ({ studio }) => {
  const relatedStudios = [
    { name: "Blumhouse", followers: "89K", logo: "🎃" },
    { name: "Neon", followers: "45K", logo: "🌈" },
    { name: "Focus Features", followers: "156K", logo: "🎯" },
  ];

  const trendingHashtags = [
    "#A24Horror",
    "#IndieFilm",
    "#ArtHouse",
    "#EverythingEverywhere",
    "#FilmTwitter",
  ];

  return (
    <div className="studio-sidebar">
      {/* Performance Stats */}
      <div className="studio-sidebar__card">
        <h3 className="studio-sidebar__card-title">
          <span className="studio-sidebar__card-icon">📊</span>
          Performance
        </h3>

        <div className="studio-sidebar__stats">
          <div className="studio-sidebar__stat">
            <span className="studio-sidebar__stat-label">Total Revenue</span>
            <span className="studio-sidebar__stat-value">
              {studio.stats?.totalRevenue || "N/A"}
            </span>
          </div>

          <div className="studio-sidebar__stat">
            <span className="studio-sidebar__stat-label">Top Moment</span>
            <span className="studio-sidebar__stat-value">
              {studio.stats?.topMoment || "N/A"}
            </span>
          </div>

          <div className="studio-sidebar__stat">
            <span className="studio-sidebar__stat-label">Avg. Price</span>
            <span className="studio-sidebar__stat-value">
              {studio.stats?.avgPrice || "N/A"}
            </span>
          </div>

          <div className="studio-sidebar__stat">
            <span className="studio-sidebar__stat-label">Most Popular</span>
            <span className="studio-sidebar__stat-value">
              {studio.stats?.mostPopular || "N/A"}
            </span>
          </div>
        </div>
      </div>

      {/* Trending Tags */}
      <div className="studio-sidebar__card">
        <h3 className="studio-sidebar__card-title">
          <span className="studio-sidebar__card-icon">🔥</span>
          Trending
        </h3>

        <div className="studio-sidebar__tags">
          {trendingHashtags.map((tag, index) => (
            <button key={index} className="studio-sidebar__tag">
              {tag}
            </button>
          ))}
        </div>
      </div>

      {/* Related Studios */}
      <div className="studio-sidebar__card">
        <h3 className="studio-sidebar__card-title">
          <span className="studio-sidebar__card-icon">🎬</span>
          Similar Studios
        </h3>

        <div className="studio-sidebar__related">
          {relatedStudios.map((relatedStudio, index) => (
            <div key={index} className="studio-sidebar__related-item">
              <div className="studio-sidebar__related-avatar">
                {relatedStudio.logo}
              </div>
              <div className="studio-sidebar__related-info">
                <span className="studio-sidebar__related-name">
                  {relatedStudio.name}
                </span>
                <span className="studio-sidebar__related-followers">
                  {relatedStudio.followers} followers
                </span>
              </div>
              <button className="studio-sidebar__related-follow">Follow</button>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="studio-sidebar__card">
        <h3 className="studio-sidebar__card-title">
          <span className="studio-sidebar__card-icon">⚡</span>
          Quick Actions
        </h3>

        <div className="studio-sidebar__actions">
          <button className="studio-sidebar__action">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path
                d="M15 7H20L19 21H5L4 7H9M10 11V17M14 11V17M12 7V3H8V7"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            View All Moments
          </button>

          <button className="studio-sidebar__action">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <rect
                x="3"
                y="4"
                width="18"
                height="16"
                rx="2"
                stroke="currentColor"
                strokeWidth="2"
              />
              <path
                d="M7 4V2M17 4V2M3 10H21"
                stroke="currentColor"
                strokeWidth="2"
              />
            </svg>
            Upcoming Drops
          </button>

          <button className="studio-sidebar__action">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path
                d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            Add to Watchlist
          </button>
        </div>
      </div>

      {/* Newsletter Signup */}
      <div className="studio-sidebar__card studio-sidebar__card--newsletter">
        <h3 className="studio-sidebar__card-title">
          <span className="studio-sidebar__card-icon">📧</span>
          Stay Updated
        </h3>

        <p className="studio-sidebar__newsletter-text">
          Get notified about {studio.name}&apos;s latest drops and exclusive
          content.
        </p>

        <div className="studio-sidebar__newsletter-form">
          <input
            type="email"
            placeholder="Enter your email"
            className="studio-sidebar__newsletter-input"
          />
          <button className="studio-sidebar__newsletter-btn">Subscribe</button>
        </div>
      </div>
    </div>
  );
};

StudioSidebar.propTypes = {
  studio: PropTypes.shape({
    name: PropTypes.string.isRequired,
    stats: PropTypes.shape({
      totalRevenue: PropTypes.string,
      topMoment: PropTypes.string,
      avgPrice: PropTypes.string,
      mostPopular: PropTypes.string,
    }),
  }).isRequired,
};

export default StudioSidebar;
