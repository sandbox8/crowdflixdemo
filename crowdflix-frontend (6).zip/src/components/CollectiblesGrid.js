import React, { useState } from "react";
import { Link } from "react-router-dom";
import PropTypes from "prop-types";

const CollectiblesGrid = ({ collectibles = [] }) => {
  const [filter, setFilter] = useState("all");

  // Filter collectibles based on tier
  const filteredCollectibles = collectibles.filter((collectible) => {
    if (filter === "all") return true;
    return collectible.tier.toLowerCase() === filter;
  });

  return (
    <section className="collectibles-grid-section">
      <div className="collectibles-grid-section__header">
        <h2 className="section-title">Universe Collectibles</h2>
        <p className="section-subtitle">
          Discover exclusive moments from this universe
        </p>

        {/* Simplified Filters */}
        <div className="section-filters">
          <button
            className={`filter-btn ${filter === "all" ? "filter-btn--active" : ""}`}
            onClick={() => setFilter("all")}
          >
            All
          </button>
          <button
            className={`filter-btn ${filter === "legendary" ? "filter-btn--active" : ""}`}
            onClick={() => setFilter("legendary")}
          >
            Legendary
          </button>
          <button
            className={`filter-btn ${filter === "ultimate" ? "filter-btn--active" : ""}`}
            onClick={() => setFilter("ultimate")}
          >
            Ultimate
          </button>
        </div>
      </div>

      {/* Collectibles Grid */}
      <div className="collectibles-grid">
        {filteredCollectibles.length > 0 ? (
          filteredCollectibles.map((collectible) => (
            <CollectibleCard key={collectible.id} collectible={collectible} />
          ))
        ) : (
          // Single clean placeholder when no content
          <div className="collectibles-empty-state">
            <div className="empty-state-icon">🎬</div>
            <h3 className="empty-state-title">No moments found</h3>
            <p className="empty-state-message">
              Check back soon for new collectibles from this universe
            </p>
          </div>
        )}
      </div>

      {/* Load More - Only show if we have content */}
      {filteredCollectibles.length > 0 && (
        <div className="collectibles-grid-section__load-more">
          <button className="load-more-btn">Load More Collectibles</button>
        </div>
      )}
    </section>
  );
};

const CollectibleCard = ({ collectible }) => {
  const [showVariants, setShowVariants] = useState(false);

  return (
    <div className="collectible-card">
      {/* Main Collectible */}
      <Link to={`/moment/${collectible.id}`} className="collectible-card__link">
        <div className="collectible-card__image-container">
          <img
            src={collectible.image}
            alt={collectible.title}
            className="collectible-card__image"
            onError={(e) => {
              e.target.src =
                "https://via.placeholder.com/300x400/1a1a1a/ffffff?text=Moment";
            }}
          />
          <div
            className={`collectible-card__tier-badge collectible-card__tier-badge--${collectible.tier.toLowerCase()}`}
          >
            {collectible.tier}
          </div>
        </div>

        <div className="collectible-card__content">
          <h3 className="collectible-card__title">{collectible.title}</h3>

          <div className="collectible-card__pricing">
            <div className="price-info">
              <span className="price-label">Lowest Ask</span>
              <span className="price-value">{collectible.price}</span>
            </div>

            <div className="collectible-card__stats">
              <span className="stat-item">12 for sale</span>
              <span className="stat-divider">•</span>
              <span className="stat-item">$89 avg</span>
            </div>
          </div>
        </div>
      </Link>

      {/* Variants Section - Only show if variants exist */}
      {collectible.variants && collectible.variants.length > 0 && (
        <div className="collectible-card__variants">
          <button
            className="variants-toggle"
            onClick={() => setShowVariants(!showVariants)}
          >
            <span>Variants ({collectible.variants.length})</span>
            <svg
              className={`chevron ${showVariants ? "chevron--expanded" : ""}`}
              width="12"
              height="12"
              viewBox="0 0 12 12"
            >
              <path
                d="M3 4.5L6 7.5L9 4.5"
                stroke="currentColor"
                strokeWidth="1.5"
                fill="none"
              />
            </svg>
          </button>

          {showVariants && (
            <div className="variants-list">
              {collectible.variants.map((variant) => (
                <Link
                  key={variant.id}
                  to={`/moment/${variant.id}`}
                  className="variant-item"
                >
                  <span className="variant-title">{variant.title}</span>
                  <span className="variant-price">{variant.price}</span>
                  <span
                    className={`variant-tier variant-tier--${variant.tier.toLowerCase()}`}
                  >
                    {variant.tier}
                  </span>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

CollectibleCard.propTypes = {
  collectible: PropTypes.shape({
    id: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    image: PropTypes.string.isRequired,
    price: PropTypes.string.isRequired,
    tier: PropTypes.string.isRequired,
    variants: PropTypes.arrayOf(
      PropTypes.shape({
        id: PropTypes.string.isRequired,
        title: PropTypes.string.isRequired,
        price: PropTypes.string.isRequired,
        tier: PropTypes.string.isRequired,
      }),
    ),
  }).isRequired,
};

CollectiblesGrid.propTypes = {
  collectibles: PropTypes.arrayOf(PropTypes.object),
};

export default CollectiblesGrid;
