import React from "react";
import PropTypes from "prop-types";

const CrowdflixLogo = ({ width, height, fill }) => {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: "14px",
        position: "relative",
      }}
    >
      {/* Original C Logo */}
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width={width}
        height={height}
        viewBox="-37.5 0 600 600"
        fill="none"
        className="me-2"
      >
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M0 163.35 283.47 0l239.94 133.575v65.475l-127.98 71.985 -111.96 -68.835 -107.73 63.75 -56.565 -35.25 164.295 -97.125 111.96 68.625 62.325 -38.85 -176.745 -97.86 -222.165 127.59v72.885l224.625 133.5 122.82 -73.845 117.12 70.86v68.13L281.01 600 0 434.49v-71.46l283.47 170.58 182.04 -102.405 -59.22 -34.725 -122.82 68.13L0 300z"
          fill={fill}
        />
      </svg>

      {/* CROWDFLIX Text */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "8px",
        }}
      >
        <span
          style={{
            color: fill,
            fontFamily: "Outfit, sans-serif",
            fontSize: "20px",
            fontWeight: 700,
            letterSpacing: "1.5px",
            textTransform: "uppercase",
          }}
        >
          CROWDFLIX
        </span>

        {/* BETA Badge */}
        <div
          style={{
            position: "relative",
            top: "-2px",
          }}
        >
          <div
            style={{
              background: "linear-gradient(135deg, #2AA2FD 0%, #4A90E2 100%)",
              color: "white",
              fontSize: "10px",
              fontWeight: 600,
              fontFamily: "Outfit, sans-serif",
              padding: "3px 8px",
              borderRadius: "12px",
              letterSpacing: "0.5px",
              textTransform: "uppercase",
              boxShadow: "0 2px 8px rgba(42, 162, 253, 0.3)",
              border: "1px solid rgba(255, 255, 255, 0.2)",
            }}
          >
            BETA
          </div>
        </div>
      </div>
    </div>
  );
};

CrowdflixLogo.propTypes = {
  width: PropTypes.number,
  height: PropTypes.number,
  fill: PropTypes.string,
};

CrowdflixLogo.defaultProps = {
  width: 40,
  height: 40,
  fill: "white",
};

export default CrowdflixLogo;
