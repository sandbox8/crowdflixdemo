import React, { useState, useCallback, useEffect, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import { selectUser } from "../features/user/userSlice";
import { Search, X } from "react-bootstrap-icons";
import CrowdflixLogo from "../components/CrowdflixLogo";
import SmartQuickActions from "../components/SmartQuickActions";

function Navbar() {
  const user = useSelector(selectUser);
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const searchInputRef = useRef(null);
  const mobileMenuRef = useRef(null);

  // Check if screen is mobile size
  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  const toggleMobileMenu = useCallback(() => {
    setIsMobileMenuOpen((prev) => !prev);
  }, []);

  const closeMobileMenu = useCallback(() => {
    setIsMobileMenuOpen(false);
  }, []);

  const toggleSearch = useCallback(() => {
    setIsSearchOpen((prev) => {
      const newState = !prev;
      if (newState) {
        // Focus search input when opened
        setTimeout(() => searchInputRef.current?.focus(), 100);
      } else {
        setSearchQuery("");
      }
      return newState;
    });
  }, []);

  const handleSearchSubmit = useCallback(
    (e) => {
      e.preventDefault();
      if (searchQuery.trim()) {
        // In a real app, this would navigate to search results
        console.log("Searching for:", searchQuery);
        // Navigate to marketplace with search query
        window.location.href = `/marketplace?search=${encodeURIComponent(searchQuery)}`;
      }
    },
    [searchQuery],
  );

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape") {
        if (isSearchOpen) {
          setIsSearchOpen(false);
          setSearchQuery("");
        }
        if (isMobileMenuOpen) {
          setIsMobileMenuOpen(false);
        }
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isSearchOpen, isMobileMenuOpen]);

  // Prevent body scroll when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }

    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isMobileMenuOpen]);

  // Focus management for mobile menu
  useEffect(() => {
    if (isMobileMenuOpen && mobileMenuRef.current) {
      mobileMenuRef.current.focus();
    }
  }, [isMobileMenuOpen]);

  // Global search event listener
  useEffect(() => {
    const handleOpenSearch = () => {
      setIsSearchOpen(true);
    };

    window.addEventListener("openSearch", handleOpenSearch);
    return () => window.removeEventListener("openSearch", handleOpenSearch);
  }, []);

  // Intelligent menu auto-close
  useEffect(() => {
    if (isMobileMenuOpen) {
      const handleRouteChange = () => {
        setIsMobileMenuOpen(false);
      };

      // Close menu on route change
      window.addEventListener("popstate", handleRouteChange);
      return () => window.removeEventListener("popstate", handleRouteChange);
    }
  }, [isMobileMenuOpen]);

  // Check if current route is active
  const isActiveRoute = (path) => {
    if (path === "/" && location.pathname === "/") return true;
    if (path !== "/" && location.pathname.startsWith(path)) return true;
    return false;
  };

  const navStyles = {
    desktop: {
      display: "flex",
      width: "100%",
      padding: "0px 40px",
      justifyContent: "space-between",
      alignItems: "center",
      position: "absolute",
      left: "2px",
      top: "30px",
      height: "50px",
      zIndex: 1000,
    },
    mobile: {
      display: "flex",
      width: "100%",
      padding: "0px 20px",
      justifyContent: "space-between",
      alignItems: "center",
      position: "absolute",
      left: "0px",
      top: "15px",
      height: "60px",
      zIndex: 1000,
    },
  };

  const mobileMenuStyles = {
    overlay: {
      position: "fixed",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      backgroundColor: "rgba(0, 0, 0, 0.8)",
      zIndex: 9998,
      display: isMobileMenuOpen ? "block" : "none",
      transition: "opacity 0.3s ease-in-out",
      opacity: isMobileMenuOpen ? 1 : 0,
    },
    menu: {
      position: "fixed",
      top: "75px",
      right: isMobileMenuOpen ? "0" : "-100%",
      width: "280px",
      height: "calc(100vh - 75px)",
      backgroundColor: "rgba(26, 26, 26, 0.95)",
      backdropFilter: "blur(20px)",
      padding: "30px 20px",
      transition: "right 0.3s ease-in-out",
      zIndex: 9999,
      borderLeft: "1px solid rgba(255, 255, 255, 0.1)",
      outline: "none",
    },
  };

  const searchOverlayStyles = {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: "rgba(0, 0, 0, 0.9)",
    zIndex: 10000,
    display: isSearchOpen ? "flex" : "none",
    alignItems: "center",
    justifyContent: "center",
    backdropFilter: "blur(20px)",
  };

  const HamburgerIcon = () => (
    <button
      onClick={toggleMobileMenu}
      style={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        width: "30px",
        height: "30px",
        background: "transparent",
        border: "none",
        cursor: "pointer",
        padding: "5px",
        transition: "transform 0.2s ease",
      }}
      aria-label={isMobileMenuOpen ? "Close mobile menu" : "Open mobile menu"}
      aria-expanded={isMobileMenuOpen}
      onMouseOver={(e) => (e.target.style.transform = "scale(1.1)")}
      onMouseOut={(e) => (e.target.style.transform = "scale(1)")}
    >
      <span
        style={{
          display: "block",
          width: "20px",
          height: "2px",
          backgroundColor: "#fff",
          margin: "2px 0",
          transition: "0.3s",
          transform: isMobileMenuOpen
            ? "rotate(-45deg) translate(-5px, 6px)"
            : "none",
        }}
      ></span>
      <span
        style={{
          display: "block",
          width: "20px",
          height: "2px",
          backgroundColor: "#fff",
          margin: "2px 0",
          transition: "0.3s",
          opacity: isMobileMenuOpen ? "0" : "1",
        }}
      ></span>
      <span
        style={{
          display: "block",
          width: "20px",
          height: "2px",
          backgroundColor: "#fff",
          margin: "2px 0",
          transition: "0.3s",
          transform: isMobileMenuOpen
            ? "rotate(45deg) translate(-5px, -6px)"
            : "none",
        }}
      ></span>
    </button>
  );

  const SearchOverlay = () => (
    <div style={searchOverlayStyles}>
      <div
        style={{
          width: "90%",
          maxWidth: "600px",
          padding: "40px",
          textAlign: "center",
        }}
      >
        <h2
          style={{
            color: "#fff",
            fontFamily: "Outfit, sans-serif",
            fontSize: "32px",
            fontWeight: 600,
            marginBottom: "30px",
          }}
        >
          Search CrowdFlix
        </h2>
        <form onSubmit={handleSearchSubmit}>
          <div
            style={{
              position: "relative",
              marginBottom: "20px",
            }}
          >
            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for moments, collections, creators..."
              style={{
                width: "100%",
                padding: "20px 60px 20px 20px",
                fontSize: "18px",
                fontFamily: "Outfit, sans-serif",
                backgroundColor: "rgba(255, 255, 255, 0.1)",
                border: "2px solid rgba(255, 255, 255, 0.2)",
                borderRadius: "15px",
                color: "#fff",
                outline: "none",
                transition: "border-color 0.3s ease",
              }}
              onFocus={(e) => (e.target.style.borderColor = "#FFC03F")}
              onBlur={(e) =>
                (e.target.style.borderColor = "rgba(255, 255, 255, 0.2)")
              }
            />
            <button
              type="button"
              onClick={toggleSearch}
              style={{
                position: "absolute",
                right: "15px",
                top: "50%",
                transform: "translateY(-50%)",
                background: "transparent",
                border: "none",
                color: "#fff",
                cursor: "pointer",
                padding: "5px",
              }}
              aria-label="Close search"
            >
              <X size={24} />
            </button>
          </div>
          <button
            type="submit"
            style={{
              padding: "15px 30px",
              backgroundColor: "#FFC03F",
              color: "#000",
              border: "none",
              borderRadius: "10px",
              fontSize: "16px",
              fontWeight: 600,
              cursor: "pointer",
              transition: "background-color 0.3s ease",
            }}
            onMouseOver={(e) => (e.target.style.backgroundColor = "#FFD700")}
            onMouseOut={(e) => (e.target.style.backgroundColor = "#FFC03F")}
          >
            Search
          </button>
        </form>
      </div>
    </div>
  );

  const MobileMenu = () => (
    <>
      {/* Overlay */}
      <div style={mobileMenuStyles.overlay} onClick={closeMobileMenu}></div>

      {/* Menu */}
      <div
        ref={mobileMenuRef}
        style={mobileMenuStyles.menu}
        tabIndex={-1}
        role="navigation"
        aria-label="Mobile navigation menu"
      >
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "25px",
          }}
        >
          {/* Search */}
          <button
            onClick={() => {
              closeMobileMenu();
              toggleSearch();
            }}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "15px",
              padding: "15px 0",
              borderBottom: "1px solid rgba(255, 255, 255, 0.1)",
              background: "transparent",
              border: "none",
              color: "#fff",
              cursor: "pointer",
              width: "100%",
              textAlign: "left",
              transition: "background-color 0.2s ease",
            }}
            onMouseOver={(e) =>
              (e.target.style.backgroundColor = "rgba(255, 255, 255, 0.05)")
            }
            onMouseOut={(e) => (e.target.style.backgroundColor = "transparent")}
            aria-label="Open search"
          >
            <Search style={{ color: "#FFC03F", fontSize: "20px" }} />
            <span
              style={{
                color: "#fff",
                fontFamily: "Outfit, sans-serif",
                fontSize: "16px",
                fontWeight: 400,
              }}
            >
              Search
            </span>
          </button>

          {/* Navigation Links */}
          <Link
            to="/"
            onClick={closeMobileMenu}
            style={{
              display: "flex",
              alignItems: "center",
              padding: "15px 0",
              textDecoration: "none",
              borderBottom: "1px solid rgba(255, 255, 255, 0.05)",
              backgroundColor: isActiveRoute("/")
                ? "rgba(255, 74, 60, 0.1)"
                : "transparent",
              borderRadius: isActiveRoute("/") ? "8px" : "0",
              transition: "background-color 0.2s ease",
            }}
            onMouseOver={(e) =>
              !isActiveRoute("/") &&
              (e.target.style.backgroundColor = "rgba(255, 255, 255, 0.05)")
            }
            onMouseOut={(e) =>
              !isActiveRoute("/") &&
              (e.target.style.backgroundColor = "transparent")
            }
          >
            <span
              style={{
                color: isActiveRoute("/") ? "#FF4A3C" : "#fff",
                fontFamily: "Outfit, sans-serif",
                fontSize: "18px",
                fontWeight: isActiveRoute("/") ? 600 : 400,
              }}
            >
              Home
            </span>
          </Link>

          <Link
            to="/marketplace"
            onClick={closeMobileMenu}
            style={{
              display: "flex",
              alignItems: "center",
              padding: "15px 0",
              textDecoration: "none",
              borderBottom: "1px solid rgba(255, 255, 255, 0.05)",
              backgroundColor: isActiveRoute("/marketplace")
                ? "rgba(203, 246, 255, 0.1)"
                : "transparent",
              borderRadius: isActiveRoute("/marketplace") ? "8px" : "0",
              transition: "background-color 0.2s ease",
            }}
            onMouseOver={(e) =>
              !isActiveRoute("/marketplace") &&
              (e.target.style.backgroundColor = "rgba(255, 255, 255, 0.05)")
            }
            onMouseOut={(e) =>
              !isActiveRoute("/marketplace") &&
              (e.target.style.backgroundColor = "transparent")
            }
          >
            <span
              style={{
                color: isActiveRoute("/marketplace") ? "#CBF6FF" : "#fff",
                fontFamily: "Outfit, sans-serif",
                fontSize: "18px",
                fontWeight: isActiveRoute("/marketplace") ? 600 : 400,
              }}
            >
              Marketplace
            </span>
          </Link>

          <Link
            to="/u/james-blackwood"
            onClick={closeMobileMenu}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "15px 0",
              textDecoration: "none",
              borderBottom: "1px solid rgba(255, 255, 255, 0.05)",
              backgroundColor: isActiveRoute("/u/")
                ? "rgba(255, 203, 205, 0.1)"
                : "transparent",
              borderRadius: isActiveRoute("/u/") ? "8px" : "0",
              transition: "background-color 0.2s ease",
            }}
            onMouseOver={(e) =>
              !isActiveRoute("/u/") &&
              (e.target.style.backgroundColor = "rgba(255, 255, 255, 0.05)")
            }
            onMouseOut={(e) =>
              !isActiveRoute("/u/") &&
              (e.target.style.backgroundColor = "transparent")
            }
          >
            <span
              style={{
                color: isActiveRoute("/u/") ? "#FFCBCD" : "#fff",
                fontFamily: "Outfit, sans-serif",
                fontSize: "18px",
                fontWeight: isActiveRoute("/u/") ? 600 : 400,
              }}
            >
              My Collection
            </span>
            <div
              style={{
                display: "flex",
                width: "20px",
                height: "20px",
                justifyContent: "center",
                alignItems: "center",
                borderRadius: "100px",
                background: "#981D21",
              }}
            >
              <span
                style={{
                  color: "#fff",
                  fontSize: "12px",
                  fontWeight: 500,
                }}
              >
                8
              </span>
            </div>
          </Link>

          <Link
            to="/a24"
            onClick={closeMobileMenu}
            style={{
              display: "flex",
              alignItems: "center",
              padding: "15px 0",
              textDecoration: "none",
              borderBottom: "1px solid rgba(255, 255, 255, 0.05)",
              backgroundColor: isActiveRoute("/a24")
                ? "rgba(42, 162, 253, 0.1)"
                : "transparent",
              borderRadius: isActiveRoute("/a24") ? "8px" : "0",
              transition: "background-color 0.2s ease",
            }}
            onMouseOver={(e) =>
              !isActiveRoute("/a24") &&
              (e.target.style.backgroundColor = "rgba(255, 255, 255, 0.05)")
            }
            onMouseOut={(e) =>
              !isActiveRoute("/a24") &&
              (e.target.style.backgroundColor = "transparent")
            }
          >
            <span
              style={{
                color: isActiveRoute("/a24") ? "#2aa2fd" : "#fff",
                fontFamily: "Outfit, sans-serif",
                fontSize: "18px",
                fontWeight: isActiveRoute("/a24") ? 600 : 400,
              }}
            >
              🎬 Studios
            </span>
          </Link>

          {/* User Section */}
          <div
            style={{
              marginTop: "20px",
              paddingTop: "20px",
              borderTop: "1px solid rgba(255, 255, 255, 0.1)",
            }}
          >
            {user ? (
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "15px",
                }}
              >
                <div
                  style={{
                    width: "40px",
                    height: "40px",
                    borderRadius: "50%",
                    overflow: "hidden",
                    border: "2px solid rgba(255, 74, 60, 0.44)",
                  }}
                >
                  <img
                    src={
                      user.photoURL ||
                      "https://cdn.builder.io/api/v1/image/assets/TEMP/0be9141cd3a2cd490a87bf9bab2add354433a845"
                    }
                    alt="User avatar"
                    style={{
                      width: "100%",
                      height: "100%",
                      objectFit: "cover",
                    }}
                  />
                </div>
                <span
                  style={{
                    color: "#fff",
                    fontFamily: "Outfit, sans-serif",
                    fontSize: "16px",
                    fontWeight: 400,
                  }}
                >
                  Profile
                </span>
              </div>
            ) : (
              <Link
                to="/sign-in"
                onClick={closeMobileMenu}
                style={{
                  display: "flex",
                  padding: "12px 24px",
                  justifyContent: "center",
                  alignItems: "center",
                  borderRadius: "25px",
                  background:
                    "linear-gradient(90deg, #FF4A3C 0%, #2AA2FD 100%)",
                  textDecoration: "none",
                  color: "#fff",
                  fontFamily: "Outfit, sans-serif",
                  fontSize: "16px",
                  fontWeight: 500,
                  transition: "transform 0.2s ease",
                }}
                onMouseOver={(e) => (e.target.style.transform = "scale(1.05)")}
                onMouseOut={(e) => (e.target.style.transform = "scale(1)")}
              >
                Sign In
              </Link>
            )}
          </div>
        </div>
      </div>
    </>
  );

  if (isMobile) {
    return (
      <>
        <div style={navStyles.mobile}>
          {/* Logo */}
          <Link
            to="/"
            style={{
              display: "flex",
              alignItems: "center",
              textDecoration: "none",
            }}
          >
            <CrowdflixLogo height={35} width={35} fill={"white"} />
          </Link>

          {/* Mobile Menu Toggle */}
          <HamburgerIcon />
        </div>

        {/* Mobile Menu */}
        <MobileMenu />

        {/* Search Overlay */}
        <SearchOverlay />
      </>
    );
  }

  // Desktop Navigation (enhanced)
  return (
    <>
      <div style={navStyles.desktop}>
        {/* Left Section - Logo and Search */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "60px",
          }}
        >
          {/* Logo */}
          <Link
            to="/"
            style={{
              display: "flex",
              alignItems: "center",
              textDecoration: "none",
              transition: "transform 0.2s ease",
            }}
            onMouseOver={(e) => (e.target.style.transform = "scale(1.05)")}
            onMouseOut={(e) => (e.target.style.transform = "scale(1)")}
          >
            <CrowdflixLogo height={40} width={40} fill={"white"} />
          </Link>

          {/* Search Icon */}
          <button
            onClick={toggleSearch}
            style={{
              display: "flex",
              width: "40px",
              height: "40px",
              padding: "8px",
              alignItems: "center",
              justifyContent: "center",
              gap: "10px",
              borderRadius: "100px",
              border: "1px solid rgba(255, 173, 20, 0.40)",
              background: "rgba(253, 71, 37, 0.05)",
              cursor: "pointer",
              transition: "all 0.3s ease",
            }}
            onMouseOver={(e) => {
              e.target.style.background = "rgba(255, 192, 63, 0.2)";
              e.target.style.transform = "scale(1.1)";
            }}
            onMouseOut={(e) => {
              e.target.style.background = "rgba(253, 71, 37, 0.05)";
              e.target.style.transform = "scale(1)";
            }}
            aria-label="Open search"
          >
            <Search style={{ color: "#FFC03F", fontSize: "20px" }} />
          </button>
        </div>

        {/* Center Navigation */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "20px",
          }}
        >
          <Link
            to="/"
            style={{
              display: "flex",
              width: "130px",
              height: "40px",
              padding: "0px 20px",
              justifyContent: "center",
              alignItems: "center",
              borderRadius: "100px",
              border: isActiveRoute("/")
                ? "1px solid #FF4A3C"
                : "1px solid rgba(255, 74, 60, 0.3)",
              background: isActiveRoute("/")
                ? "rgba(245, 31, 45, 0.15)"
                : "transparent",
              textDecoration: "none",
              transition: "all 0.3s ease",
            }}
            onMouseOver={(e) => {
              if (!isActiveRoute("/")) {
                e.target.style.background = "rgba(245, 31, 45, 0.1)";
                e.target.style.borderColor = "#FF4A3C";
              }
            }}
            onMouseOut={(e) => {
              if (!isActiveRoute("/")) {
                e.target.style.background = "transparent";
                e.target.style.borderColor = "rgba(255, 74, 60, 0.3)";
              }
            }}
          >
            <span
              style={{
                color: "#fff",
                textAlign: "center",
                fontFamily: "Outfit, sans-serif",
                fontSize: "16px",
                fontWeight: isActiveRoute("/") ? 600 : 400,
                lineHeight: "16px",
              }}
            >
              Home
            </span>
          </Link>

          <Link
            to="/marketplace"
            style={{
              display: "flex",
              width: "130px",
              height: "40px",
              justifyContent: "center",
              alignItems: "center",
              borderRadius: "100px",
              border: isActiveRoute("/marketplace")
                ? "1px solid #CBF6FF"
                : "1px solid rgba(53, 111, 180, 0.43)",
              background: isActiveRoute("/marketplace")
                ? "rgba(203, 246, 255, 0.1)"
                : "transparent",
              textDecoration: "none",
              transition: "all 0.3s ease",
            }}
            onMouseOver={(e) => {
              if (!isActiveRoute("/marketplace")) {
                e.target.style.background = "rgba(203, 246, 255, 0.05)";
                e.target.style.borderColor = "#CBF6FF";
              }
            }}
            onMouseOut={(e) => {
              if (!isActiveRoute("/marketplace")) {
                e.target.style.background = "transparent";
                e.target.style.borderColor = "rgba(53, 111, 180, 0.43)";
              }
            }}
          >
            <span
              style={{
                color: "#CBF6FF",
                textAlign: "center",
                fontFamily: "Outfit, sans-serif",
                fontSize: "16px",
                fontWeight: isActiveRoute("/marketplace") ? 600 : 400,
                lineHeight: "16px",
              }}
            >
              Marketplace
            </span>
          </Link>
        </div>

        {/* Right Section - User Info */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "20px",
          }}
        >
          {/* My Collection */}
          <Link
            to="/u/james-blackwood"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "10px",
              textDecoration: "none",
              cursor: "pointer",
              padding: "8px 12px",
              borderRadius: "8px",
              backgroundColor: isActiveRoute("/u/")
                ? "rgba(255, 203, 205, 0.1)"
                : "transparent",
              transition: "all 0.3s ease",
            }}
            onMouseOver={(e) => {
              if (!isActiveRoute("/u/")) {
                e.target.style.background = "rgba(255, 203, 205, 0.05)";
              }
            }}
            onMouseOut={(e) => {
              if (!isActiveRoute("/u/")) {
                e.target.style.background = "transparent";
              }
            }}
          >
            <span
              style={{
                color: "#FFCBCD",
                textAlign: "right",
                fontFamily: "Outfit, sans-serif",
                fontSize: "16px",
                fontWeight: isActiveRoute("/u/") ? 600 : 400,
                lineHeight: "16px",
              }}
            >
              My Collection
            </span>
            <div
              style={{
                display: "flex",
                width: "16px",
                height: "16px",
                justifyContent: "center",
                alignItems: "center",
                borderRadius: "100px",
                background: "#981D21",
              }}
            >
              <span
                style={{
                  color: "#fff",
                  textAlign: "center",
                  fontFamily: "Outfit, sans-serif",
                  fontSize: "10px",
                  fontWeight: 500,
                  lineHeight: "10px",
                }}
              >
                8
              </span>
            </div>
          </Link>

          {/* User Profile */}
          {user ? (
            <div
              style={{
                display: "flex",
                width: "50px",
                height: "50px",
                padding: "5px",
                justifyContent: "center",
                alignItems: "center",
                borderRadius: "100px",
                border: "1px solid rgba(255, 74, 60, 0.44)",
                background: "rgba(253, 71, 37, 0.05)",
                cursor: "pointer",
                transition: "all 0.3s ease",
              }}
              onMouseOver={(e) => {
                e.target.style.background = "rgba(253, 71, 37, 0.1)";
                e.target.style.transform = "scale(1.05)";
              }}
              onMouseOut={(e) => {
                e.target.style.background = "rgba(253, 71, 37, 0.05)";
                e.target.style.transform = "scale(1)";
              }}
            >
              <div
                style={{
                  display: "flex",
                  width: "40px",
                  height: "40px",
                  padding: "5px",
                  justifyContent: "center",
                  alignItems: "center",
                  borderRadius: "100px",
                  background: "rgba(253, 71, 37, 0.05)",
                  overflow: "hidden",
                }}
              >
                <img
                  src={
                    user.photoURL ||
                    "https://cdn.builder.io/api/v1/image/assets/TEMP/0be9141cd3a2cd490a87bf9bab2add354433a845"
                  }
                  alt="User avatar"
                  style={{
                    width: "100%",
                    height: "100%",
                    objectFit: "cover",
                  }}
                />
              </div>
            </div>
          ) : (
            <Link
              to="/sign-in"
              style={{
                color: "#fff",
                textDecoration: "none",
                fontFamily: "Outfit, sans-serif",
                fontSize: "16px",
                padding: "8px 16px",
                borderRadius: "8px",
                transition: "all 0.3s ease",
              }}
              onMouseOver={(e) => {
                e.target.style.background = "rgba(255, 255, 255, 0.1)";
              }}
              onMouseOut={(e) => {
                e.target.style.background = "transparent";
              }}
            >
              Sign in
            </Link>
          )}
        </div>
      </div>

      {/* Search Overlay */}
      <SearchOverlay />

      {/* Smart Quick Actions */}
      <SmartQuickActions />
    </>
  );
}

export default Navbar;
