import { Builder } from "@builder.io/react";
import React from "react";

// Import universe components
import UniverseHero from "./components/UniverseHero";
import StickyMediaColumn from "./components/StickyMediaColumn";
import FeaturedCharacters from "./components/FeaturedCharacters";
import CollectiblesGrid from "./components/CollectiblesGrid";
import MediaCarousel from "./components/MediaCarousel";
import VideoPlayer from "./components/VideoPlayer";
import CharacterBlock from "./components/CharacterBlock";
import MovieBlock from "./components/MovieBlock";
import MomentMediaDisplay from "./components/MomentMediaDisplay";
import MomentDescriptionStats from "./components/MomentDescriptionStats";
import SalesHistoryTable from "./components/SalesHistoryTable";
import BidsHistoryTable from "./components/BidsHistoryTable";
import MarketplaceMomentCard from "./components/MarketplaceMomentCard";
import MarketplaceFilterSidebar from "./components/MarketplaceFilterSidebar";
import SortAndSearchBar from "./components/SortAndSearchBar";
import MobileOptimizedFooter from "./components/MobileOptimizedFooter";
import MomentTitleSection from "./components/MomentTitleSection";
import MomentPriceSection from "./components/MomentPriceSection";
import OfferSelectionList from "./components/OfferSelectionList";
import PurchaseSummaryCard from "./components/PurchaseSummaryCard";
import PaymentMethodTabs from "./components/PaymentMethodTabs";
import PaymentForm from "./components/PaymentForm";
import SocialMediaIcons from "./components/SocialMediaIcons";

// Wrapper components for Builder.io
const BuilderUniverseHero = (props) => {
  return (
    <UniverseHero
      logo={props.logo || ""}
      bgImage={props.bgImage || ""}
      tagline={props.tagline || "Enter the Universe"}
      name={props.name || "Universe"}
    />
  );
};

const BuilderStickyMediaColumn = (props) => {
  return (
    <StickyMediaColumn
      videoUrl={props.videoUrl || ""}
      title={props.title || "Featured Content"}
      thumbnails={props.thumbnails || []}
    />
  );
};

const BuilderFeaturedCharacters = (props) => {
  return <FeaturedCharacters characters={props.characters || []} />;
};

const BuilderCollectiblesGrid = (props) => {
  return <CollectiblesGrid collectibles={props.collectibles || []} />;
};

const BuilderVideoPlayer = (props) => {
  return (
    <div
      style={{
        position: "sticky",
        top: "20px",
        height: "100vh",
        maxWidth: "40%",
        padding: "16px",
      }}
    >
      <VideoPlayer
        src={props.src || ""}
        autoPlay={props.autoPlay || false}
        loop={props.loop || false}
        muted={props.muted || true}
      />
    </div>
  );
};

const BuilderCharacterBlock = (props) => {
  return (
    <CharacterBlock
      name={props.name || "Iron Man"}
      description={props.description || "Character description..."}
      alias={props.alias || "Tony Stark"}
      nationality={props.nationality || "U.S"}
      height={props.height || "6'1"}
      actor={props.actor || "Robert Downey Jr."}
      born={props.born || "1973"}
      avatarImage={props.avatarImage || ""}
    />
  );
};

const BuilderMovieBlock = (props) => {
  return (
    <MovieBlock
      title={props.title || "Avengers: Endgame"}
      year={props.year || "2019"}
      tags={props.tags || ["Marvel", "Superhero", "Action"]}
      posterImage={props.posterImage || ""}
      carouselImages={props.carouselImages || []}
      credits={
        props.credits || {
          director: "Director Name",
          writers: "Writer Names",
          producers: "Producer Names",
          cinematography: "Cinematographer",
          composers: "Composer Names",
          releaseDate: "Release Date",
          boxOffice: "Box Office",
        }
      }
    />
  );
};

const BuilderMomentMediaDisplay = (props) => {
  return (
    <MomentMediaDisplay
      videoUrl={props.videoUrl || ""}
      angle1={props.angle1 || ""}
      angle2={props.angle2 || ""}
      angle3={props.angle3 || ""}
    />
  );
};

const BuilderMomentDescriptionStats = (props) => {
  return (
    <MomentDescriptionStats
      description={props.description || "Description about moment"}
      stats={props.stats || []}
    />
  );
};

const BuilderSalesHistoryTable = (props) => {
  return (
    <SalesHistoryTable
      availableCount={props.availableCount || 6}
      sortBy={props.sortBy || "Lowest Ask: low to high"}
      listings={props.listings || []}
    />
  );
};

const BuilderBidsHistoryTable = (props) => {
  return (
    <BidsHistoryTable
      timeFilter={props.timeFilter || "Today"}
      bidHistory={props.bidHistory || []}
      highestBid={props.highestBid || {}}
    />
  );
};

const BuilderMarketplaceMomentCard = (props) => {
  return (
    <MarketplaceMomentCard
      momentName={props.momentName || "Moment Title"}
      studio={props.studio || "Studio"}
      lowestAsk={props.lowestAsk || "00.00"}
      avgSale={props.avgSale || "00.00"}
      sold={props.sold || "9,854"}
      total={props.total || "12,000"}
      rarity={props.rarity || "Rarity Level"}
      videoPreviewUrl={props.videoPreviewUrl || ""}
      thumbnailUrl={props.thumbnailUrl || ""}
      momentId={props.momentId || ""}
    />
  );
};

const BuilderMarketplaceFilterSidebar = (props) => {
  return (
    <MarketplaceFilterSidebar
      onFilterChange={props.onFilterChange || (() => {})}
      onClearAll={props.onClearAll || (() => {})}
    />
  );
};

const BuilderSortAndSearchBar = (props) => {
  return (
    <SortAndSearchBar
      activeTab={props.activeTab || "Moments"}
      onTabChange={props.onTabChange || (() => {})}
      onSearchChange={props.onSearchChange || (() => {})}
      onSortChange={props.onSortChange || (() => {})}
      onFilterToggle={props.onFilterToggle || (() => {})}
    />
  );
};

const BuilderMobileOptimizedFooter = () => {
  return <MobileOptimizedFooter />;
};

const BuilderMomentTitleSection = (props) => {
  return (
    <MomentTitleSection
      rarity={props.rarity || "Legendary"}
      serialNumber={props.serialNumber || "#3,498"}
      sold={props.sold || "9,854"}
      total={props.total || "12,000"}
      momentName={props.momentName || "Iron Man"}
      subtitle={props.subtitle || "MCU Legendary Moment"}
      iconUrl={
        props.iconUrl ||
        "https://cdn.builder.io/api/v1/image/assets/TEMP/f874c6ddb00d519f7941eda79457c5fd2a177be6"
      }
    />
  );
};

const BuilderMomentPriceSection = (props) => {
  return (
    <MomentPriceSection
      lowestAsk={props.lowestAsk || "$13.00"}
      currency={props.currency || "USD"}
      avgSale={props.avgSale || "$14.00 USD"}
      forSale={props.forSale || "50"}
      onShare={props.onShare || (() => console.log("Share clicked"))}
      onPurchase={props.onPurchase || (() => console.log("Purchase clicked"))}
    />
  );
};

const BuilderOfferSelectionList = (props) => {
  return (
    <OfferSelectionList
      offers={
        props.offers || [
          { id: "1", price: 350.0, serial: 37, seller: "EWW" },
          { id: "2", price: 400.0, serial: 9, seller: "num1SEAfanNSD" },
          { id: "3", price: 550.0, serial: 2, seller: "wemby" },
        ]
      }
      selectedOffer={props.selectedOffer || null}
      onOfferSelect={
        props.onOfferSelect || (() => console.log("Offer selected"))
      }
      availableCount={props.availableCount || 6}
    />
  );
};

const BuilderPurchaseSummaryCard = (props) => {
  return (
    <PurchaseSummaryCard
      item={
        props.item || {
          name: "IRON MAN",
          description: "LEGENDARY MCU MOMENT",
          imageUrl:
            "https://cdn.builder.io/api/v1/image/assets/TEMP/31e7486266d19ac2ba83b04c7910ab8497cfe6b9",
          quantity: 2,
        }
      }
      selectedOffer={props.selectedOffer || { price: 400.0 }}
      subtotal={props.subtotal || 400.0}
      shipping={props.shipping || 7.24}
      taxes={props.taxes || 2.24}
      total={props.total || 407.24}
    />
  );
};

const BuilderPaymentMethodTabs = (props) => {
  return (
    <PaymentMethodTabs
      activeMethod={props.activeMethod || "card"}
      onMethodChange={
        props.onMethodChange || (() => console.log("Payment method changed"))
      }
    />
  );
};

const BuilderPaymentForm = (props) => {
  return (
    <PaymentForm
      onSubmit={props.onSubmit || (() => console.log("Payment submitted"))}
      total={props.total || 400.0}
      isLoading={props.isLoading || false}
    />
  );
};

// Register components with Builder.io
Builder.registerComponent(BuilderUniverseHero, {
  name: "Universe Hero",
  inputs: [
    {
      name: "logo",
      type: "file",
      allowedFileTypes: ["jpeg", "jpg", "png", "svg"],
      required: true,
      friendlyName: "Universe Logo",
    },
    {
      name: "bgImage",
      type: "file",
      allowedFileTypes: ["jpeg", "jpg", "png"],
      required: true,
      friendlyName: "Background Image",
    },
    {
      name: "tagline",
      type: "string",
      required: true,
      defaultValue: "Enter the Universe",
      friendlyName: "Tagline",
    },
    {
      name: "name",
      type: "string",
      required: true,
      defaultValue: "Universe",
      friendlyName: "Universe Name",
    },
  ],
});

Builder.registerComponent(BuilderStickyMediaColumn, {
  name: "Sticky Media Column",
  inputs: [
    {
      name: "videoUrl",
      type: "file",
      allowedFileTypes: ["mp4", "webm", "ogg"],
      required: true,
      friendlyName: "Featured Video",
    },
    {
      name: "title",
      type: "string",
      required: true,
      defaultValue: "Featured Content",
      friendlyName: "Video Title",
    },
    {
      name: "thumbnails",
      type: "list",
      subFields: [
        {
          name: "url",
          type: "file",
          allowedFileTypes: ["jpeg", "jpg", "png"],
        },
      ],
      friendlyName: "Thumbnail Images",
    },
  ],
});

Builder.registerComponent(BuilderFeaturedCharacters, {
  name: "Featured Characters",
  inputs: [
    {
      name: "characters",
      type: "list",
      subFields: [
        {
          name: "id",
          type: "string",
          required: true,
        },
        {
          name: "name",
          type: "string",
          required: true,
        },
        {
          name: "image",
          type: "file",
          allowedFileTypes: ["jpeg", "jpg", "png"],
          required: true,
        },
        {
          name: "description",
          type: "text",
          required: true,
        },
      ],
      defaultValue: [
        {
          id: "sample-character",
          name: "Sample Character",
          image: "",
          description: "A legendary character from the universe",
        },
      ],
      friendlyName: "Characters List",
    },
  ],
});

Builder.registerComponent(BuilderCollectiblesGrid, {
  name: "Collectibles Grid",
  inputs: [
    {
      name: "collectibles",
      type: "list",
      subFields: [
        {
          name: "id",
          type: "string",
          required: true,
        },
        {
          name: "title",
          type: "string",
          required: true,
        },
        {
          name: "image",
          type: "file",
          allowedFileTypes: ["jpeg", "jpg", "png"],
          required: true,
        },
        {
          name: "price",
          type: "string",
          required: true,
          defaultValue: "$0.00",
        },
        {
          name: "tier",
          type: "string",
          enum: ["Common", "Rare", "Epic", "Legendary", "Ultimate"],
          required: true,
          defaultValue: "Common",
        },
      ],
      defaultValue: [
        {
          id: "sample-collectible",
          title: "Sample Moment",
          image: "",
          price: "$99.00",
          tier: "Legendary",
        },
      ],
      friendlyName: "Collectibles List",
    },
  ],
});

Builder.registerComponent(BuilderVideoPlayer, {
  name: "Sticky Video Player",
  inputs: [
    {
      name: "src",
      type: "file",
      allowedFileTypes: ["mp4", "webm", "ogg"],
      required: true,
      friendlyName: "Video Source",
    },
    {
      name: "autoPlay",
      type: "boolean",
      defaultValue: true,
      friendlyName: "Auto Play",
    },
    {
      name: "loop",
      type: "boolean",
      defaultValue: true,
      friendlyName: "Loop Video",
    },
    {
      name: "muted",
      type: "boolean",
      defaultValue: true,
      friendlyName: "Muted",
    },
  ],
});

Builder.registerComponent(BuilderCharacterBlock, {
  name: "Character Block",
  inputs: [
    {
      name: "name",
      type: "string",
      required: true,
      defaultValue: "Iron Man",
      friendlyName: "Character Name",
    },
    {
      name: "description",
      type: "longText",
      required: true,
      defaultValue: "Character description...",
      friendlyName: "Character Description",
    },
    {
      name: "alias",
      type: "string",
      required: true,
      defaultValue: "Tony Stark",
      friendlyName: "Alias/Real Name",
    },
    {
      name: "nationality",
      type: "string",
      required: true,
      defaultValue: "U.S",
      friendlyName: "Nationality",
    },
    {
      name: "height",
      type: "string",
      required: true,
      defaultValue: "6'1",
      friendlyName: "Height",
    },
    {
      name: "actor",
      type: "string",
      required: true,
      defaultValue: "Robert Downey Jr.",
      friendlyName: "Portrayed By",
    },
    {
      name: "born",
      type: "string",
      required: true,
      defaultValue: "1973",
      friendlyName: "Born Year",
    },
    {
      name: "avatarImage",
      type: "file",
      allowedFileTypes: ["jpeg", "jpg", "png"],
      required: true,
      friendlyName: "Character Avatar",
    },
  ],
});

Builder.registerComponent(BuilderMovieBlock, {
  name: "Movie Block",
  inputs: [
    {
      name: "title",
      type: "string",
      required: true,
      defaultValue: "Avengers: Endgame",
      friendlyName: "Movie Title",
    },
    {
      name: "year",
      type: "string",
      required: true,
      defaultValue: "2019",
      friendlyName: "Release Year",
    },
    {
      name: "tags",
      type: "list",
      subFields: [
        {
          name: "tag",
          type: "string",
          required: true,
        },
      ],
      defaultValue: [
        { tag: "Marvel" },
        { tag: "Superhero" },
        { tag: "Action" },
      ],
      friendlyName: "Movie Tags",
    },
    {
      name: "posterImage",
      type: "file",
      allowedFileTypes: ["jpeg", "jpg", "png"],
      required: true,
      friendlyName: "Main Poster",
    },
    {
      name: "carouselImages",
      type: "list",
      subFields: [
        {
          name: "image",
          type: "file",
          allowedFileTypes: ["jpeg", "jpg", "png"],
          required: true,
        },
      ],
      friendlyName: "Carousel Images",
    },
    {
      name: "credits",
      type: "object",
      subFields: [
        {
          name: "director",
          type: "string",
          defaultValue: "Director Name",
          friendlyName: "Director",
        },
        {
          name: "writers",
          type: "string",
          defaultValue: "Writer Names",
          friendlyName: "Writers",
        },
        {
          name: "producers",
          type: "string",
          defaultValue: "Producer Names",
          friendlyName: "Producers",
        },
        {
          name: "cinematography",
          type: "string",
          defaultValue: "Cinematographer",
          friendlyName: "Cinematography",
        },
        {
          name: "composers",
          type: "string",
          defaultValue: "Composer Names",
          friendlyName: "Composers",
        },
        {
          name: "releaseDate",
          type: "string",
          defaultValue: "Release Date",
          friendlyName: "Release Date",
        },
        {
          name: "boxOffice",
          type: "string",
          defaultValue: "Box Office",
          friendlyName: "Box Office",
        },
      ],
      defaultValue: {
        director: "Director Name",
        writers: "Writer Names",
        producers: "Producer Names",
        cinematography: "Cinematographer",
        composers: "Composer Names",
        releaseDate: "Release Date",
        boxOffice: "Box Office",
      },
      friendlyName: "Movie Credits",
    },
  ],
});

Builder.registerComponent(BuilderMomentMediaDisplay, {
  name: "MomentMediaDisplay",
  inputs: [
    {
      name: "videoUrl",
      type: "file",
      allowedFileTypes: ["mp4", "webm", "ogg", "mov"],
      required: true,
      friendlyName: "Primary Video",
      helperText: "Main video that plays in the top section",
    },
    {
      name: "angle1",
      type: "file",
      allowedFileTypes: ["jpeg", "jpg", "png", "webp"],
      required: true,
      friendlyName: "Angle 1 Image",
      helperText: "First thumbnail image - different camera angle",
    },
    {
      name: "angle2",
      type: "file",
      allowedFileTypes: ["jpeg", "jpg", "png", "webp"],
      required: true,
      friendlyName: "Angle 2 Image",
      helperText: "Second thumbnail image - different camera angle",
    },
    {
      name: "angle3",
      type: "file",
      allowedFileTypes: ["jpeg", "jpg", "png", "webp"],
      required: true,
      friendlyName: "Angle 3 Image",
      helperText: "Third thumbnail image - different camera angle",
    },
  ],
});

Builder.registerComponent(BuilderMomentDescriptionStats, {
  name: "MomentDescriptionStats",
  inputs: [
    {
      name: "description",
      type: "longText",
      defaultValue: "Description about moment",
      friendlyName: "Moment Description",
      helperText: "Brief description of the moment",
    },
    {
      name: "stats",
      type: "list",
      defaultValue: [
        {
          label: "Unlisted",
          sublabel: "Owned",
          value: "306",
          color: "purple",
          bgColor: "rgba(118, 22, 156, 0.10)",
        },
        {
          label: "For Sale",
          sublabel: "Owned",
          value: "198",
          color: "blue",
          bgColor: "rgba(57, 65, 211, 0.10)",
        },
        {
          label: "Locked",
          sublabel: "Owned",
          value: "459",
          color: "cyan",
          bgColor: "rgba(55, 154, 184, 0.10)",
        },
      ],
      subFields: [
        {
          name: "label",
          type: "string",
          required: true,
          friendlyName: "Stat Label",
        },
        { name: "sublabel", type: "string", friendlyName: "Stat Sublabel" },
        {
          name: "value",
          type: "string",
          required: true,
          friendlyName: "Stat Value",
        },
        {
          name: "color",
          type: "string",
          enum: ["purple", "blue", "cyan", "green", "yellow", "red"],
          friendlyName: "Color Theme",
        },
        { name: "bgColor", type: "string", friendlyName: "Background Color" },
      ],
      friendlyName: "Statistics",
    },
  ],
});

Builder.registerComponent(BuilderSalesHistoryTable, {
  name: "SalesHistoryTable",
  inputs: [
    {
      name: "availableCount",
      type: "number",
      defaultValue: 6,
      friendlyName: "Available Count",
      helperText: "Number of available listings",
    },
    {
      name: "sortBy",
      type: "string",
      defaultValue: "Lowest Ask: low to high",
      friendlyName: "Sort Option",
      helperText: "Current sorting method",
    },
    {
      name: "listings",
      type: "list",
      defaultValue: [],
      subFields: [
        {
          name: "price",
          type: "string",
          required: true,
          friendlyName: "Price",
        },
        {
          name: "serial",
          type: "string",
          required: true,
          friendlyName: "Serial Number",
        },
        {
          name: "seller",
          type: "string",
          required: true,
          friendlyName: "Seller Username",
        },
        { name: "avatar", type: "string", friendlyName: "Avatar ID" },
        {
          name: "isSelected",
          type: "boolean",
          defaultValue: false,
          friendlyName: "Selected",
        },
        {
          name: "isHighlighted",
          type: "boolean",
          defaultValue: false,
          friendlyName: "Highlighted",
        },
      ],
      friendlyName: "Sales Listings",
    },
  ],
});

Builder.registerComponent(BuilderBidsHistoryTable, {
  name: "BidsHistoryTable",
  inputs: [
    {
      name: "timeFilter",
      type: "string",
      defaultValue: "Today",
      enum: ["Today", "This Week", "This Month", "All Time"],
      friendlyName: "Time Filter",
      helperText: "Filter bids by time period",
    },
    {
      name: "bidHistory",
      type: "list",
      defaultValue: [],
      subFields: [
        {
          name: "user",
          type: "string",
          required: true,
          friendlyName: "Username",
        },
        { name: "avatar", type: "string", friendlyName: "Avatar ID" },
        {
          name: "price",
          type: "string",
          required: true,
          friendlyName: "Bid Price",
        },
        {
          name: "time",
          type: "string",
          required: true,
          friendlyName: "Bid Time",
        },
      ],
      friendlyName: "Bid History",
    },
    {
      name: "highestBid",
      type: "object",
      subFields: [
        {
          name: "user",
          type: "string",
          required: true,
          friendlyName: "Username",
        },
        { name: "avatar", type: "string", friendlyName: "Avatar ID" },
        {
          name: "price",
          type: "string",
          required: true,
          friendlyName: "Bid Price",
        },
        {
          name: "time",
          type: "string",
          required: true,
          friendlyName: "Bid Time",
        },
      ],
      defaultValue: {
        user: "@Twtbttttt",
        avatar: "user-6",
        price: "$13.00",
        time: "09:00 pm",
      },
      friendlyName: "Highest Bid",
    },
  ],
});

Builder.registerComponent(BuilderMarketplaceMomentCard, {
  name: "Marketplace Moment Card",
  inputs: [
    {
      name: "momentName",
      type: "string",
      defaultValue: "Moment Title",
      friendlyName: "Moment Name",
      helperText: "The name/title of the moment",
    },
    {
      name: "studio",
      type: "string",
      defaultValue: "Studio",
      friendlyName: "Studio Name",
      helperText: "Production studio or franchise name",
    },
    {
      name: "lowestAsk",
      type: "string",
      defaultValue: "00.00",
      friendlyName: "Lowest Ask Price",
      helperText: "Lowest asking price (without $ or currency)",
    },
    {
      name: "avgSale",
      type: "string",
      defaultValue: "00.00",
      friendlyName: "Average Sale Price",
      helperText: "Average sale price (without $ or currency)",
    },
    {
      name: "sold",
      type: "string",
      defaultValue: "9,854",
      friendlyName: "Sold Count",
      helperText: "Number of moments sold",
    },
    {
      name: "total",
      type: "string",
      defaultValue: "12,000",
      friendlyName: "Total Count",
      helperText: "Total number of moments available",
    },
    {
      name: "rarity",
      type: "string",
      defaultValue: "Rarity Level",
      enum: ["Common", "Fandom", "Rare", "Legendary", "Ultimate"],
      friendlyName: "Rarity Level",
      helperText: "Rarity tier of the moment",
    },
    {
      name: "videoPreviewUrl",
      type: "file",
      allowedFileTypes: ["mp4", "webm", "ogg"],
      friendlyName: "Video Preview",
      helperText: "Video that plays on hover (optional)",
    },
    {
      name: "thumbnailUrl",
      type: "file",
      allowedFileTypes: ["jpeg", "jpg", "png", "webp"],
      required: true,
      friendlyName: "Thumbnail Image",
      helperText: "Static thumbnail image shown by default",
    },
    {
      name: "momentId",
      type: "string",
      friendlyName: "Moment ID",
      helperText: "Unique identifier for routing to moment detail page",
    },
  ],
});

Builder.registerComponent(BuilderMarketplaceFilterSidebar, {
  name: "Marketplace Filter Sidebar",
  inputs: [
    {
      name: "onFilterChange",
      type: "string",
      friendlyName: "Filter Change Handler",
      helperText: "Function name to handle filter changes",
      advanced: true,
    },
    {
      name: "onClearAll",
      type: "string",
      friendlyName: "Clear All Handler",
      helperText: "Function name to handle clearing all filters",
      advanced: true,
    },
  ],
});

Builder.registerComponent(BuilderSortAndSearchBar, {
  name: "Sort and Search Bar",
  inputs: [
    {
      name: "activeTab",
      type: "string",
      defaultValue: "Moments",
      enum: ["All", "Moments", "Packs", "Latest Purchases", "Top Purchases"],
      friendlyName: "Active Tab",
      helperText: "Currently selected tab",
    },
    {
      name: "onTabChange",
      type: "string",
      friendlyName: "Tab Change Handler",
      helperText: "Function name to handle tab changes",
      advanced: true,
    },
    {
      name: "onSearchChange",
      type: "string",
      friendlyName: "Search Change Handler",
      helperText: "Function name to handle search input changes",
      advanced: true,
    },
    {
      name: "onSortChange",
      type: "string",
      friendlyName: "Sort Change Handler",
      helperText: "Function name to handle sort changes",
      advanced: true,
    },
    {
      name: "onFilterToggle",
      type: "string",
      friendlyName: "Filter Toggle Handler",
      helperText: "Function name to handle filter sidebar toggle",
      advanced: true,
    },
  ],
});

Builder.registerComponent(BuilderMobileOptimizedFooter, {
  name: "Mobile Optimized Footer",
  inputs: [],
  hideFromInsertMenu: false,
  friendlyName: "Mobile Footer",
  helperText:
    "Responsive footer optimized for mobile devices with email signup and social links",
});

Builder.registerComponent(BuilderMomentTitleSection, {
  name: "Moment Title Section",
  inputs: [
    {
      name: "rarity",
      type: "string",
      defaultValue: "Legendary",
      enum: ["Common", "Fandom", "Rare", "Legendary", "Ultimate"],
      friendlyName: "Rarity Level",
      helperText: "The rarity tier of the moment",
    },
    {
      name: "serialNumber",
      type: "string",
      defaultValue: "#3,498",
      friendlyName: "Serial Number",
      helperText: "Unique serial number identifier",
    },
    {
      name: "sold",
      type: "string",
      defaultValue: "9,854",
      friendlyName: "Sold Count",
      helperText: "Number of moments sold",
    },
    {
      name: "total",
      type: "string",
      defaultValue: "12,000",
      friendlyName: "Total Count",
      helperText: "Total number of moments minted",
    },
    {
      name: "momentName",
      type: "string",
      defaultValue: "Iron Man",
      friendlyName: "Moment Name",
      helperText: "Main title of the moment",
    },
    {
      name: "subtitle",
      type: "string",
      defaultValue: "MCU Legendary Moment",
      friendlyName: "Subtitle",
      helperText: "Description or category subtitle",
    },
    {
      name: "iconUrl",
      type: "file",
      allowedFileTypes: ["jpeg", "jpg", "png", "svg", "webp"],
      defaultValue:
        "https://cdn.builder.io/api/v1/image/assets/TEMP/f874c6ddb00d519f7941eda79457c5fd2a177be6",
      friendlyName: "Character Icon",
      helperText: "Icon image displayed next to the moment name",
    },
  ],
  hideFromInsertMenu: false,
  friendlyName: "Moment Title",
  helperText:
    "Title section with rarity badges, serial number, and moment information",
});

Builder.registerComponent(BuilderMomentPriceSection, {
  name: "Moment Price Section",
  inputs: [
    {
      name: "lowestAsk",
      type: "string",
      defaultValue: "$13.00",
      friendlyName: "Lowest Ask",
      helperText: "Current lowest asking price",
    },
    {
      name: "currency",
      type: "string",
      defaultValue: "USD",
      enum: ["USD", "EUR", "GBP", "CAD", "AUD"],
      friendlyName: "Currency",
      helperText: "Currency symbol to display",
    },
    {
      name: "avgSale",
      type: "string",
      defaultValue: "$14.00 USD",
      friendlyName: "Average Sale",
      helperText: "Average sale price with currency",
    },
    {
      name: "forSale",
      type: "string",
      defaultValue: "50",
      friendlyName: "For Sale Count",
      helperText: "Number of moments currently for sale",
    },
  ],
  hideFromInsertMenu: false,
  friendlyName: "Moment Pricing",
  helperText: "Pricing interface with purchase button and market statistics",
});

Builder.registerComponent(BuilderOfferSelectionList, {
  name: "Offer Selection List",
  inputs: [
    {
      name: "offers",
      type: "list",
      subFields: [
        {
          name: "id",
          type: "string",
          required: true,
          friendlyName: "Offer ID",
        },
        {
          name: "price",
          type: "number",
          required: true,
          friendlyName: "Price",
        },
        {
          name: "serial",
          type: "string",
          required: true,
          friendlyName: "Serial Number",
        },
        {
          name: "seller",
          type: "string",
          required: true,
          friendlyName: "Seller Username",
        },
      ],
      defaultValue: [
        { id: "1", price: 350.0, serial: "37", seller: "EWW" },
        { id: "2", price: 400.0, serial: "9", seller: "num1SEAfanNSD" },
        { id: "3", price: 550.0, serial: "2", seller: "wemby" },
      ],
      friendlyName: "Available Offers",
      helperText: "List of available offers for purchase",
    },
    {
      name: "availableCount",
      type: "number",
      defaultValue: 6,
      friendlyName: "Available Count",
      helperText: "Total number of available offers",
    },
  ],
  hideFromInsertMenu: false,
  friendlyName: "Offer Selection",
  helperText: "Radio button list for selecting purchase offers",
});

Builder.registerComponent(BuilderPurchaseSummaryCard, {
  name: "Purchase Summary Card",
  inputs: [
    {
      name: "item",
      type: "object",
      subFields: [
        {
          name: "name",
          type: "string",
          defaultValue: "IRON MAN",
          friendlyName: "Item Name",
        },
        {
          name: "description",
          type: "string",
          defaultValue: "LEGENDARY MCU MOMENT",
          friendlyName: "Item Description",
        },
        {
          name: "imageUrl",
          type: "file",
          allowedFileTypes: ["jpeg", "jpg", "png", "webp"],
          defaultValue:
            "https://cdn.builder.io/api/v1/image/assets/TEMP/31e7486266d19ac2ba83b04c7910ab8497cfe6b9",
          friendlyName: "Item Image",
        },
        {
          name: "quantity",
          type: "number",
          defaultValue: 2,
          friendlyName: "Quantity",
        },
      ],
      defaultValue: {
        name: "IRON MAN",
        description: "LEGENDARY MCU MOMENT",
        imageUrl:
          "https://cdn.builder.io/api/v1/image/assets/TEMP/31e7486266d19ac2ba83b04c7910ab8497cfe6b9",
        quantity: 2,
      },
      friendlyName: "Item Details",
      helperText: "Details of the item being purchased",
    },
    {
      name: "subtotal",
      type: "number",
      defaultValue: 400.0,
      friendlyName: "Subtotal",
      helperText: "Item price subtotal",
    },
    {
      name: "shipping",
      type: "number",
      defaultValue: 7.24,
      friendlyName: "Shipping Cost",
      helperText: "Shipping and handling fee",
    },
    {
      name: "taxes",
      type: "number",
      defaultValue: 2.24,
      friendlyName: "Taxes",
      helperText: "Tax amount included in total",
    },
    {
      name: "total",
      type: "number",
      defaultValue: 407.24,
      friendlyName: "Total Price",
      helperText: "Final total including all fees",
    },
  ],
  hideFromInsertMenu: false,
  friendlyName: "Purchase Summary",
  helperText: "White card showing item details and pricing breakdown",
});

Builder.registerComponent(BuilderPaymentMethodTabs, {
  name: "Payment Method Tabs",
  inputs: [
    {
      name: "activeMethod",
      type: "string",
      defaultValue: "card",
      enum: ["card", "apple_pay", "dapper_wallet"],
      friendlyName: "Active Payment Method",
      helperText: "Currently selected payment method",
    },
  ],
  hideFromInsertMenu: false,
  friendlyName: "Payment Methods",
  helperText: "Tab selector for different payment methods",
});

Builder.registerComponent(BuilderPaymentForm, {
  name: "Payment Form",
  inputs: [
    {
      name: "total",
      type: "number",
      defaultValue: 400.0,
      friendlyName: "Total Amount",
      helperText: "Total amount to be charged",
    },
    {
      name: "isLoading",
      type: "boolean",
      defaultValue: false,
      friendlyName: "Loading State",
      helperText: "Whether the form is in loading state",
    },
  ],
  hideFromInsertMenu: false,
  friendlyName: "Payment Form",
  helperText: "Credit card input form with validation",
});

// Register Social Media Icons component
Builder.registerComponent(SocialMediaIcons, {
  name: "Social Media Icons",
  inputs: [
    {
      name: "socials",
      type: "object",
      subFields: [
        { name: "youtube", type: "text", friendlyName: "YouTube URL" },
        { name: "twitter", type: "text", friendlyName: "Twitter URL" },
        { name: "x", type: "text", friendlyName: "X (Twitter) URL" },
        { name: "discord", type: "text", friendlyName: "Discord URL" },
        { name: "twitch", type: "text", friendlyName: "Twitch URL" },
        { name: "tiktok", type: "text", friendlyName: "TikTok URL" },
        { name: "reddit", type: "text", friendlyName: "Reddit URL" },
        { name: "netflix", type: "text", friendlyName: "Netflix URL" },
        { name: "pinterest", type: "text", friendlyName: "Pinterest URL" },
        { name: "messenger", type: "text", friendlyName: "Messenger URL" },
        { name: "zoom", type: "text", friendlyName: "Zoom URL" },
        { name: "facebook", type: "text", friendlyName: "Facebook URL" },
        { name: "linkedin", type: "text", friendlyName: "LinkedIn URL" },
        { name: "instagram", type: "text", friendlyName: "Instagram URL" },
      ],
      defaultValue: {},
      friendlyName: "Social Media Links",
      helperText: "Add links to social media profiles",
    },
    {
      name: "variant",
      type: "text",
      enum: ["profile", "footer", "card"],
      defaultValue: "profile",
      friendlyName: "Variant",
      helperText: "Choose the display variant",
    },
    {
      name: "size",
      type: "text",
      enum: ["small", "default", "large"],
      defaultValue: "default",
      friendlyName: "Size",
      helperText: "Choose the icon size",
    },
    {
      name: "className",
      type: "text",
      friendlyName: "CSS Class",
      helperText: "Additional CSS classes",
    },
  ],
  hideFromInsertMenu: false,
  friendlyName: "Social Media Icons",
  helperText: "Glassmorphism social media icons with platform branding",
});

// Register a layout wrapper for left-right universe layout
const UniverseLayoutWrapper = ({ children }) => {
  return (
    <div className="universe-layout-container">
      <div className="universe-left-column">{children}</div>
      <div className="universe-right-column">{children}</div>
    </div>
  );
};

Builder.registerComponent(UniverseLayoutWrapper, {
  name: "Universe Layout Container",
  canHaveChildren: true,
  childRequirements: {
    message:
      "Add Sticky Media Column to left side and Universe Hero + other components to right side",
  },
});

// Initialize Builder.io with API key - only if valid
const BUILDER_API_KEY = process.env.REACT_APP_BUILDER_API_KEY;
const BUILDER_ENABLED =
  BUILDER_API_KEY &&
  BUILDER_API_KEY !== "YOUR_BUILDER_API_KEY" &&
  BUILDER_API_KEY !== "your-builder-api-key-here";

if (BUILDER_ENABLED) {
  try {
    Builder.init(BUILDER_API_KEY);
    console.log("Builder.io initialized successfully");
  } catch (error) {
    console.warn("Builder.io initialization failed:", error.message);
  }
} else {
  console.log(
    "Builder.io not configured - components will work with sample data",
  );
  console.log(
    "To enable Builder.io, add REACT_APP_BUILDER_API_KEY to your environment variables",
  );
}

export default Builder;
