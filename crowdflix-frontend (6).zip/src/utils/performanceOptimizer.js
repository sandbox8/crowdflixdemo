// Performance Optimizer - Smart Preloading and UX Enhancements

class PerformanceOptimizer {
  constructor() {
    this.preloadedRoutes = new Set();
    this.userBehavior = {
      visitHistory: [],
      timeSpent: {},
      interactions: 0,
    };
    this.init();
  }

  init() {
    this.setupIntersectionObserver();
    this.setupUserBehaviorTracking();
    this.setupPredictivePreloading();
  }

  // Intelligent intersection observer for lazy loading and preloading
  setupIntersectionObserver() {
    if (!window.IntersectionObserver) return;

    // Image lazy loading with fade-in effect
    this.imageObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const img = entry.target;
            if (img.dataset.src) {
              this.loadImage(img);
              this.imageObserver.unobserve(img);
            }
          }
        });
      },
      { threshold: 0.1, rootMargin: "50px" },
    );

    // Link preloading on hover/near-viewport
    this.linkObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const link = entry.target;
            const href = link.getAttribute("href");
            if (href && !this.preloadedRoutes.has(href)) {
              this.preloadRoute(href);
            }
          }
        });
      },
      { threshold: 0, rootMargin: "100px" },
    );

    this.observeElements();
  }

  // Load image with smooth transition
  loadImage(img) {
    return new Promise((resolve) => {
      const newImg = new Image();
      newImg.onload = () => {
        img.src = img.dataset.src;
        img.classList.add("loaded");
        resolve();
      };
      newImg.onerror = () => {
        img.classList.add("error");
        resolve();
      };
      newImg.src = img.dataset.src;
    });
  }

  // Preload route for faster navigation
  preloadRoute(href) {
    if (this.preloadedRoutes.has(href)) return;

    const link = document.createElement("link");
    link.rel = "prefetch";
    link.href = href;
    document.head.appendChild(link);

    this.preloadedRoutes.add(href);
  }

  // Track user behavior for predictive loading
  setupUserBehaviorTracking() {
    let startTime = Date.now();
    let currentRoute = window.location.pathname;

    // Track page visit duration
    const trackTimeSpent = () => {
      const timeSpent = Date.now() - startTime;
      this.userBehavior.timeSpent[currentRoute] =
        (this.userBehavior.timeSpent[currentRoute] || 0) + timeSpent;
    };

    // Track route changes
    const trackRouteChange = () => {
      trackTimeSpent();
      this.userBehavior.visitHistory.push({
        route: currentRoute,
        timestamp: Date.now(),
      });
      currentRoute = window.location.pathname;
      startTime = Date.now();
    };

    // Track interactions
    const trackInteraction = (e) => {
      this.userBehavior.interactions++;

      // Predictive preloading based on user patterns
      if (e.target.closest("a[href]")) {
        const href = e.target.closest("a[href]").getAttribute("href");
        setTimeout(() => this.preloadRoute(href), 100);
      }
    };

    window.addEventListener("beforeunload", trackTimeSpent);
    window.addEventListener("popstate", trackRouteChange);
    document.addEventListener("click", trackInteraction, { passive: true });
    document.addEventListener("mouseover", trackInteraction, { passive: true });

    // Track visibility changes
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) {
        trackTimeSpent();
      } else {
        startTime = Date.now();
      }
    });
  }

  // Predictive preloading based on user patterns
  setupPredictivePreloading() {
    // Preload likely next routes based on current route
    const predictiveRoutes = {
      "/": ["/marketplace", "/u/james-blackwood"],
      "/marketplace": ["/moment/", "/u/james-blackwood"],
      "/u/": ["/marketplace", "/moment/"],
      "/moment/": ["/marketplace", "/u/james-blackwood"],
    };

    const currentRoute = window.location.pathname;
    const routeKey = Object.keys(predictiveRoutes).find((key) =>
      currentRoute.startsWith(key),
    );

    if (routeKey) {
      // Delay preloading to not interfere with current page
      setTimeout(() => {
        predictiveRoutes[routeKey].forEach((route) => {
          if (!this.preloadedRoutes.has(route)) {
            this.preloadRoute(route);
          }
        });
      }, 2000);
    }
  }

  // Observe elements for lazy loading and preloading
  observeElements() {
    // Observe images with data-src
    document.querySelectorAll("img[data-src]").forEach((img) => {
      this.imageObserver.observe(img);
    });

    // Observe internal links
    document.querySelectorAll("a[href^='/']").forEach((link) => {
      this.linkObserver.observe(link);
    });
  }

  // Add smooth page transitions
  static addPageTransitions() {
    const style = document.createElement("style");
    style.textContent = `
      .page-transition-enter {
        opacity: 0;
        transform: translateY(20px);
      }
      
      .page-transition-enter-active {
        opacity: 1;
        transform: translateY(0);
        transition: opacity 0.3s ease, transform 0.3s ease;
      }
      
      .page-transition-exit {
        opacity: 1;
        transform: translateY(0);
      }
      
      .page-transition-exit-active {
        opacity: 0;
        transform: translateY(-20px);
        transition: opacity 0.3s ease, transform 0.3s ease;
      }

      img[data-src] {
        opacity: 0;
        transition: opacity 0.3s ease;
      }

      img[data-src].loaded {
        opacity: 1;
      }

      img[data-src].error {
        opacity: 0.5;
        filter: grayscale(1);
      }
    `;
    document.head.appendChild(style);
  }

  // Optimize for mobile performance
  static optimizeForMobile() {
    if (window.innerWidth <= 768) {
      // Reduce animations on mobile
      document.documentElement.style.setProperty(
        "--animation-duration",
        "0.2s",
      );

      // Optimize touch events
      document.addEventListener("touchstart", () => {}, { passive: true });
    }
  }

  // Get performance insights
  getPerformanceInsights() {
    return {
      preloadedRoutes: Array.from(this.preloadedRoutes),
      userBehavior: this.userBehavior,
      navigationTiming: performance.getEntriesByType("navigation")[0],
      resourceTimings: performance.getEntriesByType("resource"),
    };
  }
}

// Initialize performance optimizer
const performanceOptimizer = new PerformanceOptimizer();

// Initialize optimizations
PerformanceOptimizer.addPageTransitions();
PerformanceOptimizer.optimizeForMobile();

export default performanceOptimizer;
