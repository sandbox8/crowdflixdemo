// Mobile utility functions for CrowdFlix

/**
 * Detect if the device is mobile
 */
export const isMobileDevice = () => {
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
    navigator.userAgent,
  );
};

/**
 * Detect if the device is iOS
 */
export const isIOS = () => {
  return /iPad|iPhone|iPod/.test(navigator.userAgent);
};

/**
 * Detect if the device is Android
 */
export const isAndroid = () => {
  return /Android/i.test(navigator.userAgent);
};

/**
 * Get screen size category
 */
export const getScreenSize = () => {
  const width = window.innerWidth;

  if (width < 480) return "xs"; // Extra small phones
  if (width < 768) return "sm"; // Small phones
  if (width < 1024) return "md"; // Tablets
  if (width < 1440) return "lg"; // Small laptops
  return "xl"; // Large screens
};

/**
 * Check if device supports touch
 */
export const isTouchDevice = () => {
  return "ontouchstart" in window || navigator.maxTouchPoints > 0;
};

/**
 * Optimize image loading for mobile
 */
export const getOptimizedImageUrl = (baseUrl, options = {}) => {
  const { width = 800, quality = 80, format = "webp" } = options;
  const screenSize = getScreenSize();

  // Adjust dimensions based on screen size
  let optimizedWidth = width;
  switch (screenSize) {
    case "xs":
      optimizedWidth = Math.min(width, 480);
      break;
    case "sm":
      optimizedWidth = Math.min(width, 768);
      break;
    case "md":
      optimizedWidth = Math.min(width, 1024);
      break;
    default:
      optimizedWidth = width;
  }

  // For Builder.io URLs, add optimization parameters
  if (baseUrl.includes("cdn.builder.io")) {
    const url = new URL(baseUrl);
    url.searchParams.set("format", format);
    url.searchParams.set("width", optimizedWidth.toString());
    url.searchParams.set("quality", quality.toString());
    return url.toString();
  }

  return baseUrl;
};

/**
 * Add haptic feedback for mobile interactions
 */
export const addHapticFeedback = (type = "light") => {
  if (!isMobileDevice() || !navigator.vibrate) return;

  const patterns = {
    light: [10],
    medium: [20],
    heavy: [30],
    success: [10, 50, 10],
    error: [50, 50, 50],
  };

  navigator.vibrate(patterns[type] || patterns.light);
};

/**
 * Optimize scroll performance for mobile
 */
export const optimizeScrolling = (element) => {
  if (!element) return;

  element.style.webkitOverflowScrolling = "touch";
  element.style.scrollBehavior = "smooth";

  // Add momentum scrolling for iOS
  if (isIOS()) {
    element.style.webkitOverflowScrolling = "touch";
  }
};

/**
 * Handle safe area insets for devices with notches
 */
export const getSafeAreaInsets = () => {
  const style = getComputedStyle(document.documentElement);

  return {
    top: style.getPropertyValue("env(safe-area-inset-top)") || "0px",
    right: style.getPropertyValue("env(safe-area-inset-right)") || "0px",
    bottom: style.getPropertyValue("env(safe-area-inset-bottom)") || "0px",
    left: style.getPropertyValue("env(safe-area-inset-left)") || "0px",
  };
};

/**
 * Lazy load images with intersection observer
 */
export const setupLazyLoading = (selector = "img[data-lazy]") => {
  if (!("IntersectionObserver" in window)) {
    // Fallback for browsers without IntersectionObserver
    const images = document.querySelectorAll(selector);
    images.forEach((img) => {
      if (img.dataset.lazy) {
        img.src = img.dataset.lazy;
        img.removeAttribute("data-lazy");
      }
    });
    return;
  }

  const imageObserver = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const img = entry.target;
          if (img.dataset.lazy) {
            img.src = img.dataset.lazy;
            img.removeAttribute("data-lazy");
            img.classList.add("loaded");
            observer.unobserve(img);
          }
        }
      });
    },
    {
      rootMargin: "50px 0px", // Start loading 50px before entering viewport
      threshold: 0.1,
    },
  );

  document.querySelectorAll(selector).forEach((img) => {
    imageObserver.observe(img);
  });
};

/**
 * Debounce function for performance optimization
 */
export const debounce = (func, wait, immediate = false) => {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      timeout = null;
      if (!immediate) func(...args);
    };
    const callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func(...args);
  };
};

/**
 * Throttle function for scroll and resize events
 */
export const throttle = (func, limit) => {
  let inThrottle;
  return function (...args) {
    if (!inThrottle) {
      func.apply(this, args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
};

/**
 * Prevent zoom on input focus (iOS)
 */
export const preventZoomOnFocus = () => {
  if (!isIOS()) return;

  const viewport = document.querySelector("meta[name=viewport]");
  if (!viewport) return;

  const inputs = document.querySelectorAll("input, textarea, select");

  inputs.forEach((input) => {
    input.addEventListener("focus", () => {
      viewport.setAttribute(
        "content",
        "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no",
      );
    });

    input.addEventListener("blur", () => {
      viewport.setAttribute(
        "content",
        "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover",
      );
    });
  });
};

/**
 * Handle orientation changes
 */
export const handleOrientationChange = (callback) => {
  const orientationHandler = debounce(() => {
    const orientation =
      window.screen?.orientation?.angle ?? window.orientation ?? 0;
    const isLandscape = Math.abs(orientation) === 90;
    callback({ orientation, isLandscape });
  }, 100);

  window.addEventListener("orientationchange", orientationHandler);
  window.addEventListener("resize", orientationHandler);

  // Return cleanup function
  return () => {
    window.removeEventListener("orientationchange", orientationHandler);
    window.removeEventListener("resize", orientationHandler);
  };
};

/**
 * Optimize component rendering for mobile
 */
export const getMobileOptimizedProps = (baseProps = {}) => {
  const screenSize = getScreenSize();
  const isMobile = ["xs", "sm"].includes(screenSize);

  return {
    ...baseProps,
    loading: isMobile ? "lazy" : "eager",
    decoding: "async",
    ...(isMobile && {
      style: {
        ...baseProps.style,
        willChange: "auto",
        transform: "translateZ(0)",
        backfaceVisibility: "hidden",
      },
    }),
  };
};

/**
 * Network-aware loading
 */
export const getConnectionSpeed = () => {
  if (!navigator.connection) return "unknown";

  const connection = navigator.connection;
  const effectiveType = connection.effectiveType;

  switch (effectiveType) {
    case "slow-2g":
    case "2g":
      return "slow";
    case "3g":
      return "medium";
    case "4g":
      return "fast";
    default:
      return "unknown";
  }
};

/**
 * Service Worker registration for offline support
 */
export const registerServiceWorker = () => {
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker
        .register("/sw.js")
        .then((registration) => {
          console.log("SW registered: ", registration);
        })
        .catch((registrationError) => {
          console.log("SW registration failed: ", registrationError);
        });
    });
  }
};

/**
 * Web Share API for mobile sharing
 */
export const shareContent = async (shareData) => {
  if (!navigator.share) {
    // Fallback to copying to clipboard
    if (navigator.clipboard && shareData.url) {
      try {
        await navigator.clipboard.writeText(shareData.url);
        addHapticFeedback("success");
        return { success: true, method: "clipboard" };
      } catch (err) {
        console.error("Failed to copy to clipboard:", err);
        return { success: false, error: err };
      }
    }
    return { success: false, error: "Share not supported" };
  }

  try {
    await navigator.share(shareData);
    addHapticFeedback("success");
    return { success: true, method: "native" };
  } catch (err) {
    if (err.name !== "AbortError") {
      console.error("Share failed:", err);
    }
    return { success: false, error: err };
  }
};

/**
 * Check if device supports PWA installation
 */
export const canInstallPWA = () => {
  return "serviceWorker" in navigator && "BeforeInstallPromptEvent" in window;
};

export default {
  isMobileDevice,
  isIOS,
  isAndroid,
  getScreenSize,
  isTouchDevice,
  getOptimizedImageUrl,
  addHapticFeedback,
  optimizeScrolling,
  getSafeAreaInsets,
  setupLazyLoading,
  debounce,
  throttle,
  preventZoomOnFocus,
  handleOrientationChange,
  getMobileOptimizedProps,
  getConnectionSpeed,
  registerServiceWorker,
  shareContent,
  canInstallPWA,
};
