// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getFunctions } from "firebase/functions";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyAaJTgppgheFspm91EI1lbtkY5jH617oGg",
    authDomain: "crowdflix.firebaseapp.com",
    projectId: "crowdflix",
    storageBucket: "crowdflix.appspot.com",
    messagingSenderId: "470017780656",
    appId: "1:470017780656:web:c0049ad827413bbcf1c475",
    measurementId: "G-0QTW1D316J"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and get a reference to the service
const auth = getAuth(app);

// Initialize Firebase Storage and get a reference to the service
export const storage = getStorage(app);

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(app);

const functions = getFunctions(app);

export { auth, db, functions };