# Builder.io Setup Instructions

## Quick Start (Universe Pages Work Without Builder.io)

The universe pages will work immediately with sample data. You don't need Builder.io to test the functionality.

## Optional: Enable Builder.io CMS

To enable content management through Builder.io:

### 1. Get Builder.io API Key

1. Sign up at [builder.io](https://builder.io)
2. Create a new space
3. Copy your API key from Settings > API Keys

### 2. Add Environment Variable

Create a `.env.local` file in your project root:

```
REACT_APP_BUILDER_API_KEY=your-actual-api-key-here
```

### 3. Create Universe Page Model

In your Builder.io dashboard:

1. Go to Models
2. Click "Create New Model"
3. Name: `universe-page`
4. Type: `page`
5. URL Pattern: `/universe/:slug`

### 4. Test the Integration

1. Restart your development server
2. Visit any universe page (e.g., `/universe/marvel`)
3. Check the debug info in the bottom-right corner

## Components Available in Builder.io

Once configured, you can use these components in the visual editor:

- **Universe Hero** - Hero section with logo and background
- **Sticky Media Column** - Video player with thumbnails
- **Featured Characters** - Character showcase grid
- **Collectibles Grid** - Moment cards with pricing
- **Universe Layout Container** - Left-right layout wrapper

## Troubleshooting

### Error: "Authorization required"

- Check your API key is correct
- Verify the model name is `universe-page`
- Ensure the space has the proper permissions

### Error: "body stream already read"

- This usually means multiple initialization attempts
- Restart your development server
- Clear browser cache

### Universe pages show sample data

- This is normal behavior when Builder.io is not configured
- All functionality works with sample data
- Add the API key when you're ready for content management

## Development vs Production

- **Development**: Sample data provides full functionality
- **Production**: Add Builder.io for content management by editors
